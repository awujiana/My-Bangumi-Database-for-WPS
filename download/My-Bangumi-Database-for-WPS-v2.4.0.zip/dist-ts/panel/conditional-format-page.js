/**
 * @fileoverview 条件格式管理页 UI 控制器
 * @module panel/conditionalFormatPage
 * @description 「条件格式管理」独立页：任意工作表可选、规则搜索/分组/隐藏/排序/
 *   复制粘贴/编辑、默认规则集生成、应用（默认**增量**：只增改插件自己那份规则，
 *   不清除表上既有规则；另有显式「清空整表后应用」走确认弹框）。
 *
 * 本页面只做渲染与编排，判断逻辑全在纯函数引擎（conditional-format-rules.ts），宿主交互全在
 * conditional-format-apply.ts——单测覆盖在那一层，页面保持薄。
 */
import { LOG_LEVELS } from '../core/constants.js';
import { showToast } from '../ui/dialog.js';
// tOr 直连 locale-store：i18n/index 桶会经 locale-install 拉进 ts/index（模块顶层写 window），
// node 单测一 import 就 ReferenceError。别改回桶。
import { tOr } from '../i18n/locale-store.js';
import { escapeHtml, columnNumberToLetter } from '../tools/string-utilities.js';
import { BGM, bgmLog, copyTextWithResult, findHeaderRow, getApp, getColumnMap, markConditionalFormatPaneLoaded, } from '../tools/util/index.js';
import { clusterModeLabel, getClusterMode, getMergeMode, getConfig, getExportPath, getModalButtonsPosition, setConfig, setExportPath, } from '../tools/config.js';
import { APPLIED_RULES_STORE_KEY, CONDITIONAL_FORMAT_GROUP_HIGHLIGHT, CONDITIONAL_FORMAT_STORE_KEY, EXISTING_GROUPS_STORE_KEY, EXISTING_ANCHORS_STORE_KEY, anchorKeyOf, parseAnchors, parseAppliedRules, planAnchorRepair, serializeAnchors, serializeAppliedRules, toAbsoluteCell, toFullColumnRange, toFullRowRange, IMPORTED_RULE_GROUP, autoClusterGroups, buildDefaultRules, dissolveGroupMapping, filterRules, firstRowOfRange, foreignSnapshotToRule, groupRules, mergeDuplicateRules, moveGroupNear, moveItemNear, normalizeHexColor, parseExistingGroups, parseRules, parseRulesPayload, planApply, renameGroupMapping, reorderGroups, serializeExistingGroups, serializeRules, shiftFormulaRows, snapshotGroupKey, UNGROUPED_LABEL, } from './conditional-format-rules.js';
import { FOREIGN_RULE_PAGE_SIZE, buildForeignRuleGroupsHtml, buildForeignRuleHeadHtml, buildForeignRuleRowHtml, filterForeignRuleRows, filterRowsByScope, fcTypeLabel, paginate, selectionSummary, toForeignRuleRows, toggleSelection, } from './conditional-format-table.js';
import { directoryNameOf, saveTextFileWithDialog } from '../tools/save-file.js';
import { bindModalCollapse, bindModalDrag, bringModalIntoView, resetModalPosition, } from '../ui/components/modal-drag.js';
import { bindModalMaximize, bindModalResize } from '../ui/components/window-chrome.js';
import { attachDelegatedContextMenu, showContextMenu } from '../ui/components/context-menu.js';
import { createSortable } from '../ui/components/sortable-list.js';
import { bindTableResize } from '../ui/components/table-resize.js';
import { fixRule, hasBlockingIssue, inspectRule, inspectRules } from './conditional-format-check.js';
import { renderOptionPicker } from '../ui/components/option-picker.js';
import { applyConditionalFormatPlan, checkFormatConditionsReadable, deleteForeignRule, duplicateForeignRule, isFormatConditionsSupported, moveForeignRule, readForeignRules, setForeignAppliesTo, setForeignFormula, setForeignStopIfTrue, updateForeignRule, } from './conditional-format-apply.js';
import { initializeShellNav } from './shell-nav.js';
import { notifyModulesReady } from './action-buttons-gate.js';
import { initializeTheme, startThemeSync } from '../tools/theme.js';
import { initializeI18n } from '../i18n/index.js';
import { activeWorksheet, collectSheets } from '../tools/sheet-list.js';
import { mountDataContextNotice, registerTargetSheetApplier } from '../tools/data-context.js';
// ===== 常量 =====
/** 选中工作表持久化键 */
const KEY_SHEET = 'conditionalFormat.sheet.v1';
/**
 * 目标表锁定开关（`1` = 锁定）。
 *
 * 语义**不是** locked-sheet 那种索引锁，而是「兜底策略」：选中键失效时
 * （目标簿被关 / 目标表被删）不静默跳到活动表，改为提示重新选择 ——
 * 条件格式是**写操作**，应用到错表的代价比选不到表更高。
 */
const KEY_SHEET_LOCK = 'conditionalFormat.sheetLock';
/** 从工作表导入的既有规则所在分组（与 rules.ts 的 IMPORTED_RULE_GROUP 同源） */
const IMPORTED_GROUP = IMPORTED_RULE_GROUP;
const state = {
    rules: [],
    sheets: [],
    selectedKey: '',
    selectionMissing: '',
    clipboard: [],
    editingId: null,
    editingIsNew: false,
    editingTarget: 'library',
    editingExistingIndex: 0,
    editingBaseline: null,
    searchQuery: '',
    existing: [],
    existingError: null,
    existingQuery: '',
    existingPage: 1,
    existingSelection: new Set(),
    ruleSelection: new Set(),
    existingScope: 'all',
    existingGroups: {},
    existingGroupCollapsed: new Set(),
    renamingGroup: null,
    importForeignRules: [],
    importGroupCollapsed: new Set(),
    collapsedGroups: new Set(),
    ruleSortable: null,
    groupSortable: null,
    existingSortable: null,
    tableResize: { existing: null, library: null, importDialog: null, paste: null },
    tableAutoFitDone: new Set(),
};
// ===== DOM 辅助 =====
function byId(id) {
    return document.getElementById(id);
}
function selectById(id) {
    return document.getElementById(id);
}
function inputById(id) {
    return document.getElementById(id);
}
function setText(id, text) {
    const element = byId(id);
    if (element)
        element.textContent = text;
}
// ===== 工作表枚举（collectSheets / activeWorksheet 见 ../tools/sheet-list.js）=====
/** 当前选中的工作簿名（从选中表反推；选中为空时为空） */
function currentWorkbookName() {
    return selectedSheet()?.workbook ?? '';
}
/**
 * 渲染目标工作簿选择器（去重的工作簿名，保持枚举顺序）
 *
 * 选项 ≤2 用单选按钮、>10 带搜索 —— 统一走通用组件 option-picker。
 */
function renderWorkbookPicker() {
    const container = byId('conditionalFormatWorkbookPicker');
    if (!container)
        return;
    const workbookNames = [];
    for (const entry of state.sheets) {
        if (!workbookNames.includes(entry.workbook))
            workbookNames.push(entry.workbook);
    }
    renderOptionPicker(container, workbookNames.map((name) => ({ value: name, label: name })), {
        value: currentWorkbookName(),
        ariaLabel: tOr('conditionalFormat.target.workbookAria', '目标工作簿'),
        emptyText: tOr('conditionalFormat.target.noWorkbook', '（无已打开的工作簿）'),
        onChange: (workbook) => {
            onWorkbookChange(workbook);
        },
    });
}
/** 渲染目标工作表选择器（只列当前工作簿下的表） */
function renderSheetPicker() {
    const container = byId('conditionalFormatSheetPicker');
    if (!container)
        return;
    const workbook = currentWorkbookName();
    const visible = state.sheets.filter((entry) => entry.workbook === workbook);
    renderOptionPicker(container, visible.map((entry) => ({ value: entry.key, label: entry.sheet })), {
        value: state.selectedKey,
        ariaLabel: tOr('conditionalFormat.target.sheetAria', '目标工作表'),
        emptyText: tOr('conditionalFormat.target.noSheet', '（该工作簿下没有可显示的工作表）'),
        onChange: (key) => {
            onSheetChange(key);
        },
    });
    // 锁定态下选中键失效：不静默跳到别的表，用一行说明让用户自己重选
    const notice = byId('conditionalFormatSheetNotice');
    if (notice) {
        notice.hidden = state.selectionMissing === '';
        notice.textContent =
            state.selectionMissing === ''
                ? ''
                : tOr('conditionalFormat.target.missing', '⚠️ 原目标表 {sheet} 已不存在，请重新选择', {
                    sheet: state.selectionMissing,
                });
    }
}
/** 第一级：切换工作簿（原选中表仍属于新簿则保留，否则选该簿第一张） */
function onWorkbookChange(workbook) {
    const inWorkbook = state.sheets.filter((entry) => entry.workbook === workbook);
    const isStillValid = inWorkbook.some((entry) => entry.key === state.selectedKey);
    if (!isStillValid) {
        state.selectedKey = inWorkbook[0]?.key ?? '';
        setConfig(KEY_SHEET, state.selectedKey);
    }
    // 用户主动切了簿：退出「原表已不存在」状态（否则提示条会赖着不走）
    state.selectionMissing = '';
    renderSheetPicker();
    loadExistingRules();
}
/** 第二级：切换工作表 */
function onSheetChange(key) {
    state.selectedKey = key;
    state.selectionMissing = '';
    setConfig(KEY_SHEET, state.selectedKey);
    loadExistingRules();
}
function selectedSheet() {
    return state.sheets.find((entry) => entry.key === state.selectedKey) ?? null;
}
/**
 * 重新枚举并定位选中表（无历史选择时默认选中**活动工作表**）。
 *
 * 「目标表锁定」勾选时，选中键失效（目标簿被关 / 目标表被删）**不静默跳**到
 * 活动表或第一张 —— 那会让用户没注意就把条件格式应用到另一张表上。改为
 * 记录 `selectionMissing`，由 renderSheetPicker 提示重新选择。
 */
function reloadSheets() {
    try {
        state.sheets = collectSheets();
        const isSelectionValid = state.sheets.some((entry) => entry.key === state.selectedKey);
        if (!isSelectionValid && state.sheets.length > 0) {
            if (isSheetLocked()) {
                // 锁定：记住失效前选的是哪张表，供下拉里提示「原目标表 X 已不存在」
                state.selectionMissing =
                    state.selectedKey ||
                        getConfig(KEY_SHEET, '', true) ||
                        tOr('conditionalFormat.target.unknownSheet', '（未知）');
                state.selectedKey = '';
            }
            else {
                // 默认选中活动表：用户是在活动表上点开面板的，第一张往往是别的表，
                // 于是「既有规则」区显示空、而用户明明看到活动表上有规则（真机反馈）。
                // 活动表匹配不到（未打开 / 取不到）才退回首张。
                const active = activeWorksheet();
                const matched = active
                    ? state.sheets.find((entry) => entry.worksheet === active)
                    : undefined;
                const fallback = state.sheets[0];
                state.selectedKey = (matched ?? fallback)?.key ?? '';
                state.selectionMissing = '';
            }
        }
        else if (isSelectionValid) {
            state.selectionMissing = '';
        }
        renderWorkbookPicker();
        renderSheetPicker();
        // 工作表列表（或选中项）变了，既有规则快照必须跟着重读——
        // 用户要在这页上直接看到「这张表现在有什么条件格式」（真机反馈：看不到）
        loadExistingRules();
    }
    catch (error) {
        // 宿主读取失败（JSAPI 桥未就绪 / 被调速器限速）：绝不让异常冒泡到事件
        // 监听或初始化，否则整页「不能点击」。降级为「可重试」空态 + 提示。
        const message = error instanceof Error ? error.message : String(error);
        bgmLog(LOG_LEVELS.ERROR, `[conditionalFormat] 枚举工作表失败：${message}`);
        showToast(tOr('conditionalFormat.toast.loadWorkbooksFailed', '读取工作簿列表失败，请点「🔄 刷新列表」重试'), 'error');
        state.sheets = [];
        renderWorkbookPicker();
        renderSheetPicker();
    }
}
/**
 * 目标表锁定开关（`1` = 锁定）。
 *
 * 语义**不是** locked-sheet 那种索引锁，而是「兜底策略」：见 reloadSheets 注释。
 * 默认不锁，保持既有「失效即兜底到活动表」的行为。
 */
function isSheetLocked() {
    try {
        return getConfig(KEY_SHEET_LOCK, '0') === '1';
    }
    catch {
        // PluginStorage 读取抛错（桥未就绪）时按「未锁定」兜底：
        // 锁定是兜底策略，读不到时用默认行为比让绑定段崩掉好
        return false;
    }
}
/** 设置目标表锁定开关；解锁时若正处于缺失态，立刻补一次兜底定位 */
function setSheetLock(isLocked) {
    setConfig(KEY_SHEET_LOCK, isLocked ? '1' : '0');
    if (!isLocked && state.selectionMissing) {
        reloadSheets();
        return;
    }
    renderSheetPicker();
}
// ===== 工作表既有规则（只读）=====
/** 读目标工作表既有规则并渲染（表格呈现，可管理） */
function loadExistingRules() {
    const entry = selectedSheet();
    if (!entry) {
        state.existing = [];
        state.existingError = tOr('conditionalFormat.existing.noTarget', '尚未选择目标工作表');
        renderExistingRules();
        return;
    }
    const unreadable = checkFormatConditionsReadable(entry.worksheet);
    if (unreadable !== null) {
        state.existing = [];
        state.existingError = tOr('conditionalFormat.existing.unreadable', '{reason}（既有规则读不到）', { reason: unreadable });
        renderExistingRules();
        return;
    }
    try {
        state.existing = readForeignRules(entry.worksheet);
        state.existingError = null;
        // 锚定自动修复：删过行 / 列后宿主会把范围收缩或平移，这里按锚定改回原范围
        if (repairAnchors(true) > 0)
            state.existing = readForeignRules(entry.worksheet);
        // 读了多少条必须留痕：真机出现过「界面显示没有规则、用户坚称表上有 38 条」
        // 的争议，没有这行日志时双方都无法判断是 COM 没读到还是渲染丢了。
        bgmLog(LOG_LEVELS.INFO, `[conditionalFormat] 工作表「${entry.sheet}」读到 ${String(state.existing.length)} 条既有规则`);
    }
    catch (error) {
        state.existing = [];
        state.existingError = tOr('conditionalFormat.existing.readFailed', '读取失败：{error}', {
            error: error.message,
        });
    }
    // 换表 / 重读后：选中集合作废（序号是「那张表」的序号，换表即失效），
    // 不停留在越界页码（否则看到空列表，用户会以为规则没了）
    state.existingSelection = new Set();
    state.existingPage = 1;
    renderExistingRules();
}
/**
 * 渲染既有规则表格（分页 + 搜索 + 行内管理）
 *
 * ⚠️ 整个函数体包在 try 里：`setText(count)` 在 `container.innerHTML` **之前**执行，
 * 渲染中途抛异常会留下「计数已更新、列表还是上一次内容」的半截状态 ——
 * 表现为「显示 38 条却同时显示没有规则」这种自相矛盾的界面，
 * 而异常被上层调用栈吞掉，控制台之外看不出来（真机踩过）。
 * 故失败时显式渲染错误行，绝不静默保留旧内容。
 */
function renderExistingRules() {
    const container = byId('conditionalFormatExistingList');
    if (!container)
        return;
    try {
        renderExistingRulesInner(container);
    }
    catch (error) {
        container.innerHTML = `<p class="conditional-format-empty">${tOr('conditionalFormat.existing.renderFailed', '既有规则渲染失败：{error}<br>请点「重新读取」重试；持续失败请把此信息反馈给开发者。', { error: escapeHtml(error.message) })}</p>`;
        setText('conditionalFormatExistingCount', '—');
        renderExistingPagination(1, 1);
    }
}
function renderExistingRulesInner(container) {
    if (state.existingError !== null) {
        container.innerHTML = `<p class="conditional-format-empty">${escapeHtml(state.existingError)}</p>`;
        setText('conditionalFormatExistingCount', '—');
        renderExistingPagination(1, 1);
        return;
    }
    if (state.existing.length === 0) {
        // 带上工作表名：默认选中漂移时（选中了另一张表）用户能立刻看出选错了表，
        // 而不是以为「我的规则丢了」
        const selected = selectedSheet();
        const sheetLabel = selected
            ? `「${selected.sheet}」`
            : tOr('conditionalFormat.existing.currentSheet', '当前选中的工作表');
        container.innerHTML = `<p class="conditional-format-empty">${tOr('conditionalFormat.existing.emptySheet', '{sheet}上没有条件格式规则。<br>若你正在看的表上有规则，请在上方「目标工作表」里切换到它。', { sheet: escapeHtml(sheetLabel) })}</p>`;
        setText('conditionalFormatExistingCount', tOr('conditionalFormat.existing.countZero', '0 条'));
        renderExistingPagination(1, 1);
        return;
    }
    const rows = toForeignRuleRows(state.existing, state.existingSelection);
    const searched = filterForeignRuleRows(rows, state.existingQuery);
    // 「显示其格式规则」= 当前选择时，还要按选区再筛一层。
    // 选区地址读不到（没选区 / 宿主不暴露）时退化为整表，并在计数里说明 ——
    // 不静默显示全部，否则用户会以为「我框的这条列上真没有规则」。
    const selectionRange = state.existingScope === 'selection' ? currentSelectionRange() : '';
    const scoped = filterRowsByScope(searched, state.existingScope, selectionRange);
    // 有本地分组时不分页：组标题跨页断裂比不分页更难读（一表 38 条一页装得下）。
    // 分页器此时 pageCount=1 自动隐藏。
    const hasGroups = Object.keys(state.existingGroups).length > 0;
    const page = hasGroups
        ? { page: 1, pageCount: 1, items: scoped }
        : paginate(scoped, state.existingPage, FOREIGN_RULE_PAGE_SIZE);
    // 分页后页码可能被收敛（删掉一页里的全部规则后），回写 state 让翻页按钮用同一页
    state.existingPage = page.page;
    const hiddenByFilter = state.existing.length - scoped.length;
    // 拆成三步算：tOr 套 tOr 套 tOr 会触发 unicorn/max-nested-calls（上限 3 层）
    const noSelectionNote = selectionRange === '' && state.existingScope === 'selection'
        ? tOr('conditionalFormat.existing.noSelection', '，未读到选区，已按整表显示')
        : '';
    const filteredNote = hiddenByFilter > 0
        ? tOr('conditionalFormat.existing.countFiltered', '（筛出 {shown} 条{note}）', {
            shown: String(scoped.length),
            note: noSelectionNote,
        })
        : '';
    setText('conditionalFormatExistingCount', tOr('conditionalFormat.existing.count', '{total} 条{filtered}', {
        total: String(state.existing.length),
        filtered: filteredNote,
    }));
    // 一次 innerHTML 写入（表头 + 本页行）；行内事件在容器上委托，见 handleExistingTableClick
    const summary = selectionSummary(page.items);
    const rowsHtml = hasGroups
        ? buildForeignRuleGroupsHtml(page.items, state.existingGroups, state.existingGroupCollapsed)
        : page.items.map((row) => buildForeignRuleRowHtml(row)).join('');
    container.innerHTML = `${buildForeignRuleHeadHtml(summary.isAllSelected)}${rowsHtml}`;
    // 全选复选框的三态：HTML 属性表达不了「部分选中」，必须走 DOM property。
    // 漏了这一步，半选时全选框显示未勾选，用户会以为「什么都没选」。
    const selectAll = container.querySelector('input[data-action="select-all"]');
    if (selectAll)
        selectAll.indeterminate = summary.isSomeSelected;
    renderExistingBatchBar();
    renderExistingPagination(page.page, page.pageCount);
    // 浮动窗口顶栏的 ↑↓ / 删除要跟随选中数放开 / 禁用：
    // 按钮在 DOM 搬家范围之外，只能在这里统一同步（渲染的终点）。
    syncFloatToolbarState();
    // 拖拽排序：DOM 换了新节点，重新扫描补 tabindex / aria（键盘排序的前提）
    state.existingSortable?.refresh();
    // 列宽/行高把手：表头是新节点，每次渲染都要重插（decorate 幂等）
    state.tableResize.existing?.decorate();
    maybeAutoFitTable('existing');
}
/** 浮动窗口顶栏按钮的可用性（选中数为 0 时 ↑↓ / 删除禁用） */
function syncFloatToolbarState() {
    const hasSelection = state.existingSelection.size > 0;
    const setDisabled = (id) => {
        const button = byId(id);
        if (button instanceof HTMLButtonElement)
            button.disabled = !hasSelection;
    };
    setDisabled('conditionalFormatFloatUp');
    setDisabled('conditionalFormatFloatDown');
    setDisabled('conditionalFormatFloatDelete');
}
/**
 * 渲染批量操作条（选中 N 条时才出现）
 *
 * 没有选中时整条隐藏：平时屏幕上只留「全选」一个入口，不添乱。
 * 按钮全部 `data-batch-action`，与表格行内按钮一样走容器事件委托。
 */
function renderExistingBatchBar() {
    const bar = byId('conditionalFormatExistingBatchBar');
    if (!bar)
        return;
    const selectedCount = state.existingSelection.size;
    if (selectedCount === 0) {
        bar.replaceChildren();
        bar.classList.remove('is-visible');
        return;
    }
    bar.classList.add('is-visible');
    const selectedIndices = [...state.existingSelection].sort((a, b) => a - b);
    const rebuildableCount = selectedIndices.filter((index) => {
        const snapshot = state.existing[index - 1];
        return snapshot?.kind === 'expression' && snapshot.formula !== '';
    }).length;
    bar.innerHTML = `
    <span class="conditional-format-batch-count">${tOr('conditionalFormat.batch.selected', '已选 {count} 条', { count: String(selectedCount) })}</span>
    <button type="button" class="bgm-btn small" data-batch-action="group" title="${tOr('conditionalFormat.batch.groupTitle', '把所选规则归入一个分组（本地视图分组，可收起展开；导入时组名会带进规则库）')}">${tOr('conditionalFormat.batch.group', '🏷 归入分组')}</button>
    <button type="button" class="bgm-btn small" data-batch-action="edit" title="${tOr('conditionalFormat.batch.editTitle', '批量修改所选规则的应用范围 / 公式 / 颜色（可统一为某一条已有的值，也可自己填；改完立刻写表）')}">${tOr('conditionalFormat.batch.edit', '✎ 批量修改')}</button>
    <button type="button" class="bgm-btn small" data-batch-action="import" ${rebuildableCount === 0 ? 'disabled' : ''} title="${rebuildableCount === 0
        ? tOr('conditionalFormat.toast.importNoFormulaSelected', '所选规则里没有可导入的公式类规则')
        : tOr('conditionalFormat.batch.importCount', '导入 {count} 条到规则库', {
            count: String(rebuildableCount),
        })}">${tOr('conditionalFormat.batch.importToLibrary', '⤵ 导入规则库')}</button>
    <button type="button" class="bgm-btn small" data-batch-action="export" title="${tOr('conditionalFormat.batch.exportTitle', '把所选规则导出为 JSON 文件（另存为对话框选保存位置）')}">${tOr('conditionalFormat.batch.export', '📤 导出所选')}</button>
    <button type="button" class="bgm-btn small danger" data-batch-action="delete" title="${tOr('conditionalFormat.batch.deleteTitle', '从工作表删除所选规则')}">${tOr('conditionalFormat.batch.delete', '✕ 批量删除')}</button>
    <button type="button" class="bgm-btn small" data-batch-action="clear" title="${tOr('conditionalFormat.batch.clearTitle', '取消选择')}">${tOr('conditionalFormat.batch.clear', '取消选择')}</button>`;
}
/** 渲染既有规则表格的分页条（页码 + 上下页） */
function renderExistingPagination(current, pageCount) {
    const container = byId('conditionalFormatExistingPager');
    if (!container)
        return;
    if (pageCount <= 1) {
        container.replaceChildren();
        return;
    }
    container.innerHTML = `
    <button type="button" class="bgm-btn small" data-page-action="prev" ${current <= 1 ? 'disabled' : ''}>${tOr('conditionalFormat.pager.prev', '‹ 上一页')}</button>
    <span class="conditional-format-pager-label">${tOr('conditionalFormat.pager.label', '第 {current} / {total} 页', { current: String(current), total: String(pageCount) })}</span>
    <button type="button" class="bgm-btn small" data-page-action="next" ${current >= pageCount ? 'disabled' : ''}>${tOr('conditionalFormat.pager.next', '下一页 ›')}</button>`;
}
// ===== 既有规则的行内操作与批量操作 =====
/**
 * 既有规则表格的事件委托
 *
 * **不给每行绑监听器**：实测用户的表有 347 条既有规则，逐行绑就是 347×N 个
 * 监听器 + 347 次 querySelectorAll，翻页时还要手动解绑。容器上代理一次即可。
 * 行的 1 基序号从 `data-row-index` 取（与 FormatConditions.Item 下标一致）。
 */
function handleExistingTableClick(event) {
    const target = event.target;
    if (!target)
        return;
    const pageButton = target.closest('[data-page-action]');
    if (pageButton) {
        const direction = pageButton.dataset.pageAction === 'prev' ? -1 : 1;
        state.existingPage = Math.max(1, state.existingPage + direction);
        renderExistingRules();
        return;
    }
    // 批量操作条（在表格容器外，但同属这个浮动面板，故一并在这里分流）
    const batchButton = target.closest('[data-batch-action]');
    if (batchButton) {
        handleBatchAction(batchButton.dataset.batchAction ?? '');
        return;
    }
    // 分组的收起/展开（标题上的 ▾/▸）：只改视图折叠状态，不碰规则本身
    const groupToggle = target.closest('[data-action="toggle-existing-group"]');
    if (groupToggle) {
        const group = groupToggle.closest('[data-group]')?.dataset.group ?? '';
        if (group !== '') {
            const next = new Set(state.existingGroupCollapsed);
            if (next.has(group))
                next.delete(group);
            else
                next.add(group);
            state.existingGroupCollapsed = next;
            renderExistingRules();
        }
        return;
    }
    // 组标题 ✎：重命名整组（弹窗预填旧组名，确认后组内全部规则换组名）
    const renameGroupButton = target.closest('[data-action="rename-existing-group"]');
    if (renameGroupButton) {
        const group = renameGroupButton.closest('[data-group]')?.dataset.group ?? '';
        if (group !== '')
            openRenameGroupModal(group);
        return;
    }
    // 组标题 ✕：解散整组（规则回「未分组」，不从工作表删除）
    const dissolveGroupButton = target.closest('[data-action="dissolve-existing-group"]');
    if (dissolveGroupButton) {
        const group = dissolveGroupButton.closest('[data-group]')?.dataset.group ?? '';
        if (group !== '')
            dissolveExistingGroupLocal(group);
        return;
    }
    // 组标题 ☑：全选 / 取消本组（momo：组内也要能全选）
    const pickGroupButton = target.closest('[data-action="pick-existing-group"]');
    if (pickGroupButton) {
        const group = pickGroupButton.closest('[data-group]')?.dataset.group ?? '';
        if (group !== '')
            toggleExistingGroupSelection(group);
        return;
    }
    // 组标题 📤：导出本组规则（选保存位置）
    const exportGroupButton = target.closest('[data-action="export-existing-group"]');
    if (exportGroupButton) {
        const group = exportGroupButton.closest('[data-group]')?.dataset.group ?? '';
        if (group !== '')
            exportExistingGroup(group);
        return;
    }
    // 组标题「列 / 行」：把本组规则的应用范围钉成整列 / 整行（删除行列后自动恢复）
    const anchorGroupButton = target.closest('[data-action="anchor-existing-group"], [data-action="anchor-existing-group-rows"]');
    if (anchorGroupButton) {
        const group = anchorGroupButton.closest('[data-group]')?.dataset.group ?? '';
        const axis = anchorGroupButton.dataset.action === 'anchor-existing-group-rows' ? 'row' : 'column';
        if (group !== '')
            anchorExistingGroup(group, axis);
        return;
    }
    // 组标题 🗑：从工作表删除本组全部规则
    const groupDeleteButton = target.closest('[data-action="delete-existing-group"]');
    if (groupDeleteButton) {
        const group = groupDeleteButton.closest('[data-group]')?.dataset.group ?? '';
        if (group !== '')
            deleteExistingGroup(group);
        return;
    }
    // 行内编辑：点「应用于 / 公式」单元格原地变输入框（momo：要能直接改）。
    // 放在 button 分支之前：这两个单元格不是 button，走 button 分支会直接 return。
    const editable = target.closest('.conditional-format-cell-editable');
    if (editable) {
        const editRow = editable.closest('[data-row-index]');
        const editIndex = Number(editRow?.dataset.rowIndex ?? '0');
        if (!Number.isSafeInteger(editIndex) || editIndex < 1)
            return;
        const { action } = editable.dataset;
        if (action === 'edit-range')
            startCellEdit(editable, editIndex, 'range');
        else if (action === 'edit-formula')
            startCellEdit(editable, editIndex, 'formula');
        return;
    }
    const button = target.closest('button[data-action]');
    if (!button)
        return;
    const row = button.closest('[data-row-index]');
    const index = Number(row?.dataset.rowIndex ?? '0');
    if (!Number.isSafeInteger(index) || index < 1)
        return;
    switch (button.dataset.action) {
        case 'import': {
            importForeignRule(index);
            break;
        }
        case 'delete': {
            deleteForeignRuleRow(index);
            break;
        }
        case 'edit': {
            openExistingRuleEditor(index);
            break;
        }
        // 点格式预览色块：与 ✎ 同一个弹窗（「看到样式不对就点样式」）
        case 'edit-format': {
            openExistingRuleEditor(index);
            break;
        }
        case 'duplicate': {
            openDuplicateModal(index);
            break;
        }
        case 'up': {
            moveForeignRuleRow(index, -1);
            break;
        }
        case 'down': {
            moveForeignRuleRow(index, 1);
            break;
        }
        default: {
            break;
        }
    }
}
/** 批量操作条的分流（归入分组 / 导入 / 导出 / 删除 / 取消选择） */
function handleBatchAction(action) {
    switch (action) {
        case 'group': {
            openGroupNameModal();
            break;
        }
        case 'edit': {
            openBatchEdit('worksheet');
            break;
        }
        case 'import': {
            batchImportForeignRules();
            break;
        }
        case 'export': {
            batchExportForeignRules();
            break;
        }
        case 'delete': {
            batchDeleteForeignRules();
            break;
        }
        case 'clear': {
            state.existingSelection = new Set();
            renderExistingRules();
            break;
        }
        default: {
            break;
        }
    }
}
/**
 * 批量导出所选既有规则为 JSON（选保存位置）
 *
 * 快照转规则与「导入」同一套判据（foreignSnapshotToRule）：不可重建的类型
 * 逐条跳过并在结果里报数——不静默丢。id 用 nextId 现生成（导出文件只是
 * 快照，导入时会再生成新 id，不与库内既有规则撞）。
 */
function batchExportForeignRules() {
    const indices = [...state.existingSelection].sort((a, b) => a - b);
    const rules = [];
    let skipped = 0;
    for (const index of indices) {
        const snapshot = state.existing[index - 1];
        if (snapshot) {
            const rule = foreignSnapshotToRule(snapshot, nextId, groupOfSnapshot(snapshot));
            if (rule)
                rules.push(rule);
            else
                skipped += 1;
        }
    }
    if (rules.length === 0) {
        showToast(tOr('conditionalFormat.toast.exportNoFormulaSelected', '所选规则里没有可导出的公式类规则'), 'warn');
        return;
    }
    saveRulesJson(rules, '所选规则', tOr('conditionalFormat.export.labelSelected', '所选规则'));
    if (skipped > 0) {
        showToast(tOr('conditionalFormat.toast.exportSkippedTypes', '{count} 条类型不支持，未包含在导出文件里', {
            count: String(skipped),
        }), 'info');
    }
}
/**
 * 取一个分组下所有行的 1 基序号（从 DOM 读：分组是视图层概念，
 * state 里只有 existingGroups 的 key→组名映射，行属于哪组看渲染结果）
 */
function existingGroupIndices(group) {
    const container = document.querySelector(`[data-group="${CSS.escape(group)}"]`);
    if (!container)
        return [];
    const indices = [];
    for (const row of container.querySelectorAll('[data-row-index]')) {
        const index = Number(row.dataset.rowIndex ?? '0');
        if (Number.isSafeInteger(index) && index >= 1)
            indices.push(index);
    }
    return indices.sort((a, b) => a - b);
}
/** 组标题 ☑：组内已全勾 → 取消本组；否则补全本组 */
function toggleExistingGroupSelection(group) {
    const indices = existingGroupIndices(group);
    if (indices.length === 0) {
        showToast(tOr('conditionalFormat.toast.groupNoSelectable', '本组没有可勾选的规则'), 'warn');
        return;
    }
    const next = new Set(state.existingSelection);
    const isAllPicked = indices.every((index) => next.has(index));
    for (const index of indices) {
        if (isAllPicked)
            next.delete(index);
        else
            next.add(index);
    }
    state.existingSelection = next;
    renderExistingRules();
}
/** 组标题 📤：导出本组快照转规则（与批量条导出所选同一通道） */
function exportExistingGroup(group) {
    const indices = existingGroupIndices(group);
    const rules = [];
    let skipped = 0;
    for (const index of indices) {
        const snapshot = state.existing[index - 1];
        if (snapshot) {
            const rule = foreignSnapshotToRule(snapshot, nextId, groupOfSnapshot(snapshot));
            if (rule)
                rules.push(rule);
            else
                skipped += 1;
        }
    }
    if (rules.length === 0) {
        showToast(tOr('conditionalFormat.toast.groupExportNoFormula', '本组没有可导出的公式类规则'), 'warn');
        return;
    }
    saveRulesJson(rules, `「${group}」分组`, tOr('conditionalFormat.export.labelGroup', '「{group}」分组', { group }));
    if (skipped > 0) {
        showToast(tOr('conditionalFormat.toast.exportSkippedTypes', '{count} 条类型不支持，未包含在导出文件里', {
            count: String(skipped),
        }), 'info');
    }
}
/**
 * 组标题 🗑：从工作表删除本组全部规则
 *
 * 与 batchDeleteForeignRules 同口径：**逆序删**（删前面的行会让后面的
 * FormatConditions.Item 下标漂移）。删除的是工作表规则，组的本地映射
 * （existingGroups）保留——组里没规则了自然不再显示。
 */
function deleteExistingGroup(group) {
    const entry = selectedSheet();
    if (!entry)
        return;
    const indices = existingGroupIndices(group);
    if (indices.length === 0) {
        showToast(tOr('conditionalFormat.toast.groupNoDeletable', '本组没有可删除的规则'), 'warn');
        return;
    }
    // BGM.Dialog.confirm（项目范式，非 window.confirm）：不可撤销操作必须确认
    BGM.Dialog.confirm(tOr('conditionalFormat.groupDelete.confirm', '将从工作表删除「{group}」分组的全部 {count} 条规则，且不可撤销。确定？', { group, count: String(indices.length) }), (isConfirmed) => {
        if (!isConfirmed)
            return;
        // 逆序删：删前面的行会让后面的 FormatConditions.Item 下标漂移
        const descending = [...indices].sort((a, b) => b - a);
        let succeeded = 0;
        const failures = [];
        for (const index of descending) {
            const result = deleteForeignRule(entry.worksheet, index);
            if (result.ok)
                succeeded += 1;
            else {
                failures.push(tOr('conditionalFormat.toast.failureItem', '第 {index} 条：{error}', {
                    index: String(index),
                    error: result.error,
                }));
            }
        }
        const removed = new Set(indices);
        state.existingSelection = new Set([...state.existingSelection].filter((index) => !removed.has(index)));
        if (failures.length > 0) {
            showToast(tOr('conditionalFormat.toast.deleteFailedCount', '已删除 {ok} 条，{failed} 条失败（{reason}）', {
                ok: String(succeeded),
                failed: String(failures.length),
                reason: failures[0] ?? tOr('conditionalFormat.toast.unknownReason', '未知原因'),
            }), 'error');
        }
        else {
            showToast(tOr('conditionalFormat.toast.groupDeleted', '已删除「{group}」分组 {count} 条规则', {
                group,
                count: String(succeeded),
            }), 'success');
        }
        loadExistingRules();
    }, tOr('conditionalFormat.groupDelete.title', '删除整组规则？'));
}
/**
 * 打开「归入分组」组名输入弹窗（批量条入口：作用于勾选的行）
 *
 * 预填：所选规则已全部属于同一组时，把该组名填进去（改名场景直接改）；
 * 跨组多选时留空（用户要输新名）。
 */
function openGroupNameModal() {
    const indices = [...state.existingSelection].sort((a, b) => a - b);
    if (indices.length === 0)
        return;
    const names = new Set();
    for (const index of indices) {
        const snapshot = state.existing[index - 1];
        if (snapshot) {
            const group = state.existingGroups[snapshotGroupKey(snapshot)];
            if (group !== undefined)
                names.add(group);
        }
    }
    state.renamingGroup = null;
    const input = inputById('conditionalFormatGroupName');
    if (input) {
        const onlyName = names.size === 1 ? names.values().next().value : undefined;
        input.value = typeof onlyName === 'string' ? onlyName : '';
    }
    setText('conditionalFormatGroupLabel', tOr('conditionalFormat.groupAssign.label', '归入分组'));
    setText('conditionalFormatGroupHint', tOr('conditionalFormat.groupAssign.hint', '把所选的 {count} 条规则归入同一分组。分组只影响本页展示（可收起展开），并会在导入规则库时作为组名带过去。', { count: String(indices.length) }));
    showGroupNameMask();
    input?.focus();
}
/**
 * 打开「重命名分组」弹窗（组标题 ✎ 入口：作用于组内全部规则）
 *
 * 与「归入分组」共用弹窗 DOM，靠 state.renamingGroup 分流；预填旧组名，
 * 计数给**整组**规则数（不是当前可见行数——搜索过滤不改变分组全集）。
 */
function openRenameGroupModal(group) {
    const count = Object.values(state.existingGroups).filter((value) => value === group).length;
    if (count === 0) {
        showToast(tOr('conditionalFormat.toast.groupMissing', '分组不存在，可能已被解散'), 'warn');
        return;
    }
    state.renamingGroup = group;
    const input = inputById('conditionalFormatGroupName');
    if (input)
        input.value = group;
    setText('conditionalFormatGroupLabel', tOr('conditionalFormat.groupRename.label', '重命名分组'));
    setText('conditionalFormatGroupHint', tOr('conditionalFormat.groupRename.hint', '分组「{group}」下有 {count} 条规则，将全部改用新组名。分组只影响本页展示，不会改写工作表。', { group, count: String(count) }));
    showGroupNameMask();
    input?.focus();
}
/** 显示组名弹窗（锚定 + 锁定背景滚动 + 拉回可见区，三个模态框同口径） */
function showGroupNameMask() {
    const mask = byId('conditionalFormatGroupMask');
    const modal = mask?.querySelector('.conditional-format-modal');
    if (mask) {
        if (modal) {
            resetModalPosition(modal);
            applyModalButtonsPosition(modal);
        }
        anchorModalMask(mask);
        mask.style.display = 'flex';
        if (modal)
            bringModalIntoView(mask, modal);
    }
    lockModalScroll();
}
function closeGroupNameModal() {
    const mask = byId('conditionalFormatGroupMask');
    // 没开 = no-op：Esc 块连调五个 close，没开的弹窗不能动共享的滚动锁计数
    // （modalScrollLockCount 是计数式；空关一次就把别的弹窗的锁解掉了）
    if (mask?.style.display === 'none')
        return;
    if (mask) {
        mask.style.display = 'none';
    }
    state.renamingGroup = null;
    unlockModalScroll();
}
/**
 * 确定归组 / 重命名：写映射 → 持久化 → 重渲染（组名会随导入带进规则库）
 *
 * 两条路径由 state.renamingGroup 分流：
 * - 重命名模式：renameGroupMapping 按**组名**换掉组内全部规则的组名；
 * - 归组模式：把勾选的序号写进映射（原行为）。
 */
function confirmGroupName() {
    const name = inputById('conditionalFormatGroupName')?.value.trim() ?? '';
    if (name === '') {
        showToast(tOr('conditionalFormat.toast.groupNameEmpty', '分组名不能为空'), 'warn');
        return;
    }
    if (state.renamingGroup !== null) {
        // 先取局部常量：state.renamingGroup 是可变属性，TS 的窄化不会传进下面的
        // 闭包（filter 回调里又变成 string | null）；closeGroupNameModal 也会把它清空
        const oldName = state.renamingGroup;
        const renamed = renameGroupMapping(state.existingGroups, oldName, name);
        if (renamed === null) {
            closeGroupNameModal();
            showToast(tOr('conditionalFormat.toast.groupMissing', '分组不存在，可能已被解散'), 'warn');
            return;
        }
        state.existingGroups = renamed;
        persistExistingGroups();
        // 折叠集合里的旧名作废（新组默认展开）：不清的话下次渲染旧名永远
        // 匹配不上，用户点展开也没反应
        state.existingGroupCollapsed = new Set([...state.existingGroupCollapsed].filter((group) => group !== oldName));
        closeGroupNameModal();
        renderExistingRules();
        showToast(tOr('conditionalFormat.toast.groupRenamed', '分组已重命名为「{name}」', {
            name,
        }), 'success');
        return;
    }
    const indices = [...state.existingSelection].sort((a, b) => a - b);
    const groups = { ...state.existingGroups };
    let count = 0;
    for (const index of indices) {
        const snapshot = state.existing[index - 1];
        if (snapshot) {
            groups[snapshotGroupKey(snapshot)] = name;
            count += 1;
        }
    }
    state.existingGroups = groups;
    persistExistingGroups();
    closeGroupNameModal();
    renderExistingRules();
    showToast(tOr('conditionalFormat.toast.groupAssigned', '已把 {count} 条规则归入「{name}」', {
        count: String(count),
        name,
    }), 'success');
}
/**
 * 解散一个分组（组标题 ✕ 入口）
 *
 * 只清视图层映射：组内规则回「未分组」桶，**不从工作表删除任何规则**
 * （dissolveGroupMapping 的语义，弹窗标题/按钮文案都要说清）。
 */
function dissolveExistingGroupLocal(group) {
    const next = dissolveGroupMapping(state.existingGroups, group);
    if (next === null) {
        showToast(tOr('conditionalFormat.toast.groupMissing', '分组不存在，可能已被解散'), 'warn');
        return;
    }
    state.existingGroups = next;
    persistExistingGroups();
    state.existingGroupCollapsed = new Set([...state.existingGroupCollapsed].filter((collapsed) => collapsed !== group));
    renderExistingRules();
    showToast(
    // 「未分组」是数据契约里的真实组名（UNGROUPED_LABEL），当变量传而不是写死在译文里，
    // 否则英文用户会看到 “Ungrouped”，而列表上那一组仍叫「未分组」。
    tOr('conditionalFormat.toast.groupDissolved', '已解散分组「{group}」，规则回「{ungrouped}」', {
        group,
        ungrouped: UNGROUPED_LABEL,
    }), 'success');
}
/**
 * 自动聚类：按设置页选定的口径重算所有分组
 *
 * 覆盖现有映射（含手动归的组）——自动聚类是「重来一遍」的语义，
 * 在 toast 里明说口径与覆盖了几组，避免用户以为手动分组被合并。
 * 口径本身在设置页「条件格式」里配置（按公式 / 按范围+公式 / 按列 / 按行），
 * 本页每次点击现读，改完口径不必重启插件。
 */
function autoClusterExistingGroups() {
    if (state.existing.length === 0) {
        showToast(tOr('conditionalFormat.toast.noExistingRules', '当前表没有既有规则'), 'info');
        return;
    }
    const mode = getClusterMode(true);
    state.existingGroups = autoClusterGroups(state.existing, mode);
    persistExistingGroups();
    state.existingGroupCollapsed = new Set();
    renderExistingRules();
    const groupCount = new Set(Object.values(state.existingGroups)).size;
    showToast(tOr('conditionalFormat.toast.autoClustered', '已按「{mode}」聚成 {count} 组（覆盖了原分组）', {
        mode: clusterModeLabel(mode),
        count: String(groupCount),
    }), 'success');
}
/**
 * 合并重复项：把「同公式 + 同列」的多条单行既有规则并成一条
 *
 * 只做两件事：算出合并结果 + 把结果**写进规则库**（store），不直接改工作表。
 * 原因：写工作表要走「应用与修复」那条唯一链路（指纹比对 / 增量写入 / 回读校验），
 * 在这里另写一份会绕过它的去重与校验逻辑，容易悄悄丢规则或叠出重复规则。
 * 用户点一次「应用条件格式」后，工作表上的重复单行规则就被合并后的规则取代。
 *
 * 口径由设置页「条件格式 → 合并重复项口径」决定（仅连续行 / 强行并成一块）。
 */
function mergeExistingDuplicates() {
    if (state.existing.length === 0) {
        showToast(tOr('conditionalFormat.toast.noExistingRules', '当前表没有既有规则'), 'info');
        return;
    }
    const mode = getMergeMode(true);
    const result = mergeDuplicateRules(state.existing, mode);
    if (result.removedCount === 0) {
        showToast(tOr('conditionalFormat.toast.noMergeable', '没有可合并的单行重复规则（需要同公式、同列且为单行范围）'), 'info');
        return;
    }
    // 快照 → 规则库条目：沿用「导入既有规则」同一条转换路径，避免两套映射
    const stamp = Date.now();
    const imported = [];
    for (const [index, snapshot] of result.rules.entries()) {
        const rule = foreignSnapshotToRule(snapshot, () => `merge-${String(stamp)}-${String(index)}`);
        if (rule !== null)
            imported.push(rule);
    }
    state.rules = [...state.rules, ...imported];
    persistRules();
    renderRuleList();
    showToast(tOr('conditionalFormat.toast.merged', '已把 {from} 条合并为 {to} 条并加入规则库（口径：{mode}）；点「应用与修复」写回工作表', {
        from: String(state.existing.length),
        to: String(result.rules.length),
        mode: mode === 'union'
            ? tOr('conditionalFormat.toast.mergeModeUnion', '强行并成一块')
            : tOr('conditionalFormat.toast.mergeModeContiguous', '仅连续行'),
    }), 'success');
    bgmLog(LOG_LEVELS.INFO, `[conditionalFormat] 合并重复项: ${String(result.removedCount)} 条 → ${String(result.rules.length)} 条（${mode}）`);
}
/** 读锚定表（坏数据当空） */
function readAnchors() {
    return parseAnchors(getConfig(EXISTING_ANCHORS_STORE_KEY, '', true));
}
/**
 * 锚定一个分组的全部规则
 *
 * 锚定的是「应用范围」：把这些规则当前的 range 记下来，之后删行 / 删列导致宿主
 * 收缩或平移范围时，{@link repairAnchors} 会把范围改回锚定值 —— 这就是用户要的
 * 「锚定后删除行列不影响条件格式」。
 *
 * @param axis `column` = 整列（`$J:$J`，增删行免疫）；`row` = 整行（`$5:$5`，增删列免疫）
 */
function anchorExistingGroup(group, axis = 'column') {
    const entry = selectedSheet();
    const anchors = readAnchors();
    const toWholeAxis = axis === 'row' ? toFullRowRange : toFullColumnRange;
    const axisLabel = axis === 'row'
        ? tOr('conditionalFormat.toast.axisRow', '整行')
        : tOr('conditionalFormat.toast.axisColumn', '整列');
    // axis=row 时免疫的是「列」，反之是「行」——与 axisLabel 相反，别顺手统一
    const immuneLabel = axis === 'row'
        ? tOr('conditionalFormat.toast.axisColumnShort', '列')
        : tOr('conditionalFormat.toast.axisRowShort', '行');
    let count = 0;
    for (const [index, snapshot] of state.existing.entries()) {
        // 与渲染同口径（映射缺失 = 未分组）：直接拿映射值比「未分组」永远不相等，
        // 未分组那一组的锚定按钮会静默失效（count 恒 0，只弹「没有可锚定的规则」）
        const ruleGroup = state.existingGroups[snapshotGroupKey(snapshot)] ?? UNGROUPED_LABEL;
        const isInGroup = ruleGroup === group;
        const wholeAxisRange = isInGroup && snapshot.formula !== '' && snapshot.range !== ''
            ? toWholeAxis(snapshot.range)
            : null;
        if (wholeAxisRange !== null) {
            // 锚定 = 把应用范围改写为整列（$J:$J）/ 整行（$5:$5），公式不动
            anchors[anchorKeyOf(snapshot)] = wholeAxisRange;
            count += 1;
            // 立刻写回工作表：用户要的是「现在就不受行列增删影响」，不是等下次
            if (entry !== null)
                setForeignAppliesTo(entry.worksheet, index + 1, wholeAxisRange);
        }
    }
    if (count === 0) {
        showToast(tOr('conditionalFormat.toast.groupNoAnchorable', '本组没有可锚定的规则（需要公式与范围都能读到）'), 'info');
        return;
    }
    if (!setConfig(EXISTING_ANCHORS_STORE_KEY, serializeAnchors(anchors))) {
        showToast(tOr('conditionalFormat.toast.anchorSaveFailed', '锚定保存失败'), 'error');
        return;
    }
    bgmLog(LOG_LEVELS.INFO, `[conditionalFormat] 已锚定分组「${group}」共 ${String(count)} 条规则（${axisLabel}）`);
    loadExistingRules();
    showToast(tOr('conditionalFormat.toast.anchored', '已锚定 {count} 条规则：应用范围改为{axis}，{immune}增删不再影响', {
        count: String(count),
        axis: axisLabel,
        immune: immuneLabel,
    }), 'success');
}
/**
 * 固定单元格：把选中的规则（没选就全部）的应用范围钉成**一个单元格**
 *
 * 与「锚定整列」的区别：整列范围怕删列，单元格范围怕删行 —— 固定就是把
 * 「只认这个单元格号」写死，之后删行删列都由 {@link repairAnchors} 改回该地址。
 * 地址由用户输入（`J5` / `$J$5` 都认），落盘统一成绝对引用。
 */
function fixRulesToCell() {
    const entry = selectedSheet();
    if (entry === null || state.existing.length === 0) {
        showToast(tOr('conditionalFormat.toast.noExistingRules', '当前表没有既有规则'), 'info');
        return;
    }
    // eslint-disable-next-line no-alert -- 只有一个单元格地址要填，用原生 prompt 比再搭一个模态框更轻
    const input = window.prompt(tOr('conditionalFormat.fixCell.prompt', '要固定到哪个单元格？（例如 J5）'), '');
    if (input === null)
        return;
    const cell = toAbsoluteCell(input);
    if (cell === null) {
        showToast(tOr('conditionalFormat.toast.cellAddressInvalid', '单元格地址无法识别，请输入类似 J5 的形式'), 'warn');
        return;
    }
    const targets = state.existingSelection.size > 0
        ? [...state.existingSelection].map((index) => index - 1)
        : state.existing.map((_snapshot, index) => index);
    const anchors = readAnchors();
    let count = 0;
    for (const index of targets) {
        const snapshot = state.existing[index];
        if (snapshot !== undefined && snapshot.formula !== '') {
            anchors[anchorKeyOf(snapshot)] = cell;
            if (setForeignAppliesTo(entry.worksheet, index + 1, cell).ok)
                count += 1;
        }
    }
    if (count === 0) {
        showToast(tOr('conditionalFormat.toast.fixNoWritable', '固定失败：没有可写入的规则'), 'error');
        return;
    }
    setConfig(EXISTING_ANCHORS_STORE_KEY, serializeAnchors(anchors));
    bgmLog(LOG_LEVELS.INFO, `[conditionalFormat] 已把 ${String(count)} 条规则固定到 ${cell}`);
    loadExistingRules();
    showToast(tOr('conditionalFormat.toast.fixedToCell', '已固定 {count} 条规则到 {cell}：删行删列后仍只作用于该单元格', {
        count: String(count),
        cell,
    }), 'success');
}
/**
 * 按锚定表修复范围
 * @param isAuto - 自动修复（读取后触发）时不弹成功 toast，避免每次换表都吵
 * @returns 实际写回的条数
 */
function repairAnchors(isAuto) {
    const entry = selectedSheet();
    const anchors = readAnchors();
    if (!entry || Object.keys(anchors).length === 0) {
        if (!isAuto)
            showToast(tOr('conditionalFormat.toast.noAnchors', '还没有锚定任何规则'), 'info');
        return 0;
    }
    const plan = planAnchorRepair(state.existing, anchors);
    if (plan.repairs.length === 0) {
        if (!isAuto)
            showToast(tOr('conditionalFormat.toast.anchorsAllCorrect', '所有锚定规则的范围都正确，无需修复'), 'info');
        return 0;
    }
    let repaired = 0;
    for (const repair of plan.repairs) {
        const result = setForeignAppliesTo(entry.worksheet, repair.index + 1, repair.range);
        if (result.ok)
            repaired += 1;
        else
            bgmLog(LOG_LEVELS.WARN, `[conditionalFormat] 锚定修复失败（第 ${String(repair.index + 1)} 条）：${result.error}`);
    }
    bgmLog(LOG_LEVELS.INFO, `[conditionalFormat] 按锚定恢复 ${String(repaired)} 条规则范围（自动=${String(isAuto)}）`);
    if (repaired > 0) {
        showToast(tOr('conditionalFormat.toast.anchorsRepaired', '已按锚定恢复 {count} 条规则的应用范围', {
            count: String(repaired),
        }), isAuto ? 'info' : 'success');
    }
    else if (!isAuto) {
        showToast(tOr('conditionalFormat.toast.anchorRepairFailed', '锚定恢复失败：当前 WPS 版本不支持改应用范围'), 'error');
    }
    return repaired;
}
/** 清除所有分组：回到平铺分页视图 */
function clearExistingGroups() {
    if (Object.keys(state.existingGroups).length === 0) {
        showToast(tOr('conditionalFormat.toast.noGroups', '当前没有分组'), 'info');
        return;
    }
    state.existingGroups = {};
    persistExistingGroups();
    state.existingGroupCollapsed = new Set();
    renderExistingRules();
    showToast(tOr('conditionalFormat.toast.groupsCleared', '已清除全部分组'), 'success');
}
/** 快照在既有规则表格里的归组（没归过 → 默认「导入的规则」） */
function groupOfSnapshot(snapshot) {
    return state.existingGroups[snapshotGroupKey(snapshot)] ?? IMPORTED_RULE_GROUP;
}
/**
 * 行内编辑改了公式/范围后，把分组映射的 key 迁到新 key
 *
 * key 由「公式 + 范围」组成，字段一改旧 key 就失配——不迁移的话规则会
 * 突然掉进「未分组」。迁移后组名跟着规则走。
 */
function migrateExistingGroupKey(oldKey, nextKey) {
    const group = state.existingGroups[oldKey];
    if (group === undefined || oldKey === nextKey)
        return;
    // 不用 delete：no-dynamic-delete 禁动态键删除。filter 重建一份更直白
    const groups = Object.fromEntries(Object.entries(state.existingGroups).filter(([key]) => key !== oldKey));
    groups[nextKey] = group;
    state.existingGroups = groups;
    persistExistingGroups();
}
/**
 * 批量导入所选既有规则到规则库（表格勾选入口）
 *
 * 与导入弹框共用 {@link importSnapshots}：两条入口一套导入逻辑，
 * 不各写一份（否则跳过计数 / 持久化 / 提示必然漂移）。
 */
function batchImportForeignRules() {
    importSnapshots(state.existing, [...state.existingSelection].sort((a, b) => a - b));
    state.existingSelection = new Set();
    renderExistingRules();
}
/**
 * 批量删除所选既有规则
 *
 * ⚠️ **必须倒序删**：删除单条会让后续规则的序号整体前移（`Item(i)` 变成 `Item(i-1)`）。
 * 正序删会「删着删着就错位」——第 3 条删掉后，原来的第 5 条变成第 4 条，
 * 而循环手里的 i 已经走到 5，于是删错了对象（真机踩过这个坑）。
 * 倒序（从大下标往小下标）则被删项后面的序号不受影响。
 */
function batchDeleteForeignRules() {
    const entry = selectedSheet();
    if (!entry)
        return;
    const indices = [...state.existingSelection].sort((a, b) => b - a);
    let succeeded = 0;
    const failures = [];
    for (const index of indices) {
        const result = deleteForeignRule(entry.worksheet, index);
        if (result.ok)
            succeeded += 1;
        else {
            failures.push(tOr('conditionalFormat.toast.failureItem', '第 {index} 条：{error}', {
                index: String(index),
                error: result.error,
            }));
        }
    }
    state.existingSelection = new Set();
    if (failures.length > 0) {
        showToast(tOr('conditionalFormat.toast.deleteFailedCount', '已删除 {ok} 条，{failed} 条失败（{reason}）', {
            ok: String(succeeded),
            failed: String(failures.length),
            reason: failures[0] ?? tOr('conditionalFormat.toast.unknownReason', '未知原因'),
        }), 'error');
    }
    else {
        showToast(tOr('conditionalFormat.toast.deletedCount', '已删除 {count} 条规则', {
            count: String(succeeded),
        }), 'success');
    }
    loadExistingRules();
}
/**
 * 取当前选区的 A1 地址（「显示其格式规则 = 当前选择」用）
 *
 * 读不到返回空串：调用方据此退化为整表并在计数上说明，不静默显示全部。
 */
function currentSelectionRange() {
    const entry = selectedSheet();
    if (!entry)
        return '';
    try {
        const app = getApp();
        const address = app?.Selection?.Address;
        return typeof address === 'string' ? address : '';
    }
    catch {
        return '';
    }
}
/**
 * 批量调整所选规则优先级
 *
 * ⚠️ **必须倒序**（与批量删除同理）：移动会改变其余规则的下标，正序走着就错位。
 * moveForeignRule 现在是真正的「相邻交换一格」，倒序逐条调 = 每条各自上/下移
 * 一格（多条同时穿越同一位置的精确排序需要反复重排，代价高且易错，先不做）。
 */
function batchMoveForeignRules(direction) {
    const entry = selectedSheet();
    if (!entry)
        return;
    const indices = [...state.existingSelection].sort((a, b) => b - a);
    let succeeded = 0;
    let failed = 0;
    for (const index of indices) {
        const result = moveForeignRule(entry.worksheet, index, direction);
        if (result.ok)
            succeeded += 1;
        else
            failed += 1;
    }
    if (failed > 0) {
        showToast(tOr('conditionalFormat.toast.reorderedCount', '已调整 {ok} 条，{failed} 条失败', {
            ok: String(succeeded),
            failed: String(failed),
        }), 'error');
    }
    else if (succeeded > 0) {
        showToast(tOr('conditionalFormat.toast.movedDirection', '已把 {count} 条规则{direction}（每次一格）', {
            count: String(succeeded),
            direction: direction === -1
                ? tOr('conditionalFormat.toast.directionUp', '提前')
                : tOr('conditionalFormat.toast.directionDown', '置后'),
        }), 'success');
    }
    loadExistingRules();
}
/**
 * 既有规则表格里的 checkbox 变化（三处：选中单行 / 全选 / 如果为真则停止）
 *
 * 同一容器上按 `data-action` 分流，避免给每种 checkbox 各绑一个监听器。
 */
function handleExistingTableChange(event) {
    const target = event.target;
    if (!target)
        return;
    if (target.dataset.action === 'select') {
        const row = target.closest('[data-row-index]');
        const index = Number(row?.dataset.rowIndex ?? '0');
        if (!Number.isSafeInteger(index) || index < 1)
            return;
        // 不可变更新：改原 Set 会让「上一次渲染的旧行模型」与当前 state 指向同一对象
        state.existingSelection = toggleSelection(state.existingSelection, index, target.checked);
        renderExistingRules();
        return;
    }
    if (target.dataset.action === 'select-all') {
        // 全选只作用于**当前可见页**（翻页不跨页全选）：347 条规则里「全选」通常
        // 指「这一屏我都不要了」，跨页全选反而危险（一删就是 347 条）。
        const rows = toForeignRuleRows(state.existing, state.existingSelection);
        const visible = filterForeignRuleRows(rows, state.existingQuery);
        const page = paginate(visible, state.existingPage, FOREIGN_RULE_PAGE_SIZE);
        const next = new Set(state.existingSelection);
        if (target.checked)
            for (const row of page.items)
                next.add(row.index);
        else
            for (const row of page.items)
                next.delete(row.index);
        state.existingSelection = next;
        renderExistingRules();
        return;
    }
    if (target.dataset.action !== 'stop')
        return;
    const row = target.closest('[data-row-index]');
    const index = Number(row?.dataset.rowIndex ?? '0');
    if (!Number.isSafeInteger(index) || index < 1)
        return;
    const entry = selectedSheet();
    if (!entry)
        return;
    const result = setForeignStopIfTrue(entry.worksheet, index, target.checked);
    if (result.ok) {
        showToast(tOr('conditionalFormat.toast.stopIfTrueSet', '第 {index} 条规则已设为{state}', {
            index: String(index),
            state: target.checked
                ? tOr('conditionalFormat.toast.stopIfTrueOn', '命中即停')
                : tOr('conditionalFormat.toast.stopIfTrueOff', '继续评估后续'),
        }), 'success');
        loadExistingRules();
    }
    else {
        // 写不进去要把复选框还原：否则用户以为生效了，实际没有
        target.checked = !target.checked;
        showToast(tOr('conditionalFormat.toast.setFailed', '设置失败：{error}', {
            error: result.error,
        }), 'error');
    }
}
/**
 * 行内编辑「应用于 / 公式」：单元格原地变成输入框
 *
 * Enter / blur 保存，Esc 取消（重渲染即还原）。保存走 COM 写工作表
 * （ModifyAppliesToRange / Formula1），成功后按公式匹配联动规则库里
 * 已导入的副本。
 */
function startCellEdit(cell, index, kind) {
    // 同一单元格已在编辑中（里面已有 input）不重复开
    if (cell.querySelector('input'))
        return;
    const snapshot = state.existing[index - 1];
    if (!snapshot)
        return;
    const original = kind === 'range' ? snapshot.range : snapshot.formula;
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'conditional-format-cell-input';
    input.value = original;
    input.spellcheck = false;
    input.setAttribute('aria-label', kind === 'range'
        ? tOr('conditionalFormat.editInline.rangeAria', '修改应用范围')
        : tOr('conditionalFormat.editInline.formulaAria', '修改公式'));
    // replaceChildren 一次完成「清空 + 插入」：拆成 textContent='' + append 会踩
    // no-param-reassign（禁给参数属性赋值，方法调用不管）
    cell.replaceChildren(input);
    input.focus();
    input.select();
    let isFinished = false;
    const finish = (shouldCommit) => {
        if (isFinished)
            return;
        isFinished = true;
        const next = input.value.trim();
        // 取消 / 空值 / 没改动：重渲染还原，不写 COM
        if (!shouldCommit || next === '' || next === original) {
            renderExistingRules();
            return;
        }
        commitCellEdit(index, kind, original, next);
    };
    input.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
            event.preventDefault();
            finish(true);
        }
        else if (event.key === 'Escape') {
            event.preventDefault();
            // 拦住传播：document 上还有关弹窗的 Esc 监听，不该被行内编辑触发
            event.stopPropagation();
            finish(false);
        }
    });
    input.addEventListener('blur', () => {
        finish(true);
    });
}
/** 提交行内编辑：写工作表 → 联动规则库副本 → 刷新表格与规则库 */
function commitCellEdit(index, kind, oldFormula, next) {
    const entry = selectedSheet();
    if (!entry)
        return;
    // 快照在写 COM 前取：key 迁移要用「改之前」的公式/范围（state.existing 在
    // 成功后会被 loadExistingRules 刷新）
    const snapshot = state.existing[index - 1];
    const result = kind === 'range'
        ? setForeignAppliesTo(entry.worksheet, index, next)
        : setForeignFormula(entry.worksheet, index, next);
    if (!result.ok) {
        // 写不进去要还原输入并明说：否则用户以为改了，实际没有（与 stopIfTrue 同口径）
        showToast(tOr('conditionalFormat.toast.modifyFailed', '修改失败：{error}', {
            error: result.error,
        }), 'error');
        renderExistingRules();
        return;
    }
    // 分组 key 由公式+范围组成，改了哪个就迁哪个（否则规则掉进「未分组」）
    if (snapshot) {
        const oldKey = snapshotGroupKey(snapshot);
        // 只换被改的字段，另一个沿用原值（三元提到对象构造里，prefer-minimal-ternary）
        const patched = kind === 'range' ? { ...snapshot, range: next } : { ...snapshot, formula: next };
        migrateExistingGroupKey(oldKey, snapshotGroupKey(patched));
    }
    const synced = syncImportedRulesInStore(oldFormula, kind === 'range' ? { appliesTo: next } : { formula: next });
    showToast(kind === 'range'
        ? tOr('conditionalFormat.editInline.rangeChanged', '第 {index} 条范围已改为 {range}', {
            index: String(index),
            range: next,
        })
        : tOr('conditionalFormat.editInline.formulaUpdated', '第 {index} 条公式已更新', {
            index: String(index),
        }), 'success');
    if (synced > 0) {
        showToast(tOr('conditionalFormat.toast.importedSynced', '已同步规则库里 {count} 条导入的规则', {
            count: String(synced),
        }), 'info');
    }
    loadExistingRules();
    renderRuleList();
}
/**
 * 表格改了范围/公式后，同步规则库里已导入的副本（按公式匹配）
 *
 * 只动「导入的规则」分组：手工写的插件规则与工作表规则是两套东西，
 * 不该被表格操作波及。多条同公式时全部同步（同一公式的范围通常一致）。
 *
 * @returns 同步了几条（0 = 库里没有对应副本，toast 不提示联动）
 */
function syncImportedRulesInStore(oldFormula, patch) {
    if (oldFormula === '')
        return 0;
    let synced = 0;
    state.rules = state.rules.map((rule) => {
        if (rule.group !== IMPORTED_RULE_GROUP || rule.formula !== oldFormula)
            return rule;
        synced += 1;
        return {
            ...rule,
            ...(patch.appliesTo !== undefined && { appliesTo: patch.appliesTo }),
            ...(patch.formula !== undefined && { formula: patch.formula }),
        };
    });
    if (synced > 0)
        persistRules(false);
    return synced;
}
/** 单条既有规则导入规则库 */
function importForeignRule(index) {
    const entry = selectedSheet();
    if (!entry)
        return;
    const snapshot = state.existing[index - 1];
    if (!snapshot) {
        showToast(tOr('conditionalFormat.toast.ruleMissing', '规则已不存在，请重新读取'), 'warn');
        return;
    }
    const rule = foreignSnapshotToRule(snapshot, nextId);
    if (!rule) {
        showToast(tOr('conditionalFormat.toast.typeNotRebuildable', '第 {index} 条是{type}，插件无法重建该类型，不能导入', {
            index: String(index),
            type: fcTypeLabel(snapshot.type, snapshot.kind),
        }), 'warn');
        return;
    }
    state.rules = [...state.rules, rule];
    persistRules();
    renderRuleList();
    showToast(tOr('conditionalFormat.toast.importedToGroup', '已导入第 {index} 条规则到「{group}」', {
        index: String(index),
        group: IMPORTED_GROUP,
    }), 'success');
}
/** 从工作表删除单条既有规则 */
function deleteForeignRuleRow(index) {
    const entry = selectedSheet();
    if (!entry)
        return;
    const snapshot = state.existing[index - 1];
    if (!snapshot) {
        showToast(tOr('conditionalFormat.toast.ruleMissing', '规则已不存在，请重新读取'), 'warn');
        return;
    }
    const label = snapshot.range ||
        tOr('conditionalFormat.toast.ruleIndex', '第 {index} 条', { index: String(index) });
    const result = deleteForeignRule(entry.worksheet, index);
    if (!result.ok) {
        showToast(tOr('conditionalFormat.toast.deleteFailed', '删除失败：{error}', {
            error: result.error,
        }), 'error');
        return;
    }
    showToast(tOr('conditionalFormat.toast.deletedOnLabel', '已删除 {label} 上的规则', {
        label,
    }), 'success');
    loadExistingRules();
}
/** 调整既有规则优先级 */
function moveForeignRuleRow(index, direction) {
    const entry = selectedSheet();
    if (!entry)
        return;
    const total = state.existing.length;
    if (index < 1 || index > total)
        return;
    const target = index + direction;
    if (target < 1 || target > total)
        return;
    const result = moveForeignRule(entry.worksheet, index, direction);
    if (!result.ok) {
        showToast(tOr('conditionalFormat.toast.reorderFailed', '调整失败：{error}', {
            error: result.error,
        }), 'error');
        return;
    }
    loadExistingRules();
}
// ===== Store 读写 =====
function loadRules() {
    const { rules, dropped } = parseRules(getConfig(CONDITIONAL_FORMAT_STORE_KEY, '', true));
    state.rules = rules;
    if (dropped > 0) {
        bgmLog(LOG_LEVELS.WARN, `[conditionalFormat] 规则库有 ${String(dropped)} 条损坏记录已忽略`);
    }
}
/**
 * 落盘规则库
 *
 * @param shouldNotifyApply 是否提示「还没写进工作表」。默认 true：规则库是本地库，
 *   改完不点应用表上不会有变化——这句话原先写死在模块提示里，用户滑过去就看不见，
 *   改完以为该生效。工作表 → 规则库的同步（`syncImportedRulesInStore`）传 false：
 *   那种改动本来就已经在表上了，再提示「去点应用」是错的。
 */
function persistRules(shouldNotifyApply = true) {
    setConfig(CONDITIONAL_FORMAT_STORE_KEY, serializeRules(state.rules));
    if (shouldNotifyApply)
        notifyApplyNeeded();
}
/** 上次「未应用到工作表」提示的时间（防抖：拖拽连续调序会连写多次盘，不该刷屏） */
let lastApplyNoticeAt = 0;
/**
 * 提示「改动只在『我的规则』里，还没写进工作表」
 *
 * 2 秒内重复触发只提示一次：拖拽调序 / 连续勾选隐藏都会连写，逐次弹 toast 会盖住
 * 用户正在看的表格。
 */
function notifyApplyNeeded() {
    const now = Date.now();
    if (now - lastApplyNoticeAt < 2000)
        return;
    lastApplyNoticeAt = now;
    showToast(tOr('conditionalFormat.toast.savedToLibrary', '改动已存进「我的规则」，点「🖌️ 应用与修复 → 应用条件格式」才会写进工作表'), 'info');
}
function loadExistingGroups() {
    state.existingGroups = parseExistingGroups(getConfig(EXISTING_GROUPS_STORE_KEY, '', true));
}
function persistExistingGroups() {
    setConfig(EXISTING_GROUPS_STORE_KEY, serializeExistingGroups(state.existingGroups));
}
function nextId() {
    return `cf_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}
// ===== 规则列表渲染 =====
function toggleHidden(id, isHidden) {
    const rule = state.rules.find((r) => r.id === id);
    if (!rule)
        return;
    rule.hidden = isHidden;
    persistRules();
    renderRuleList();
}
function moveRule(id, direction) {
    const index = state.rules.findIndex((r) => r.id === id);
    const target = index + direction;
    if (index === -1 || target < 0 || target >= state.rules.length)
        return;
    const current = state.rules[index];
    const neighbor = state.rules[target];
    if (!current || !neighbor)
        return;
    state.rules[index] = neighbor;
    state.rules[target] = current;
    persistRules();
    renderRuleList();
}
function deleteRule(id) {
    state.rules = state.rules.filter((rule) => rule.id !== id);
    state.clipboard = state.clipboard.filter((cid) => cid !== id);
    persistRules();
    renderRuleList();
}
function copyRules(ids) {
    if (ids.length === 0)
        return;
    // 内部剪贴板（「粘贴」出副本用）与系统剪贴板是两回事：
    // 只写内部的话，用户按 Ctrl+V 到别处什么也拿不到，会以为「复制没生效」。
    state.clipboard = [...ids];
    const sources = state.rules.filter((rule) => ids.includes(rule.id));
    void copyRulesToSystemClipboard(sources);
}
/** 规则的 JSON 载荷（系统剪贴板与「导出到剪贴板」共用同一格式，粘回来能直接导） */
function rulesPayloadJson(rules) {
    return JSON.stringify({
        format: 'bgm-conditional-format-rules',
        version: 1,
        exportedAt: new Date().toISOString(),
        rules,
    }, null, 2);
}
/**
 * 把文本写进**系统**剪贴板
 *
 * 先走 execCommand（WPS WebView 里 Clipboard API 常不可用，这是唯一可靠路径），
 * 失败再退回 `navigator.clipboard`（普通浏览器 / 安全上下文）。
 *
 * @returns 是否真的写进去了（调用方据此决定提示语气）
 */
async function copyTextToSystemClipboard(text) {
    if (copyTextWithResult(text).ok)
        return true;
    try {
        await navigator.clipboard.writeText(text);
        return true;
    }
    catch {
        return false;
    }
}
/**
 * 复制规则到系统剪贴板（⧉ 按钮）
 *
 * 失败不静默：内部剪贴板仍然可用（「粘贴」照样能出副本），但必须说清
 * 「系统剪贴板没写进去」，否则用户粘到别处是空的还以为功能坏了。
 */
async function copyRulesToSystemClipboard(rules) {
    if (rules.length === 0) {
        showToast(tOr('conditionalFormat.toast.copiedPluginClipMissing', '已复制到插件剪贴板（规则已不存在）'), 'warn');
        return;
    }
    const isOk = await copyTextToSystemClipboard(rulesPayloadJson(rules));
    if (isOk) {
        showToast(tOr('conditionalFormat.toast.copiedToSystemClipboard', '已复制 {count} 条规则到系统剪贴板（点「粘贴」可生成副本）', {
            count: String(rules.length),
        }), 'success');
    }
    else {
        showToast(tOr('conditionalFormat.toast.systemClipboardUnavailable', '系统剪贴板不可用：仍可用「粘贴」生成副本，或改用「导出规则 → 复制到剪贴板」'), 'warn');
    }
}
function pasteRules() {
    if (state.clipboard.length === 0) {
        showToast(tOr('conditionalFormat.toast.pluginClipboardEmpty', '插件剪贴板是空的——点「粘贴 ▾」可从系统剪贴板或文本粘'), 'warn');
        return;
    }
    const sources = state.rules.filter((rule) => state.clipboard.includes(rule.id));
    if (sources.length === 0) {
        showToast(tOr('conditionalFormat.toast.clipboardRuleMissing', '剪贴板里的规则已不存在'), 'warn');
        return;
    }
    // 自有模态框而非通用 showInput：momo 要「可拖动的浮动窗口 + 可收起 +
    // 按钮小一点离输入框远点」。通用弹窗是桥接的实现，不为单个场景改行为。
    openPasteModal(sources);
}
/**
 * 「粘贴 ▾」菜单：三个来源，本质都是「把已有规则粘成副本」
 *
 * 2026-10-29 合并前是两套入口：主按钮只认插件内剪贴板（本次复制过的 id 数组），
 * 「从文本导入」藏在「导入 ▾」里——同一个诉求（把 JSON 变成规则）分裂在两处，
 * 用户复制了外部 JSON 会去点「粘贴」然后被告知剪贴板是空的。现在按**来源**分：
 * 插件内 / 系统剪贴板 / 手写文本，都收在粘贴下拉里；导入只留「工作表 / 文件」。
 */
function openPasteMenu(button) {
    const rect = button.getBoundingClientRect();
    const count = state.clipboard.length;
    showContextMenu({
        items: [
            {
                id: 'paste-library',
                label: count > 0
                    ? tOr('conditionalFormat.paste.pluginClipboardCount', '📋 粘贴插件剪贴板（{count} 条）', {
                        count: String(count),
                    })
                    : tOr('conditionalFormat.paste.pluginClipboard', '📋 粘贴插件剪贴板'),
                disabled: count === 0,
                disabledReason: tOr('conditionalFormat.paste.pluginEmpty', '还没有在插件里复制过规则——用行尾的 ⧉，或从下面两条来源粘贴'),
                onSelect: () => {
                    pasteRules();
                },
            },
            { id: 'paste-sep', separator: true },
            {
                id: 'paste-system',
                label: tOr('conditionalFormat.paste.systemClipboard', '🖥️ 从系统剪贴板粘贴'),
                onSelect: () => {
                    void pasteFromSystemClipboard();
                },
            },
            {
                id: 'paste-text',
                label: tOr('conditionalFormat.paste.text', '✍️ 从文本粘贴 / 编辑 JSON'),
                onSelect: () => {
                    openTextImportModal();
                },
            },
        ],
        x: rect.left,
        y: rect.bottom + 4,
        anchor: button,
    });
}
/**
 * 读系统剪贴板文本
 *
 * 只走 `navigator.clipboard.readText()`：`execCommand('paste')` 需要用户手势 +
 * 可编辑焦点，在任务窗格里拿不到内容。WPS 的 CEF 若禁用剪贴板读权限，这里会
 * 抛错——调用方据此降级成「打开空弹窗 + 提示 Ctrl+V」，而不是假装剪贴板是空的。
 */
async function readTextFromSystemClipboard() {
    try {
        return await navigator.clipboard.readText();
    }
    catch {
        return '';
    }
}
/**
 * 从系统剪贴板粘贴
 *
 * 读到了就预填进弹窗（用户可先看一眼、改一改再导入——直接导入剪贴板里的东西
 * 太冒险，那可能是任意文本）；读不到就开空弹窗并说明为什么，让用户自己 Ctrl+V。
 */
async function pasteFromSystemClipboard() {
    const text = await readTextFromSystemClipboard();
    if (text.trim() === '') {
        openTextImportModal({
            hint: tOr('conditionalFormat.paste.systemUnreadable', '读不到系统剪贴板（宿主可能禁止网页读取）。按 Ctrl+V 粘到下面再点「导入」即可。'),
        });
        return;
    }
    openTextImportModal({ prefill: text });
}
/** 粘贴来源的会话态（弹窗开着期间的数据源；关闭即清） */
let pasteSources = [];
/**
 * 粘贴弹窗的模式：`library` = 粘贴规则库条目（生成副本进库）；
 * `worksheet` = 复制工作表上的一条既有规则（直接 Add 到工作表）
 *
 * 两种操作本质都是「同公式同格式、换个范围」，故共用同一个弹窗（同一个范围输入框、
 * 同一套定位与滚动锁），只有确认后的落点不同。
 */
let pasteTarget = 'library';
/** 复制工作表规则时的源序号（1 基；`pasteTarget === 'library'` 时无意义） */
let pasteWorksheetIndex = 0;
/** 待粘贴的多条规则（单条粘贴时为空：那条走 #conditionalFormatPasteRange） */
let pasteRows = [];
/** 打开「粘贴规则」弹窗：预填原范围，定位三件套与其它模态框一致 */
function openPasteModal(sources) {
    pasteSources = [...sources];
    pasteTarget = 'library';
    pasteWorksheetIndex = 0;
    setText('conditionalFormatPasteLabel', tOr('conditionalFormat.paste.label', '📋 粘贴规则'));
    const hint = byId('conditionalFormatPasteHint');
    const isBatch = sources.length > 1;
    // 两套视图：单条 = 一个范围输入框；多条 = 表格（逐条看公式/配色、逐条改范围）
    setElementVisible('conditionalFormatPasteRange', !isBatch);
    setElementVisible('conditionalFormatPasteBatch', isBatch);
    if (isBatch) {
        pasteRows = sources.map((rule) => ({
            source: rule,
            range: rule.appliesTo,
            formula: rule.formula,
            interior: rule.interior,
            fontColor: rule.fontColor ?? '',
            fontBold: rule.fontBold === true,
        }));
        if (hint) {
            hint.textContent = tOr('conditionalFormat.paste.hintEditable', '将粘贴 {count} 条规则。可在表格里逐条改应用范围，或用上面的输入框批量统一。', { count: String(sources.length) });
        }
        renderPasteTable();
    }
    else {
        pasteRows = [];
        if (hint) {
            hint.textContent = tOr('conditionalFormat.paste.hintWithTarget', '将粘贴 {count} 条规则。目标范围（留空保持原范围）：', { count: String(sources.length) });
        }
        const input = inputById('conditionalFormatPasteRange');
        if (input)
            input.value = sources[0]?.appliesTo ?? '';
    }
    showPasteMask();
}
/** 按 id 显示 / 隐藏一个元素（同时清 hidden 属性与内联 display，两边都不留死角） */
function setElementVisible(id, isVisible) {
    const element = byId(id);
    if (element) {
        // hidden 属性优先级高于内联 display：只改 style 的话，HTML 里带 hidden 的
        // 节点「显示」时依旧看不见（粘贴表格的初始态就是 hidden）
        element.hidden = !isVisible;
        element.style.display = isVisible ? '' : 'none';
    }
}
/** 渲染粘贴弹窗里的规则表格（表头 + 每行：序号 / 名称 / 公式 / 色块 / 范围输入） */
function renderPasteTable() {
    const container = byId('conditionalFormatPasteTable');
    if (!container)
        return;
    const head = `<div class="conditional-format-paste-row conditional-format-paste-row--head conditional-format-table-head table-resize-head">
      <span>${tOr('conditionalFormat.paste.colIndex', '#')}</span><span>${tOr('conditionalFormat.paste.colName', '规则名')}</span><span>${tOr('conditionalFormat.paste.colFormula', '公式')}</span><span>${tOr('conditionalFormat.paste.colColor', '色')}</span><span>${tOr('conditionalFormat.paste.colRange', '应用范围')}</span>
    </div>`;
    const rows = pasteRows
        .map((row, index) => `
    <div class="conditional-format-paste-row" data-paste-row="${String(index + 1)}">
      <span>${String(index + 1)}</span>
      <span class="conditional-format-paste-name" title="${escapeHtml(row.source.name)}">${escapeHtml(row.source.name)}</span>
      <span class="conditional-format-paste-formula" title="${escapeHtml(row.formula)}">${escapeHtml(row.formula)}</span>
      <span class="conditional-format-paste-swatch" style="background:${escapeHtml(row.interior)}" title="${escapeHtml(row.interior)}"></span>
      <input
        type="text"
        class="conditional-format-input"
        data-paste-range="${String(index + 1)}"
        value="${escapeHtml(row.range)}"
        placeholder="${tOr('conditionalFormat.paste.rangePlaceholder', '如 B3:B1048576')}"
        aria-label="${tOr('conditionalFormat.paste.rangeAria', '第 {index} 条的应用范围', { index: String(index + 1) })}"
      />
    </div>`)
        .join('');
    container.innerHTML = head + rows;
    // 表头是新节点，重插列宽/行高把手（decorate 幂等）
    state.tableResize.paste?.decorate();
    maybeAutoFitTable('paste');
}
/** 表格里逐条改范围：把输入框的值写回模型（不重渲染，免得打断输入） */
function handlePasteTableInput(event) {
    const { target } = event;
    if (!(target instanceof HTMLInputElement))
        return;
    const index = Number(target.dataset.pasteRange ?? '0');
    const row = pasteRows[index - 1];
    if (row)
        row.range = target.value.trim();
}
/** 「应用到全部」：把统一范围填进每一行 */
function applyPasteUniformRange() {
    const value = (inputById('conditionalFormatPasteUniformRange')?.value ?? '').trim();
    if (value === '') {
        showToast(tOr('conditionalFormat.toast.fillRangeFirst', '先在上面填一个应用范围'), 'warn');
        return;
    }
    if (pasteRows.length === 0)
        return;
    for (const row of pasteRows)
        row.range = value;
    renderPasteTable();
    showToast(tOr('conditionalFormat.toast.rangesUnified', '已把 {count} 条的应用范围统一为 {range}', {
        count: String(pasteRows.length),
        range: value,
    }), 'success');
}
/**
 * 打开「复制工作表规则」弹窗（⧉）
 *
 * 与粘贴同一个框：预填源规则的范围，用户改成新范围即可在同一张表上得到副本。
 * 留空 = 复制到原范围（用于「同一范围再加一条不同优先级的规则」）。
 */
function openDuplicateModal(index) {
    const snapshot = state.existing[index - 1];
    if (!snapshot) {
        showToast(tOr('conditionalFormat.toast.ruleMissing', '规则已不存在，请重新读取'), 'warn');
        return;
    }
    if (snapshot.kind !== 'expression' || snapshot.formula === '') {
        showToast(tOr('conditionalFormat.toast.noReadableFormula', '这条规则没有可读到的公式（数据条 / 色阶 / 图标集等类型无法复制）'), 'warn');
        return;
    }
    pasteSources = [];
    pasteTarget = 'worksheet';
    pasteWorksheetIndex = index;
    setText('conditionalFormatPasteLabel', tOr('conditionalFormat.copy.label', '⧉ 复制规则'));
    const hint = byId('conditionalFormatPasteHint');
    if (hint) {
        hint.textContent = tOr('conditionalFormat.copy.hint', '将把第 {index} 条（{range}）复制成一条新规则，公式与格式照搬。目标范围（留空保持原范围）：', {
            index: String(index),
            range: snapshot.range || tOr('conditionalFormat.copy.unknownRange', '范围未知'),
        });
    }
    const input = inputById('conditionalFormatPasteRange');
    if (input)
        input.value = snapshot.range;
    showPasteMask();
}
/** 打开粘贴 / 复制弹窗的遮罩（两模式共用定位三件套） */
function showPasteMask() {
    const mask = byId('conditionalFormatPasteMask');
    const modal = mask?.querySelector('.conditional-format-modal');
    if (mask) {
        if (modal) {
            resetModalPosition(modal);
            applyModalButtonsPosition(modal);
        }
        anchorModalMask(mask);
        mask.style.display = 'flex';
        if (modal)
            bringModalIntoView(mask, modal);
    }
    lockModalScroll();
    // 打开即聚焦：用户可以直接改范围回车确认，不用先点一下输入框。
    // 多条规则时焦点给「统一范围」——逐条改属于例外路径，不抢焦点。
    const focusId = pasteRows.length > 1 ? 'conditionalFormatPasteUniformRange' : 'conditionalFormatPasteRange';
    const input = inputById(focusId);
    input?.focus();
    input?.select();
}
/** 关闭「粘贴 / 复制」弹窗（没开时 no-op：Esc 块连调五个 close，别乱解滚动锁） */
function closePasteModal() {
    const mask = byId('conditionalFormatPasteMask');
    // 没开 = no-op：Esc 块连调五个 close，没开的不能解别人的滚动锁
    if (mask?.style.display === 'none')
        return;
    if (mask) {
        mask.style.display = 'none';
        pasteSources = [];
        pasteRows = [];
        pasteTarget = 'library';
        pasteWorksheetIndex = 0;
        setElementVisible('conditionalFormatPasteBatch', false);
        setElementVisible('conditionalFormatPasteRange', true);
        const uniform = inputById('conditionalFormatPasteUniformRange');
        if (uniform)
            uniform.value = '';
        unlockModalScroll();
    }
}
/** 确认粘贴：按弹窗里的目标范围生成副本（公式行号引用跟着平移） */
function confirmPaste() {
    if (pasteTarget === 'worksheet') {
        confirmDuplicateRule();
        return;
    }
    // 多条：逐行用自己的范围（表格里改过），批量修改过的公式/配色也一并带上
    if (pasteRows.length > 0) {
        confirmBatchPaste();
        return;
    }
    const sources = pasteSources;
    if (sources.length === 0) {
        closePasteModal();
        return;
    }
    const firstRange = sources[0]?.appliesTo ?? '';
    const typedRange = (inputById('conditionalFormatPasteRange')?.value ?? '').trim();
    // 留空 = 保持原范围（空串与 nullish 都要回退，故不用 ??）
    const targetRange = typedRange === '' ? firstRange : typedRange;
    // 目标范围首行与原范围不同时，公式里的行号引用跟着平移（$R3 → $R10）
    const rowDelta = firstRowOfRange(targetRange) - firstRowOfRange(firstRange);
    const copies = sources.map((rule) => ({
        ...rule,
        id: nextId(),
        name: tOr('conditionalFormat.ruleCopy.suffix', '{name} 副本', { name: rule.name }),
        appliesTo: targetRange,
        formula: shiftFormulaRows(rule.formula, rowDelta),
    }));
    state.rules = [...state.rules, ...copies];
    persistRules();
    closePasteModal();
    renderRuleList();
    showToast(tOr('conditionalFormat.toast.pastedRules', '已粘贴 {count} 条规则到 {range}', {
        count: String(copies.length),
        range: targetRange,
    }), 'success');
}
/**
 * 确认粘贴（多条）：逐行按各自的范围生成副本
 *
 * 行号平移只在「公式没被批量改过」时做：用户显式填的公式是**按目标范围写好的**，
 * 再按行差平移一次反而错位（例如统一填 `=$R3="x"` 又换了范围）。
 */
function confirmBatchPaste() {
    const rows = pasteRows;
    const copies = rows.map((row) => {
        const range = row.range === '' ? row.source.appliesTo : row.range;
        const isFormulaEdited = row.formula !== row.source.formula;
        const formula = isFormulaEdited
            ? row.formula
            : shiftFormulaRows(row.formula, firstRowOfRange(range) - firstRowOfRange(row.source.appliesTo));
        return {
            ...row.source,
            id: nextId(),
            name: tOr('conditionalFormat.ruleCopy.suffix', '{name} 副本', { name: row.source.name }),
            appliesTo: range,
            formula,
            interior: row.interior,
            ...(row.fontColor !== '' && { fontColor: row.fontColor }),
            fontBold: row.fontBold,
        };
    });
    state.rules = [...state.rules, ...copies];
    persistRules();
    closePasteModal();
    renderRuleList();
    const ranges = new Set(copies.map((copy) => copy.appliesTo));
    const target = ranges.size === 1
        ? [...ranges][0]
        : tOr('conditionalFormat.ruleCopy.rangeCount', '{count} 个范围', {
            count: String(ranges.size),
        });
    showToast(tOr('conditionalFormat.toast.pastedRules', '已粘贴 {count} 条规则到 {range}', {
        count: String(copies.length),
        range: target ?? '',
    }), 'success');
}
let batchTarget = 'library';
/** 弹窗标题里显示的目标名 */
const BATCH_TARGET_LABELS = {
    library: tOr('conditionalFormat.batchTarget.library', '我的规则'),
    worksheet: tOr('conditionalFormat.batchTarget.worksheet', '工作表规则'),
    paste: tOr('conditionalFormat.batchTarget.paste', '待粘贴的规则'),
};
/** 下拉里「统一为某个已有值」的前缀（避免与 keep / custom 撞） */
const BATCH_VALUE_PREFIX = 'value:';
/** 参与批量修改的四个「值型」字段（加粗是布尔，单独处理） */
const BATCH_VALUE_FIELDS = [
    {
        key: 'range',
        pickId: 'conditionalFormatBatchRangePick',
        inputId: 'conditionalFormatBatchRange',
    },
    {
        key: 'formula',
        pickId: 'conditionalFormatBatchFormulaPick',
        inputId: 'conditionalFormatBatchFormula',
    },
    {
        key: 'interior',
        pickId: 'conditionalFormatBatchFillPick',
        inputId: 'conditionalFormatBatchFill',
    },
    {
        key: 'fontColor',
        pickId: 'conditionalFormatBatchFontPick',
        inputId: 'conditionalFormatBatchFont',
    },
];
/** 取某个目标的当前值列表（空数组 = 没勾选，弹窗不该开） */
function batchRowsOf(target) {
    if (target === 'library') {
        const ids = new Set(state.ruleSelection);
        return state.rules
            .filter((rule) => ids.has(rule.id))
            .map((rule) => ({
            range: rule.appliesTo,
            formula: rule.formula,
            interior: rule.interior,
            fontColor: rule.fontColor ?? '',
            fontBold: rule.fontBold === true,
        }));
    }
    if (target === 'worksheet') {
        return [...state.existingSelection]
            .sort((a, b) => a - b)
            .flatMap((index) => {
            const snapshot = state.existing[index - 1];
            if (!snapshot)
                return [];
            return [
                {
                    range: snapshot.range,
                    formula: snapshot.formula,
                    interior: snapshot.interior ?? '',
                    fontColor: snapshot.fontColor ?? '',
                    fontBold: false,
                },
            ];
        });
    }
    return pasteRows.map((row) => ({
        range: row.range,
        formula: row.formula,
        interior: row.interior,
        fontColor: row.fontColor,
        fontBold: row.fontBold,
    }));
}
/**
 * 填四个字段的下拉：保持不变 / 各现有值（去重）/ 自定义
 *
 * 现有值就是「统一为某条已有的格式或范围」那条路——用户不用记公式，直接从
 * 下拉里挑一条；右侧输入框同步成第一个值，选「自定义」时不用从空开始。
 */
function fillBatchValueFields(rows) {
    for (const field of BATCH_VALUE_FIELDS) {
        const pick = selectById(field.pickId);
        if (pick) {
            const values = [...new Set(rows.map((row) => row[field.key]).filter((value) => value !== ''))];
            const options = [
                `<option value="keep">${tOr('conditionalFormat.batchEdit.keep', '保持不变')}</option>`,
            ];
            for (const value of values) {
                options.push(`<option value="${BATCH_VALUE_PREFIX}${escapeHtml(value)}">${escapeHtml(value)}</option>`);
            }
            options.push(`<option value="custom">${tOr('conditionalFormat.batchEdit.custom', '自定义…')}</option>`);
            pick.innerHTML = options.join('');
            const input = byId(field.inputId);
            if (input instanceof HTMLInputElement)
                input.value = values[0] ?? '';
        }
    }
}
/**
 * 读一个字段的下拉 + 输入框
 *
 * @returns `null` = 保持不变；字符串 = 要写入的值（空串由调用方判非法）
 */
function readBatchValue(pickId, inputId) {
    const pick = selectById(pickId);
    if (!pick)
        return null;
    if (pick.value === 'keep')
        return null;
    if (pick.value === 'custom') {
        const input = byId(inputId);
        return input instanceof HTMLInputElement ? input.value.trim() : null;
    }
    return pick.value.startsWith(BATCH_VALUE_PREFIX)
        ? pick.value.slice(BATCH_VALUE_PREFIX.length)
        : pick.value;
}
/** 打开批量修改弹窗（按目标预填「现有值」下拉） */
function openBatchEdit(target) {
    const rows = batchRowsOf(target);
    if (rows.length === 0) {
        showToast(tOr('conditionalFormat.toast.selectRulesToModify', '先勾选要修改的规则'), 'warn');
        return;
    }
    batchTarget = target;
    setText('conditionalFormatBatchLabel', tOr('conditionalFormat.batchEdit.label', '✎ 批量修改（{target}）', {
        target: BATCH_TARGET_LABELS[target],
    }));
    setText('conditionalFormatBatchHint', tOr('conditionalFormat.batchEdit.hint', '将对 {count} 条生效；「保持不变」的项不动。下拉里列的是这些规则现有的值——选它即统一成那一条，选「自定义…」才用右边的输入框。', { count: String(rows.length) }));
    fillBatchValueFields(rows);
    const bold = selectById('conditionalFormatBatchBold');
    if (bold)
        bold.value = 'keep';
    openModalById('conditionalFormatBatchMask');
}
/** 关闭批量修改弹窗（没开时 no-op，别乱解滚动锁） */
function closeBatchEdit() {
    const mask = byId('conditionalFormatBatchMask');
    if (mask?.style.display === 'none')
        return;
    if (mask)
        mask.style.display = 'none';
    unlockModalScroll();
}
/** 确认批量修改：把非「保持不变」的字段组成补丁，按目标落盘 */
function confirmBatchEdit() {
    const patch = {};
    const labels = [];
    const range = readBatchValue('conditionalFormatBatchRangePick', 'conditionalFormatBatchRange');
    const formula = readBatchValue('conditionalFormatBatchFormulaPick', 'conditionalFormatBatchFormula');
    const interior = readBatchValue('conditionalFormatBatchFillPick', 'conditionalFormatBatchFill');
    const fontColor = readBatchValue('conditionalFormatBatchFontPick', 'conditionalFormatBatchFont');
    if (range !== null) {
        if (range === '') {
            showToast(tOr('conditionalFormat.toast.rangeRequiredKeep', '应用范围不能为空（不想改就选「保持不变」）'), 'warn');
            return;
        }
        patch.range = range;
        labels.push(tOr('conditionalFormat.batch.labelRange', '范围'));
    }
    if (formula !== null) {
        if (formula === '') {
            showToast(tOr('conditionalFormat.toast.formulaRequiredKeep', '公式不能为空（不想改就选「保持不变」）'), 'warn');
            return;
        }
        patch.formula = formula;
        labels.push(tOr('conditionalFormat.batch.labelFormula', '公式'));
    }
    if (interior !== null) {
        patch.interior = normalizeHexColor(interior) ?? interior;
        labels.push(tOr('conditionalFormat.batch.labelFill', '填充色'));
    }
    if (fontColor !== null) {
        patch.fontColor = normalizeHexColor(fontColor) ?? fontColor;
        labels.push(tOr('conditionalFormat.batch.labelFontColor', '字体色'));
    }
    const boldValue = selectById('conditionalFormatBatchBold')?.value ?? 'keep';
    if (boldValue !== 'keep') {
        patch.fontBold = boldValue === 'bold';
        labels.push(tOr('conditionalFormat.batch.labelBold', '加粗'));
    }
    if (labels.length === 0) {
        showToast(tOr('conditionalFormat.toast.nothingToChange', '每项都是「保持不变」，没有要改的内容'), 'warn');
        return;
    }
    closeBatchEdit();
    applyBatchPatch(patch, labels);
}
/** 把补丁落到当前目标上 */
function applyBatchPatch(patch, labels) {
    const suffix = tOr('conditionalFormat.page.parenSuffix', '（{items}）', {
        items: labels.join(' / '),
    });
    if (batchTarget === 'paste') {
        pasteRows = pasteRows.map((row) => ({
            ...row,
            ...(patch.range !== undefined && { range: patch.range }),
            ...(patch.formula !== undefined && { formula: patch.formula }),
            ...(patch.interior !== undefined && { interior: patch.interior }),
            ...(patch.fontColor !== undefined && { fontColor: patch.fontColor }),
            ...(patch.fontBold !== undefined && { fontBold: patch.fontBold }),
        }));
        renderPasteTable();
        showToast(tOr('conditionalFormat.toast.pasteRowsBatchModified', '已批量修改待粘贴的 {count} 条{suffix}', {
            count: String(pasteRows.length),
            suffix,
        }), 'success');
        return;
    }
    if (batchTarget === 'worksheet') {
        const entry = selectedSheet();
        if (!entry) {
            showToast(tOr('conditionalFormat.toast.selectTargetSheet', '请先选择目标工作表'), 'warn');
            return;
        }
        const indices = [...state.existingSelection].sort((a, b) => a - b);
        let done = 0;
        const failures = [];
        const warnings = [];
        for (const index of indices) {
            const result = updateForeignRule(entry.worksheet, index, patch);
            if (result.ok) {
                done += 1;
                warnings.push(...result.warnings);
            }
            else {
                failures.push(tOr('conditionalFormat.toast.failureItem', '第 {index} 条：{error}', {
                    index: String(index),
                    error: result.error,
                }));
            }
        }
        loadExistingRules();
        if (done === 0) {
            showToast(tOr('conditionalFormat.toast.batchModifyFailed', '批量修改失败：{reason}', {
                reason: failures[0] ?? tOr('conditionalFormat.toast.unknownReason', '未知原因'),
            }), 'error');
            return;
        }
        const failureText = failures.length > 0
            ? tOr('conditionalFormat.toast.failureText', '，{count} 条失败（{reason}）', {
                count: String(failures.length),
                reason: failures[0] ?? '',
            })
            : '';
        const warningText = warnings.length > 0
            ? tOr('conditionalFormat.toast.warningText', '；{count} 项回读不一致', {
                count: String(warnings.length),
            })
            : '';
        showToast(tOr('conditionalFormat.toast.sheetRulesBatchModified', '已批量修改 {count} 条工作表规则{suffix}{failureText}{warningText}', {
            count: String(done),
            suffix,
            failureText,
            warningText,
        }), failures.length > 0 ? 'warn' : 'success');
        return;
    }
    // library：改本地规则库（要再点「应用条件格式」才写表）
    const ids = new Set(state.ruleSelection);
    let changed = 0;
    state.rules = state.rules.map((rule) => {
        if (!ids.has(rule.id))
            return rule;
        changed += 1;
        return {
            ...rule,
            ...(patch.range !== undefined && { appliesTo: patch.range }),
            ...(patch.formula !== undefined && { formula: patch.formula }),
            ...(patch.interior !== undefined && { interior: patch.interior }),
            ...(patch.fontColor !== undefined && { fontColor: patch.fontColor }),
            ...(patch.fontBold !== undefined && { fontBold: patch.fontBold }),
        };
    });
    // 不弹 persistRules 的通用提示：下面这条自带同样的指引，两条连发会互相覆盖
    persistRules(false);
    renderRuleList();
    showToast(tOr('conditionalFormat.toast.rulesBatchModified', '已批量修改 {count} 条{suffix}——点「🖌️ 应用与修复 → 应用条件格式」才会写进工作表', {
        count: String(changed),
        suffix,
    }), 'success');
}
/** 打开一个模态框遮罩（定位三件套 + 滚动锁，与其它弹窗同一套） */
function openModalById(maskId) {
    const mask = byId(maskId);
    const modal = mask?.querySelector('.conditional-format-modal');
    if (mask) {
        if (modal) {
            resetModalPosition(modal);
            applyModalButtonsPosition(modal);
        }
        anchorModalMask(mask);
        mask.style.display = 'flex';
        if (modal)
            bringModalIntoView(mask, modal);
    }
    lockModalScroll();
}
/**
 * 确认复制工作表规则：直接在工作表上 Add 一条同公式同格式的副本
 *
 * 与「粘贴」不同，这里**不挪公式行号**：复制既有规则要的是「同一条规则换个范围」，
 * 相对引用由宿主按新范围自行解释，挪了反而错位。
 */
function confirmDuplicateRule() {
    const entry = selectedSheet();
    const index = pasteWorksheetIndex;
    const snapshot = state.existing[index - 1];
    if (!entry || !snapshot) {
        showToast(tOr('conditionalFormat.toast.ruleMissing', '规则已不存在，请重新读取'), 'warn');
        closePasteModal();
        return;
    }
    const typed = (inputById('conditionalFormatPasteRange')?.value ?? '').trim();
    const result = duplicateForeignRule(entry.worksheet, index, typed);
    if (!result.ok) {
        showToast(tOr('conditionalFormat.toast.copyFailed', '复制失败：{error}', {
            error: result.error,
        }), 'error');
        return;
    }
    closePasteModal();
    showToast(tOr('conditionalFormat.toast.copiedLowestPriority', '已复制到 {range}（优先级最低，可用「↑」上调）', {
        range: result.range,
    }), 'success');
    loadExistingRules();
}
function renderRuleList() {
    const container = byId('conditionalFormatRuleList');
    if (!container)
        return;
    const visible = filterRules(state.rules, state.searchQuery);
    if (state.rules.length === 0) {
        container.innerHTML = `<p class="conditional-format-empty">${tOr('conditionalFormat.rule.empty', '规则库是空的。到「默认规则集」生成一套，或点「新建规则」手写。')}</p>`;
        setText('conditionalFormatRuleCount', tOr('conditionalFormat.rule.countZero', '0 条规则'));
        return;
    }
    if (visible.length === 0) {
        container.innerHTML = `<p class="conditional-format-empty">${tOr('conditionalFormat.rule.noMatch', '没有匹配当前搜索词的规则。')}</p>`;
        setText('conditionalFormatRuleCount', tOr('conditionalFormat.rule.countFilteredZero', '0 / {total} 条规则', {
            total: String(state.rules.length),
        }));
        return;
    }
    const hiddenCount = state.rules.filter((rule) => rule.hidden === true).length;
    // 拆成两步：tOr 套 tOr 套 setText 会触发 unicorn/max-nested-calls（上限 3 层）
    const hiddenNote = hiddenCount > 0
        ? tOr('conditionalFormat.rule.countHidden', '（{count} 条已隐藏）', {
            count: String(hiddenCount),
        })
        : '';
    setText('conditionalFormatRuleCount', tOr('conditionalFormat.rule.count', '{total} 条规则{hidden}', {
        total: String(state.rules.length),
        hidden: hiddenNote,
    }));
    const groups = groupRules(visible);
    // 表头：规则库原来一行标签都没有——「勾选」列（批量删除/导出）与「👁」列
    // （是否应用）长得一样，用户分不清哪个是哪个。顺带它也是行高把手的落点。
    const head = `<div class="conditional-format-rule conditional-format-rule--head conditional-format-table-head table-resize-head">
          <span title="${tOr('conditionalFormat.rule.headDrag', '拖拽把手：按住上下拖可调整优先级')}"></span>
          <span title="${tOr('conditionalFormat.rule.headPick', '勾选以批量删除 / 导出 / 改颜色')}">选</span>
          <span title="${tOr('conditionalFormat.rule.headFill', '条件格式的填充色')}">色</span>
          <span>${tOr('conditionalFormat.rule.headName', '规则 / 公式')}</span>
          <span title="${tOr('conditionalFormat.rule.headVisible', '是否应用这条规则（取消勾选 = 留在规则库但不写进工作表）')}">显</span>
          <span>${tOr('conditionalFormat.rule.headActions', '操作')}</span>
        </div>`;
    container.innerHTML =
        head +
            groups
                .map(([group, rules]) => {
                // 搜索时忽略折叠态：折叠组里的命中也该可见，否则用户以为搜不到
                const isCollapsed = state.searchQuery === '' && state.collapsedGroups.has(group);
                const rows = rules
                    .map((rule) => {
                    const isHidden = rule.hidden === true;
                    return `
        <div class="conditional-format-rule${isHidden ? ' conditional-format-rule-hidden' : ''}" data-rule-id="${escapeHtml(rule.id)}" title="${tOr('conditionalFormat.rule.rowTitle', '拖拽调整优先级 · 右键打开操作菜单')}">
          <span class="conditional-format-rule-handle" title="${tOr('conditionalFormat.rule.handleTitle', '拖拽调整优先级（也可用键盘：Space 拾起、↑↓ 移动）')}" aria-hidden="true">⋮⋮</span>
          <label class="conditional-format-rule-pick" title="${tOr('conditionalFormat.rule.pickTitle', '勾选以批量删除 / 导出')}">
            <input type="checkbox" data-action="pick" ${state.ruleSelection.has(rule.id) ? 'checked' : ''} aria-label="${tOr('conditionalFormat.rule.pickAria', '勾选 {name}', { name: escapeHtml(rule.name) })}" />
          </label>
          <button type="button" class="conditional-format-swatch" data-action="edit-format" style="background:${escapeHtml(rule.interior)}" title="${tOr('conditionalFormat.rule.swatchTitle', '填充 {color} · 点击编辑这条规则', { color: escapeHtml(rule.interior) })}" aria-label="${tOr('conditionalFormat.rule.swatchAria', '编辑规则「{name}」', { name: escapeHtml(rule.name) })}"></button>
          <div class="conditional-format-rule-main">
            <div class="conditional-format-rule-name">${escapeHtml(rule.name)}</div>
            <div class="conditional-format-rule-meta">${escapeHtml(rule.appliesTo)} · <code title="${escapeHtml(rule.formula)}">${escapeHtml(rule.formula.length > 60 ? `${rule.formula.slice(0, 60)}…` : rule.formula)}</code></div>
          </div>
          <label class="conditional-format-rule-vis" title="${isHidden ? tOr('conditionalFormat.rule.hiddenTitle', '已隐藏：留在规则库但不应用') : tOr('conditionalFormat.rule.appliedTitle', '应用中')}">
            <input type="checkbox" data-action="toggle" ${isHidden ? '' : 'checked'} />
          </label>
          <div class="conditional-format-rule-actions">
            <button type="button" data-action="copy" title="${tOr('conditionalFormat.rule.copy', '复制')}">⧉</button>
            <button type="button" data-action="edit" title="${tOr('conditionalFormat.rule.edit', '编辑')}">✎</button>
            <button type="button" data-action="delete" title="${tOr('conditionalFormat.rule.delete', '删除')}">✕</button>
          </div>
        </div>`;
                })
                    .join('');
                return `
      <div class="conditional-format-group${isCollapsed ? ' is-collapsed' : ''}" data-group="${escapeHtml(group)}">
        <div class="conditional-format-group-title" title="${tOr('conditionalFormat.group.dragTitle', '拖动调整分组顺序（整组一起动）')}">
          <button type="button" class="conditional-format-group-toggle" data-action="toggle-group" aria-expanded="${isCollapsed ? 'false' : 'true'}" title="${isCollapsed ? tOr('conditionalFormat.group.expand', '展开分组') : tOr('conditionalFormat.group.collapse', '收起分组')}">${isCollapsed ? '▸' : '▾'}</button>
          <span class="conditional-format-group-name">${escapeHtml(group)}</span>
          <span class="conditional-format-group-count">${String(rules.length)}</span>
          <span class="conditional-format-group-actions">
            <button type="button" class="conditional-format-group-action" data-action="pick-group" data-group="${escapeHtml(group)}" title="${tOr('conditionalFormat.group.pickTitle', '全选 / 取消本组')}">☑</button>
            <button type="button" class="conditional-format-group-action" data-action="delete-group" data-group="${escapeHtml(group)}" title="${tOr('conditionalFormat.group.deleteTitle', '删除本组全部规则')}">🗑</button>
            <button type="button" class="conditional-format-group-action" data-action="export-group" data-group="${escapeHtml(group)}" title="${tOr('conditionalFormat.group.exportTitle', '导出本组所选规则')}">📤</button>
          </span>
        </div>
        ${rows}
      </div>`;
            })
                .join('');
    container
        .querySelectorAll('button[data-action="toggle-group"]')
        .forEach((button) => {
        button.addEventListener('click', () => {
            const group = button.closest('[data-group]')?.dataset.group ?? '';
            if (group === '')
                return;
            // 不可变更新：与 existingSelection 同口径，避免旧行模型与新 state 共享同一 Set
            const next = new Set(state.collapsedGroups);
            if (next.has(group))
                next.delete(group);
            else
                next.add(group);
            state.collapsedGroups = next;
            renderRuleList();
        });
    });
    // 组标题三件套：组内全选 / 组内删除 / 组内导出（momo：分组内也要能批量）
    container
        .querySelectorAll('button[data-action="pick-group"]')
        .forEach((button) => {
        button.addEventListener('click', () => {
            const group = button.dataset.group ?? '';
            if (group === '')
                return;
            const ids = state.rules.filter((rule) => rule.group === group).map((rule) => rule.id);
            const next = new Set(state.ruleSelection);
            // 组内已全勾 → 取消本组；否则补全本组（与「全选」按钮同语义）
            const isAllPicked = ids.length > 0 && ids.every((id) => next.has(id));
            for (const id of ids) {
                if (isAllPicked)
                    next.delete(id);
                else
                    next.add(id);
            }
            state.ruleSelection = next;
            renderRuleList();
        });
    });
    container
        .querySelectorAll('button[data-action="delete-group"]')
        .forEach((button) => {
        button.addEventListener('click', () => {
            const group = button.dataset.group ?? '';
            if (group === '')
                return;
            deleteSelectedRules(state.rules.filter((rule) => rule.group === group).map((r) => r.id));
        });
    });
    container
        .querySelectorAll('button[data-action="export-group"]')
        .forEach((button) => {
        button.addEventListener('click', () => {
            const group = button.dataset.group ?? '';
            if (group === '')
                return;
            exportSelectedRules(state.rules.filter((rule) => rule.group === group), `「${group}」分组`, tOr('conditionalFormat.export.labelGroup', '「{group}」分组', { group }));
        });
    });
    container.querySelectorAll('.conditional-format-rule').forEach((row) => {
        const id = row.dataset.ruleId ?? '';
        // 勾选（批量删除/导出语义，与可见性 toggle 分开）
        row.querySelectorAll('input[data-action="pick"]').forEach((box) => {
            box.addEventListener('change', () => {
                const next = new Set(state.ruleSelection);
                if (box.checked)
                    next.add(id);
                else
                    next.delete(id);
                state.ruleSelection = next;
                // 只刷批量条，不重渲列表（保住焦点：连勾十几条不用每次重新点）
                renderRuleBatchBar();
            });
        });
        row.querySelectorAll('input[data-action="toggle"]').forEach((box) => {
            box.addEventListener('change', () => {
                toggleHidden(id, !box.checked);
            });
        });
        row.querySelectorAll('button[data-action]').forEach((button) => {
            button.addEventListener('click', () => {
                const { action } = button.dataset;
                // 行内不再有 ↑↓：调序统一走拖拽（含键盘 Space + ↑↓）与右键菜单，
                // 省掉一列按钮，规则名与公式能多显示几个字
                switch (action) {
                    case 'copy': {
                        copyRules([id]);
                        break;
                    }
                    case 'edit': {
                        openEditor(id, false);
                        break;
                    }
                    // 点色块 = 点样式：与 ✎ 同一个编辑弹窗（momo：看到样式不对就直接点样式）
                    case 'edit-format': {
                        openEditor(id, false);
                        break;
                    }
                    case 'delete': {
                        deleteRule(id);
                        break;
                    }
                    default: {
                        break;
                    }
                }
            });
        });
    });
    // 拖拽排序：DOM 换了新节点，重新扫描补 tabindex / aria（键盘排序的前提）
    state.ruleSortable?.refresh();
    state.groupSortable?.refresh();
    // 表头是新节点，重插列宽/行高把手（decorate 幂等）
    state.tableResize.library?.decorate();
    maybeAutoFitTable('library');
    // 顶部批量条跟随勾选数显隐
    renderRuleBatchBar();
}
/**
 * 顶部批量操作条（规则管理）：全选 / 删除所选 / 导出所选
 *
 * 选中 0 条时整条隐藏——平时屏幕上只留「全选」一个入口，不添乱
 * （与既有规则表格的批量条同范式）。
 */
function renderRuleBatchBar() {
    const bar = byId('conditionalFormatRuleBatchBar');
    if (!bar)
        return;
    const count = state.ruleSelection.size;
    if (count === 0) {
        bar.replaceChildren();
        bar.classList.remove('is-visible');
        return;
    }
    bar.classList.add('is-visible');
    bar.innerHTML = `
    <span class="conditional-format-batch-count">${tOr('conditionalFormat.batch.selected', '已选 {count} 条', { count: String(count) })}</span>
    <button type="button" class="bgm-btn small" data-rule-batch="copy" title="${tOr('conditionalFormat.ruleBatch.copyTitle', '把所选规则复制进剪贴板（多条一起复制后，「粘贴」会以表格列出，可批量改范围）')}">${tOr('conditionalFormat.ruleBatch.copy', '⧉ 复制所选')}</button>
    <button type="button" class="bgm-btn small" data-rule-batch="edit" title="${tOr('conditionalFormat.ruleBatch.editTitle', '批量修改所选规则的应用范围 / 公式 / 颜色（可统一为某一条已有的值，也可自己填）')}">${tOr('conditionalFormat.ruleBatch.edit', '✎ 批量修改')}</button>
    <button type="button" class="bgm-btn small" data-rule-batch="delete" title="${tOr('conditionalFormat.ruleBatch.deleteTitle', '删除所选规则')}">${tOr('conditionalFormat.ruleBatch.delete', '🗑 删除所选')}</button>
    <button type="button" class="bgm-btn small" data-rule-batch="export" title="${tOr('conditionalFormat.ruleBatch.exportTitle', '导出所选规则为 JSON（选保存位置）')}">${tOr('conditionalFormat.ruleBatch.export', '📤 导出所选')}</button>
    <button type="button" class="bgm-btn small" data-rule-batch="clear" title="${tOr('conditionalFormat.batch.clearTitle', '取消选择')}">${tOr('conditionalFormat.batch.clear', '取消选择')}</button>`;
}
/** 批量删除所选规则（全选 / 组内 / 顶部批量条共用） */
function deleteSelectedRules(ids) {
    if (ids.length === 0) {
        showToast(tOr('conditionalFormat.toast.noSelectedRules', '没有选中的规则'), 'warn');
        return;
    }
    const removed = new Set(ids);
    state.rules = state.rules.filter((rule) => !removed.has(rule.id));
    // filter + has 而非 Set#difference：ES2022 无其类型（规则已在 eslint.config 排除）
    state.ruleSelection = new Set([...state.ruleSelection].filter((id) => !removed.has(id)));
    persistRules();
    renderRuleList();
    showToast(tOr('conditionalFormat.toast.deletedSelectedCount', '已删除 {count} 条规则', {
        count: String(ids.length),
    }), 'success');
}
const COLOR_FIELD_FILL = {
    picker: 'conditionalFormatEditFill',
    text: 'conditionalFormatEditFillText',
};
const COLOR_FIELD_FONT = {
    picker: 'conditionalFormatEditFont',
    text: 'conditionalFormatEditFontText',
};
const COLOR_FIELDS = [COLOR_FIELD_FILL, COLOR_FIELD_FONT];
/** 把颜色写进字段两件套（选择器 + 文本），保持两边永远一致 */
function setColorField(field, hex) {
    const picker = inputById(field.picker);
    const text = inputById(field.text);
    if (picker)
        picker.value = hex;
    if (text)
        text.value = hex;
}
/** 读颜色字段的权威值（文本优先）；文本非法时回落选择器值，再不行给 fallback */
function readColorField(field, fallback) {
    const fromText = normalizeHexColor(inputById(field.text)?.value ?? '');
    if (fromText !== null)
        return fromText;
    const fromPicker = normalizeHexColor(inputById(field.picker)?.value ?? '');
    return fromPicker ?? fallback;
}
/**
 * 装配一个颜色字段：选择器 / 文本两边联动
 *
 * - 选择器 change → 同步文本；
 * - 文本 input → 合法 hex 实时同步选择器（用户看着色块确认输对）；
 * - 文本 blur → 规范化成 `#RRGGBB` 大写；非法则还原成选择器当前值
 *   （不清空：清空像字段坏了，还原至少保住一个有效色）。
 */
function bindColorField(field) {
    const picker = inputById(field.picker);
    const text = inputById(field.text);
    if (!picker || !text)
        return;
    picker.addEventListener('change', () => {
        setColorField(field, picker.value);
    });
    text.addEventListener('input', () => {
        const normalized = normalizeHexColor(text.value);
        if (normalized !== null)
            picker.value = normalized;
    });
    text.addEventListener('blur', () => {
        const normalized = normalizeHexColor(text.value);
        text.value = normalized ?? picker.value;
    });
}
/** 弹窗遮罩计数锁：多个弹窗同时开时，不能有一个关闭就解锁背景滚动 */
let modalScrollLockCount = 0;
/**
 * 把弹窗遮罩锚定到「当前可见区顶部」
 *
 * WPS 任务窗格里 iframe 视口常常等于**内容全高**（长页面不产生窗格内滚动条，
 * 而是 iframe 被内容撑高）：fixed + flex-center 会把弹窗放到文档中部、落在
 * 任务窗格可见区外（momo 实测：弹窗出现在页面上方、窗口外）。
 * absolute 遮罩 + top=scrollY 补偿滚动，在「iframe=可见区」与「iframe=内容高」
 * 两种宿主模型下都落在可见区内。顺带打一条诊断日志确认宿主模型。
 */
function anchorModalMask(mask) {
    // setProperty 而非 mask.style.top = ...：后者踩 no-param-reassign（禁给参数属性赋值）
    mask.style.setProperty('top', `${String(window.scrollY)}px`);
    bgmLog(LOG_LEVELS.INFO, `[conditionalFormat] 弹窗定位: innerHeight=${String(window.innerHeight)} scrollY=${String(window.scrollY)} clientHeight=${String(document.documentElement.clientHeight)} scrollHeight=${String(document.documentElement.scrollHeight)}`);
}
/**
 * 按配置套「模态框按钮外置」类（momo：按钮可放到模态框之外）
 *
 * 每次打开弹窗时读一次配置（设置页改完，下次打开即生效）——跨窗格不做即时
 * 同步，与「高亮模式 / 自动关注上移设置页」同策略：读的时候重算，不推。
 * 类名只切显隐与定位，不动 DOM 结构（按钮组始终在 modal 里，CSS 决定它
 * 坐在底部还是标题栏那一行）。
 */
function applyModalButtonsPosition(modal) {
    const isOutside = getModalButtonsPosition(true) === 'outside';
    modal.classList.toggle('conditional-format-modal--buttons-outside', isOutside);
}
/** 锁背景滚动（弹窗打开期间；计数式，多弹窗叠加不会早解） */
function lockModalScroll() {
    modalScrollLockCount += 1;
    document.body.style.overflow = 'hidden';
}
/** 解背景滚动（计数归零才真解） */
function unlockModalScroll() {
    modalScrollLockCount = Math.max(0, modalScrollLockCount - 1);
    if (modalScrollLockCount === 0)
        document.body.style.overflow = '';
}
// ===== 规则编辑器（浮动弹窗）=====
function blankRule() {
    return {
        id: nextId(),
        name: '',
        group: CONDITIONAL_FORMAT_GROUP_HIGHLIGHT,
        appliesTo: '',
        formula: '',
        interior: '#00B050',
    };
}
/** 「名称 / 分组」两块只在规则库模式显示（工作表上的规则没有名字与分组） */
function setEditorLibraryFieldsVisible(isVisible) {
    const fields = byId('conditionalFormatEditLibraryFields');
    if (fields)
        fields.hidden = !isVisible;
}
/** 打开编辑器遮罩（定位三件套 + 滚动锁；两种模式共用） */
function openEditorMask() {
    const mask = byId('conditionalFormatEditorMask');
    const modal = mask?.querySelector('.conditional-format-modal');
    if (mask) {
        // 每次打开都回到遮罩居中位：不记住上次拖动的位置——模态框是一次性交互，
        // 记住旧位置只会让用户在老地方找一个刚打开的框
        if (modal) {
            resetModalPosition(modal);
            applyModalButtonsPosition(modal);
        }
        anchorModalMask(mask);
        mask.style.display = 'flex';
        // 打开后拉回可见区：页面滚动后模态框会落在可见区外（实测标题栏被切半个），
        // 量一次、越界就滚回来并重锚遮罩（见 modal-drag.ts 注释）
        if (modal)
            bringModalIntoView(mask, modal);
    }
    lockModalScroll();
}
function openEditor(id, isNew) {
    state.editingId = id;
    state.editingIsNew = isNew;
    state.editingTarget = 'library';
    state.editingExistingIndex = 0;
    const rule = id ? state.rules.find((r) => r.id === id) : blankRule();
    if (!rule)
        return;
    setEditorLibraryFieldsVisible(true);
    const nameInput = inputById('conditionalFormatEditName');
    const groupInput = inputById('conditionalFormatEditGroup');
    const rangeInput = inputById('conditionalFormatEditRange');
    const formulaInput = byId('conditionalFormatEditFormula');
    const boldInput = inputById('conditionalFormatEditBold');
    if (nameInput)
        nameInput.value = rule.name;
    if (groupInput)
        groupInput.value = rule.group;
    if (rangeInput)
        rangeInput.value = rule.appliesTo;
    if (formulaInput)
        formulaInput.value = rule.formula;
    // 颜色两件套一起写：只写一边会让文本与色块不一致（用户看到的是旧色）
    setColorField(COLOR_FIELD_FILL, normalizeHexColor(rule.interior) ?? '#00B050');
    setColorField(COLOR_FIELD_FONT, normalizeHexColor(rule.fontColor ?? '') ?? '#000000');
    if (boldInput)
        boldInput.checked = rule.fontBold === true;
    openEditorMask();
    setText('conditionalFormatEditorLabel', isNew
        ? tOr('conditionalFormat.editor.newRule', '新建规则')
        : tOr('conditionalFormat.editor.editRule', '编辑：{name}', {
            name: rule.name || tOr('conditionalFormat.editor.untitled', '未命名'),
        }));
}
/**
 * 打开编辑器编辑工作表上第 index 条既有规则（范围 / 公式 / 颜色）
 *
 * 与规则库编辑共用弹窗，但保存路径完全不同：这里**直接写工作表**（COM），
 * 不碰 PluginStorage —— 用户看到的那条规则改完立刻生效，不用再去点应用。
 * 「名称 / 分组」隐藏：宿主没有这两个概念，露出来只会让人以为能改。
 */
function openExistingRuleEditor(index) {
    const snapshot = state.existing[index - 1];
    if (!snapshot) {
        showToast(tOr('conditionalFormat.toast.ruleMissing', '规则已不存在，请重新读取'), 'warn');
        return;
    }
    state.editingTarget = 'worksheet';
    state.editingExistingIndex = index;
    state.editingId = null;
    state.editingIsNew = false;
    setEditorLibraryFieldsVisible(false);
    const rangeInput = inputById('conditionalFormatEditRange');
    const formulaInput = byId('conditionalFormatEditFormula');
    const boldInput = inputById('conditionalFormatEditBold');
    if (rangeInput)
        rangeInput.value = snapshot.range;
    if (formulaInput)
        formulaInput.value = snapshot.formula;
    const fill = normalizeHexColor(snapshot.interior ?? '') ?? '#00B050';
    const font = normalizeHexColor(snapshot.fontColor ?? '') ?? '#000000';
    setColorField(COLOR_FIELD_FILL, fill);
    setColorField(COLOR_FIELD_FONT, font);
    // 既有规则的加粗读不到（快照里没有该字段），一律按未勾处理：不勾 = 不改
    if (boldInput)
        boldInput.checked = false;
    state.editingBaseline = {
        range: snapshot.range,
        formula: snapshot.formula,
        fill,
        font,
        bold: false,
    };
    openEditorMask();
    setText('conditionalFormatEditorLabel', tOr('conditionalFormat.editor.editSheetRule', '编辑工作表规则 #{index}', {
        index: String(index),
    }));
}
function closeEditor() {
    state.editingId = null;
    state.editingIsNew = false;
    state.editingTarget = 'library';
    state.editingExistingIndex = 0;
    state.editingBaseline = null;
    const mask = byId('conditionalFormatEditorMask');
    // 没开 = no-op：Esc 块连调五个 close，没开的弹窗不能动共享的滚动锁计数
    // （modalScrollLockCount 是计数式；空关一次就把别的弹窗的锁解掉了）
    if (mask?.style.display === 'none')
        return;
    if (mask) {
        mask.style.display = 'none';
    }
    unlockModalScroll();
}
/**
 * 保存「工作表规则」的编辑（直接写 COM）
 *
 * 逐字段只写**真的改了**的项：范围 / 公式 / 颜色分别落到 ModifyAppliesToRange /
 * Formula1 / With 上。写失败（含回读不一致）时**弹窗不关**，把错误留在用户眼前，
 * 避免「以为改了、其实没改」——这正是这次反馈的核心问题。
 */
function saveExistingRuleEdit() {
    const entry = selectedSheet();
    if (!entry) {
        showToast(tOr('conditionalFormat.toast.selectTargetSheet', '请先选择目标工作表'), 'warn');
        return;
    }
    const index = state.editingExistingIndex;
    const snapshot = state.existing[index - 1];
    if (!snapshot) {
        showToast(tOr('conditionalFormat.toast.ruleMissing', '规则已不存在，请重新读取'), 'warn');
        closeEditor();
        return;
    }
    const rangeInput = inputById('conditionalFormatEditRange');
    const formulaInput = byId('conditionalFormatEditFormula');
    const boldInput = inputById('conditionalFormatEditBold');
    const range = rangeInput?.value.trim() ?? '';
    if (range === '') {
        showToast(tOr('conditionalFormat.toast.rangeRequired', '应用范围不能为空'), 'warn');
        return;
    }
    const formula = formulaInput?.value.trim() ?? '';
    // 公式只在「原本就有公式」时必填：数据条 / 色阶 / 图标集这类规则的 Formula1 本来就是空的，
    // 强制必填会让用户连范围都改不了
    if (formula === '' && snapshot.formula !== '') {
        showToast(tOr('conditionalFormat.toast.formulaRequired', '公式不能为空'), 'warn');
        return;
    }
    const fillColor = readColorField(COLOR_FIELD_FILL, snapshot.interior ?? '#00B050');
    const fontColor = readColorField(COLOR_FIELD_FONT, snapshot.fontColor ?? '#000000');
    const isBold = boldInput?.checked === true;
    // 与「打开时的初值」比，而不是与快照比：宿主读不到颜色时预填的是默认色，
    // 拿快照比会把默认色当成改动写回去（只改公式却把字体染黑）
    const baseline = state.editingBaseline;
    const result = updateForeignRule(entry.worksheet, index, {
        ...(range !== (baseline?.range ?? snapshot.range) && { range }),
        ...(formula !== (baseline?.formula ?? snapshot.formula) && formula !== '' && { formula }),
        ...(fillColor !== baseline?.fill && { interior: fillColor }),
        ...(fontColor !== baseline?.font && { fontColor }),
        ...(isBold !== (baseline?.bold ?? false) && { fontBold: isBold }),
    });
    if (!result.ok) {
        showToast(tOr('conditionalFormat.toast.modifyFailed', '修改失败：{error}', {
            error: result.error,
        }), 'error');
        return;
    }
    closeEditor();
    showToast(tOr('conditionalFormat.toast.ruleUpdated', '第 {index} 条已更新：{changed}', {
        index: String(index),
        changed: result.changed.join(' / '),
    }), 'success');
    for (const warning of result.warnings)
        showToast(warning, 'warn');
    // 写回成功后重新读表：以宿主实际状态为准（也顺带刷新分组 key 的锚定）
    loadExistingRules();
    renderRuleList();
}
function saveEditor() {
    if (state.editingTarget === 'worksheet') {
        saveExistingRuleEdit();
        return;
    }
    const nameInput = inputById('conditionalFormatEditName');
    const groupInput = inputById('conditionalFormatEditGroup');
    const rangeInput = inputById('conditionalFormatEditRange');
    const formulaInput = byId('conditionalFormatEditFormula');
    const boldInput = inputById('conditionalFormatEditBold');
    const name = nameInput?.value.trim() ?? '';
    const appliesTo = rangeInput?.value.trim() ?? '';
    const formula = formulaInput?.value.trim() ?? '';
    if (!name || !appliesTo || !formula) {
        showToast(tOr('conditionalFormat.toast.nameRangeFormulaRequired', '名称、范围、公式都不能为空'), 'warn');
        return;
    }
    const existing = state.editingId ? state.rules.find((r) => r.id === state.editingId) : undefined;
    const groupText = groupInput?.value.trim() ?? '';
    // 颜色走 readColorField：文本（可手输 hex）权威，非法时回落选择器值
    const fillColor = readColorField(COLOR_FIELD_FILL, '#00B050');
    const fontColor = readColorField(COLOR_FIELD_FONT, '#000000');
    const isBold = boldInput?.checked === true;
    const rule = {
        id: existing?.id ?? nextId(),
        name,
        group: groupText === '' ? CONDITIONAL_FORMAT_GROUP_HIGHLIGHT : groupText,
        appliesTo,
        formula,
        interior: fillColor,
        fontColor,
        ...(isBold && { fontBold: true }),
        ...(existing?.hidden !== undefined && { hidden: existing.hidden }),
    };
    state.rules = existing
        ? state.rules.map((r) => (r.id === rule.id ? rule : r))
        : [...state.rules, rule];
    persistRules();
    closeEditor();
    renderRuleList();
    // 不在这里单独提示「要去点应用」：persistRules 已统一弹「未应用」toast，
    // 两处各弹一条会让同一次保存出现两个内容相近的提示
}
// ===== 默认规则集 =====
function detectColumns() {
    const entry = selectedSheet();
    if (!entry)
        return null;
    const headerRow = findHeaderRow(entry.worksheet);
    const columnMap = getColumnMap(entry.worksheet, headerRow);
    const seasonColumnNumber = columnMap.get('开播季度');
    const nameColumnNumber = columnMap.get('名称');
    if (seasonColumnNumber === undefined || nameColumnNumber === undefined)
        return null;
    return {
        seasonColumn: columnNumberToLetter(seasonColumnNumber),
        nameColumn: columnNumberToLetter(nameColumnNumber),
        firstRow: headerRow + 1,
    };
}
function generateDefaults() {
    const detected = detectColumns();
    if (!detected) {
        showToast(tOr('conditionalFormat.toast.noSeasonColumn', '未识别到「开播季度」或「名称」列，无法生成默认规则（公式依赖季列）'), 'warn');
        return;
    }
    const defaults = buildDefaultRules({ ...detected, makeId: nextId });
    state.rules = [...state.rules, ...defaults];
    persistRules();
    renderRuleList();
    showToast(tOr('conditionalFormat.toast.defaultsAppended', '已追加 {count} 条默认规则（季列 {season} · 名称列 {name}）', {
        count: String(defaults.length),
        season: detected.seasonColumn,
        name: detected.nameColumn,
    }), 'success');
}
// ===== 应用流程（merge 增量 / replace 整表重来）=====
/**
 * 把体检弹窗改好的规则写回规则库
 *
 * 按下标定位：`visible` 是 `state.rules` 去掉隐藏项后的同序子集，
 * 弹窗条目的 `key` 就是它在这个子集里的下标。
 */
function writeBackDoctorFixes(visible, fixed) {
    const patched = patchRulesByKey(visible, fixed);
    const patchedById = new Map(patched.map((rule) => [rule.id, rule]));
    // 隐藏的规则不参与应用，也不该被这次修改波及
    state.rules = state.rules.map((rule) => patchedById.get(rule.id) ?? rule);
    persistRules(false);
    renderRuleList();
}
/**
 * 应用后「没落地 / 写入失败」的规则进体检弹窗
 *
 * 与导入前预检不同：这里的规则**已经试过一次了**，所以要带上宿主给的真实原因
 * （`result.failures[].reason`）—— 用户改的是「宿主嫌什么」，不用猜。
 */
function openFailureDoctor(result, strategy, visible) {
    const entries = [];
    const taken = new Set();
    // 逐条失败原因（宿主不支持条件格式时也有：`failures` 与 `missing` 二选一或都有）
    const { failures } = result;
    for (const failure of failures) {
        const index = state.rules.findIndex((rule) => rule.name === failure.name);
        if (index !== -1)
            taken.add(index);
        const found = index === -1 ? undefined : state.rules[index];
        entries.push({
            key: String(index),
            rule: found ?? {
                id: '',
                name: failure.name,
                group: IMPORTED_GROUP,
                appliesTo: failure.range,
                formula: failure.formula,
                interior: '#CCCCCC',
            },
            issues: found === undefined ? [] : inspectRule(found),
            reason: failure.reason,
        });
    }
    for (const name of result.missing) {
        const index = state.rules.findIndex((rule) => rule.name === name);
        // 失败原因里列过的不重复；库里没有的（不该发生）也不硬造卡片
        const found = index === -1 ? undefined : state.rules[index];
        if (found !== undefined && !taken.has(index)) {
            taken.add(index);
            entries.push({
                key: String(index),
                rule: found,
                issues: inspectRule(found),
                reason: tOr('conditionalFormat.doctor.hostDropped', '写入后回读不到：宿主可能丢掉了这条，或把范围改写成了别的写法'),
            });
        }
    }
    if (entries.length === 0)
        return;
    openRuleDoctor({
        mode: 'apply',
        entries,
        hint: tOr('conditionalFormat.doctor.applyHint', '这 {count} 条没写进工作表。带「宿主原因」的是 WPS 返回的真实报错；改完点「修复并应用」重跑。', { count: String(entries.length) }),
        onConfirm: (fixed) => {
            writeBackDoctorFixes(visible, fixed);
            runApply(strategy);
        },
    });
}
/** 读「插件写过哪些规则」的账本（按工作表名分桶） */
function readAppliedBuckets() {
    return parseAppliedRules(getConfig(APPLIED_RULES_STORE_KEY, '', true));
}
/**
 * 记下这一轮写进工作表的规则指纹
 *
 * 下一轮靠它区分「自己上一轮写的」与「用户手工建的」——只有前者才允许被移除。
 * 写入失败也照记：指纹只是「曾经想写这些」，下一轮仍以工作表实际快照为准
 * （找不到就重加，找到就刷新），记多了不会误删别人的规则。
 *
 * @param records 空数组 = 这张表已无插件规则，把桶摘掉（不留空壳）
 */
function saveAppliedRecords(sheetName, records) {
    const buckets = readAppliedBuckets();
    const next = Object.fromEntries(Object.entries(buckets).filter(([name]) => name !== sheetName));
    if (records.length > 0)
        next[sheetName] = [...records];
    setConfig(APPLIED_RULES_STORE_KEY, serializeAppliedRules(next));
}
/**
 * 执行一次应用
 *
 * @param strategy `merge`（默认，只动自己那份）/ `replace`（清空整表后重建）
 */
function runApply(strategy) {
    const entry = selectedSheet();
    if (!entry) {
        showToast(tOr('conditionalFormat.toast.selectTargetSheet', '请先选择目标工作表'), 'warn');
        return;
    }
    if (!isFormatConditionsSupported(entry.worksheet)) {
        showToast(tOr('conditionalFormat.toast.unsupportedApiFeature', '当前 WPS 版本不支持条件格式 API，该功能不可用'), 'error');
        return;
    }
    const visible = state.rules.filter((rule) => rule.hidden !== true);
    if (visible.length === 0) {
        showToast(tOr('conditionalFormat.toast.noApplicableRules', '没有可应用的规则（全部隐藏了？）'), 'warn');
        return;
    }
    // 应用前体检：库里的规则可能被手改成脏的（范围带表名、公式引号没配对…），
    // 与其写一半被宿主拒、只留一句 toast，不如先摆在弹窗里让用户改完再写。
    const blocked = blockingEntriesOf(visible);
    if (blocked.length > 0) {
        openRuleDoctor({
            mode: 'apply',
            entries: blocked,
            hint: tOr('conditionalFormat.doctor.blockedHintApply', '这 {count} 条的范围 / 公式不合法，宿主会直接拒绝。改完点「修复并应用」继续，其余 {rest} 条不受影响。', {
                count: String(blocked.length),
                rest: String(visible.length - blocked.length),
            }),
            onConfirm: (fixed) => {
                writeBackDoctorFixes(visible, fixed);
                runApply(strategy);
            },
        });
        return;
    }
    const foreign = readForeignRules(entry.worksheet);
    const previous = readAppliedBuckets()[entry.sheet] ?? [];
    const plan = planApply(state.rules, foreign, strategy, previous);
    // 计划自带的说明（要移除几条自己的旧规则 / 整表将被清空多少条）进日志：
    // toast 只报结果条数，这些「为什么动了 N 条」的上下文排障时才用得上
    if (plan.warnings.length > 0) {
        bgmLog(LOG_LEVELS.INFO, `[conditionalFormat] 应用计划：${plan.warnings.join('；')}`);
    }
    const result = applyConditionalFormatPlan(entry.worksheet, plan);
    // 记账：下一轮「只清自己那份」全靠它
    saveAppliedRecords(entry.sheet, visible.map((rule) => ({ range: rule.appliesTo, formula: rule.formula })));
    // 写调用返回成功 ≠ 每条都真落地：`missing` 是写后回读不到的具体规则名。
    // 只报总数会把「局部失败」说成「已写入 N 条」，用户去表上找不到却无从定位。
    if (result.missing.length > 0) {
        const shown = result.missing.slice(0, 3).join(' / ');
        const more = result.missing.length > 3
            ? tOr('conditionalFormat.toast.missingMore', ' 等 {count} 条', {
                count: String(result.missing.length),
            })
            : '';
        // 弹窗里能改、能自动修、能直接重来 —— toast 只负责报「有几条」，不再让用户去翻日志
        showToast(tOr('conditionalFormat.toast.rulesNotWritten', '{count} 条规则没写进工作表：{shown}{more}（已打开「规则体检」，可就地改完重应用）', {
            count: String(result.missing.length),
            shown,
            more,
        }), 'error');
        openFailureDoctor(result, strategy, visible);
    }
    else if (result.failed > 0) {
        showToast(tOr('conditionalFormat.toast.addedAndFailed', '新增 {added} 条，失败 {failed} 条（详见日志）', {
            added: String(result.added),
            failed: String(result.failed),
        }), 'warn');
    }
    else {
        const parts = [
            tOr('conditionalFormat.toast.appliedAdded', '新增 {count} 条', {
                count: String(result.added),
            }),
        ];
        if (result.refreshed > 0) {
            parts.push(tOr('conditionalFormat.toast.appliedRefreshed', '刷新 {count} 条', {
                count: String(result.refreshed),
            }));
        }
        if (result.deleted > 0) {
            parts.push(tOr('conditionalFormat.toast.appliedDeleted', '移除旧规则 {count} 条', {
                count: String(result.deleted),
            }));
        }
        const verifiedNote = result.verified >= 0
            ? tOr('conditionalFormat.toast.appliedVerified', '，表上共 {count} 条', {
                count: String(result.verified),
            })
            : '';
        const separator = tOr('conditionalFormat.page.listSeparator', '，');
        showToast(tOr('conditionalFormat.toast.applied', '已应用：{parts}{verified}', {
            parts: parts.join(separator),
            verified: verifiedNote,
        }), 'success');
    }
    const summary = [
        tOr('conditionalFormat.status.summaryAdded', '新增 {count}', {
            count: String(result.added),
        }),
        tOr('conditionalFormat.status.summaryRefreshed', '刷新 {count}', {
            count: String(result.refreshed),
        }),
        tOr('conditionalFormat.status.summaryDeleted', '移除 {count}', {
            count: String(result.deleted),
        }),
        tOr('conditionalFormat.status.summaryFailed', '失败 {count}', {
            count: String(result.failed),
        }),
    ].join(' · ');
    const verifiedText = result.verified >= 0
        ? tOr('conditionalFormat.status.verified', ' · 表上 {count} 条', {
            count: String(result.verified),
        })
        : '';
    const missingText = result.missing.length > 0
        ? tOr('conditionalFormat.status.missing', ' · 未落地 {count}', {
            count: String(result.missing.length),
        })
        : '';
    setText('conditionalFormatApplyStatus', tOr('conditionalFormat.status.line', '上次应用（{strategy}）：{sheet} · {summary}{verified}{missing}', {
        strategy: strategy === 'replace'
            ? tOr('conditionalFormat.status.strategyReplace', '清空整表')
            : tOr('conditionalFormat.status.strategyMerge', '增量'),
        sheet: entry.sheet,
        summary,
        verified: verifiedText,
        missing: missingText,
    }));
    // 应用完重读表：让「工作表规则」立刻显示刚落地的规则（不再需要手动点「重新读取」）
    loadExistingRules();
}
/**
 * 打开「清空整表后应用」的确认弹框
 *
 * 只有这条路会动别人的规则，所以必须先把将被丢弃的规则列清楚。
 * 常规「应用条件格式」走 {@link runApply}('merge')，不弹框——它不清除任何东西，
 * 弹框只会让用户误以为有风险（旧实现每次应用都弹，是「点应用规则没了」的帮凶）。
 */
function openConfirmModal(foreign) {
    const mask = byId('conditionalFormatConfirmMask');
    const body = byId('conditionalFormatConfirmBody');
    if (!mask || !body)
        return;
    const rows = foreign
        .map((rule) => `<li><code>${escapeHtml(rule.range)}</code> — ${escapeHtml(rule.formula ||
        tOr('conditionalFormat.confirm.formulaUnread', '（{kind}规则，公式未读到）', {
            kind: rule.kind === 'expression'
                ? tOr('conditionalFormat.confirm.kindExpression', '公式类')
                : tOr('conditionalFormat.confirm.kindOther', '非公式类'),
        }))}</li>`)
        .join('');
    body.innerHTML = `
    ${tOr('conditionalFormat.confirm.clearBody', '<p>这一步会<strong>清空目标工作表上的全部 {count} 条条件格式规则</strong>，再按规则库重建。</p>', { count: String(foreign.length) })}
    <p class="conditional-format-modal-label">${tOr('conditionalFormat.confirm.clearListLabel', '将被清掉的规则：')}</p>
    <ul class="conditional-format-modal-list">${rows}</ul>
    <p class="conditional-format-modal-label">
      ${tOr('conditionalFormat.confirm.clearKeepHint', '只想把规则库写进表、保留这些规则？关掉本框，点「🖌️ 应用条件格式」即可——它不会清除任何既有规则。')}
    </p>`;
    const clearButton = byId('conditionalFormatConfirmClear');
    if (clearButton) {
        clearButton.textContent = tOr('conditionalFormat.confirm.clearButton', '确认清空整表后应用');
    }
    // mask 在函数入口已判非 null（!mask || !body 早退），直接用
    const modal = mask.querySelector('.conditional-format-modal');
    if (modal) {
        resetModalPosition(modal);
        applyModalButtonsPosition(modal);
    }
    anchorModalMask(mask);
    mask.style.display = 'flex';
    if (modal)
        bringModalIntoView(mask, modal);
    lockModalScroll();
    byId('conditionalFormatConfirmCancel')?.focus();
}
function closeConfirmModal() {
    const mask = byId('conditionalFormatConfirmMask');
    // 没开 = no-op：Esc 块连调五个 close，没开的弹窗不能动共享的滚动锁计数
    // （modalScrollLockCount 是计数式；空关一次就把别的弹窗的锁解掉了）
    if (mask?.style.display === 'none')
        return;
    if (mask) {
        mask.style.display = 'none';
    }
    unlockModalScroll();
}
/** 常规应用：增量写规则库，**不清除任何既有规则**（无确认框） */
function applyFlow() {
    runApply('merge');
}
/** 整表重来：清空目标表全部规则后重建（危险操作，先列清单再确认） */
function replaceFlow() {
    const entry = selectedSheet();
    if (!entry) {
        showToast(tOr('conditionalFormat.toast.selectTargetSheet', '请先选择目标工作表'), 'warn');
        return;
    }
    if (!isFormatConditionsSupported(entry.worksheet)) {
        showToast(tOr('conditionalFormat.toast.unsupportedApiFeature', '当前 WPS 版本不支持条件格式 API，该功能不可用'), 'error');
        return;
    }
    const visibleCount = state.rules.filter((rule) => rule.hidden !== true).length;
    if (visibleCount === 0) {
        showToast(tOr('conditionalFormat.toast.noApplicableRules', '没有可应用的规则（全部隐藏了？）'), 'warn');
        return;
    }
    const foreign = readForeignRules(entry.worksheet);
    if (foreign.length === 0) {
        runApply('replace');
        return;
    }
    openConfirmModal(foreign);
}
// ===== 导入规则（工作表规则 / 文件 / 文本）=====
function importForeign() {
    const entry = selectedSheet();
    if (!entry) {
        showToast(tOr('conditionalFormat.toast.selectTargetSheet', '请先选择目标工作表'), 'warn');
        return;
    }
    if (!isFormatConditionsSupported(entry.worksheet)) {
        showToast(tOr('conditionalFormat.toast.unsupportedApi', '当前 WPS 版本不支持条件格式 API'), 'error');
        return;
    }
    const foreign = readForeignRules(entry.worksheet);
    if (foreign.length === 0) {
        showToast(tOr('conditionalFormat.toast.sheetHasNoRules', '这张表没有条件格式规则（可在「既有规则」卡片确认）'), 'info');
        loadExistingRules();
        return;
    }
    // 不再一键全导：弹选择框让用户挑（momo：#conditionalFormatImportBtn 直接导了全部）
    openImportModal(foreign, entry.sheet);
}
/**
 * 「导入」主按钮旁的 ▾ 菜单：两个来源
 *
 * 主按钮是「导入工作表规则」（当前表既有规则）；文件那条用于「别的表、别的电脑、
 * 备份文件」——「导出规则 → 导出到文件」得到的 .json 就走它，是跨设备迁移规则的
 * 唯一通道。
 *
 * 「从文本导入」已并入「📋 粘贴 ▾」（2026-10-29）：它和粘贴是同一个动作——
 * 把一段 JSON 变成规则副本，只是来源不同。按来源分入口，用户不会在「粘贴」里
 * 碰壁后再去找「导入」。
 */
function openImportMenu(button) {
    const rect = button.getBoundingClientRect();
    showContextMenu({
        items: [
            {
                id: 'import-worksheet',
                label: tOr('conditionalFormat.import.fromSheet', '📥 导入工作表规则（当前表）'),
                onSelect: () => {
                    importForeign();
                },
            },
            {
                id: 'import-file',
                label: tOr('conditionalFormat.import.fromFile', '📂 从文件导入（.json 规则文件）'),
                onSelect: () => {
                    importRulesFromFile();
                },
            },
        ],
        x: rect.left,
        y: rect.bottom + 4,
        anchor: button,
    });
}
/**
 * 打开文件选择器（项目导出的 .json 规则文件）
 *
 * 用 `input[type=file]` + FileReader 而不是 COM：FileReader 自带 BOM 嗅探，
 * 项目导出的 UTF-16 LE（带 BOM）和别处的 UTF-8 都能读；FSO 的 OpenTextFile
 * 必须**事先知道**编码，读错就是乱码。
 */
function importRulesFromFile() {
    const input = byId('conditionalFormatImportFile');
    if (!(input instanceof HTMLInputElement)) {
        showToast(tOr('conditionalFormat.toast.hostNoFilePicker', '当前宿主不支持文件选择，改用「📋 粘贴 ▾ → 从文本粘贴」'), 'warn');
        return;
    }
    // 清空 value：连续选同一个文件也要触发 change
    input.value = '';
    input.click();
}
/** 文件选择器的 change：读文本 → 走与文本导入同一条合并通道 */
function handleImportFileChange(event) {
    const input = event.target;
    if (!(input instanceof HTMLInputElement))
        return;
    const file = input.files?.[0];
    if (!file)
        return;
    const reader = new FileReader();
    reader.addEventListener('load', () => {
        const text = typeof reader.result === 'string' ? reader.result : '';
        importRulesFromText(text, file.name);
    });
    reader.addEventListener('error', () => {
        showToast(tOr('conditionalFormat.toast.readFileFailed', '读取文件失败：{name}', {
            name: file.name,
        }), 'error');
    });
    // 不传编码：交给 FileReader 按 BOM 判断（见 importRulesFromFile 的注释）。
    // 不能用 file.text()：它只按 UTF-8 解码，读项目自己导出的 UTF-16 LE 就是乱码。
    // eslint-disable-next-line unicorn/prefer-blob-reading-methods -- 见上：需按 BOM 嗅探解码
    reader.readAsText(file);
}
/** 规则身份键：导入去重用（同一条规则重复导入只会把库撑大） */
function ruleIdentity(rule) {
    return [
        rule.name,
        rule.appliesTo,
        rule.formula,
        rule.interior,
        rule.fontColor ?? '',
        String(rule.fontBold === true),
    ].join('\u{0}');
}
/**
 * 把外来规则并进「我的规则」
 *
 * id 一律重新生成：文件里的 id 来自别的库，直接沿用会和现有条目撞。
 * 与库里**完全相同**的条目（名称/范围/公式/配色全等）跳过——重复导入同一份
 * 文件不该让规则翻倍。
 */
function mergeRulesIntoLibrary(incoming) {
    const seen = new Set(state.rules.map((rule) => ruleIdentity(rule)));
    const merged = [];
    let skipped = 0;
    for (const rule of incoming) {
        const key = ruleIdentity(rule);
        if (seen.has(key)) {
            skipped += 1;
        }
        else {
            seen.add(key);
            merged.push({ ...rule, id: nextId() });
        }
    }
    if (merged.length > 0) {
        state.rules = [...state.rules, ...merged];
        // 不弹 persistRules 的「未应用」提示：下面这条 toast 自带同样的指引，
        // 两条连发会互相覆盖，用户只看得到后一条
        persistRules(false);
        renderRuleList();
    }
    return { added: merged.length, skipped };
}
/** 解析并导入一段规则 JSON（文件与文本两条通道共用） */
function importRulesFromText(text, source) {
    const { rules, dropped } = parseRulesPayload(text);
    if (rules.length === 0) {
        showToast(dropped > 0
            ? tOr('conditionalFormat.import.noRecognizable', '「{source}」里没有可识别的规则（不是规则 JSON？）', { source })
            : tOr('conditionalFormat.import.sourceEmpty', '「{source}」是空的，没有可导入的规则', {
                source,
            }), 'warn');
        return;
    }
    const blocked = blockingEntriesOf(rules);
    if (blocked.length > 0) {
        openRuleDoctor({
            mode: 'import',
            entries: blocked,
            hint: tOr('conditionalFormat.doctor.importBlockedHint', '「{source}」里有 {count} 条范围 / 公式不合法，宿主会拒绝写入。改完点「修复并导入」继续（其余条目不受影响）。', { source, count: String(blocked.length) }),
            onConfirm: (fixed) => {
                finishImportFromText(patchRulesByKey(rules, fixed), source, dropped);
            },
        });
        return;
    }
    finishImportFromText(rules, source, dropped);
}
/** 文本 / 文件导入的终点（体检通过后） */
function finishImportFromText(rules, source, dropped) {
    const { added, skipped } = mergeRulesIntoLibrary(rules);
    const details = [];
    if (skipped > 0) {
        details.push(tOr('conditionalFormat.toast.importSkippedDuplicate', '跳过 {count} 条重复', {
            count: String(skipped),
        }));
    }
    if (dropped > 0) {
        details.push(tOr('conditionalFormat.toast.importDroppedInvalid', '{count} 条格式不对未导入', {
            count: String(dropped),
        }));
    }
    const suffix = details.length === 0
        ? ''
        : tOr('conditionalFormat.page.parenSuffix', '（{items}）', {
            items: details.join(tOr('conditionalFormat.page.listSeparator', '，')),
        });
    if (added === 0) {
        showToast(tOr('conditionalFormat.toast.allRulesAlreadyExist', '「{source}」里的规则都已存在{suffix}', {
            source,
            suffix,
        }), 'info');
        return;
    }
    showToast(tOr('conditionalFormat.toast.importedFromSource', '已从「{source}」导入 {count} 条到「我的规则」{suffix}——点「🖌️ 应用与修复 → 应用条件格式」才会写进工作表', {
        source,
        count: String(added),
        suffix,
    }), 'success');
}
/** 弹窗默认说明的原始 HTML（首次打开时从页面抓，避免文案两处维护） */
let textImportDefaultHintHtml = null;
/**
 * 打开「粘贴规则 JSON」弹窗
 *
 * @param options.prefill 预填内容（从系统剪贴板读到的东西）；不传则清空
 * @param options.hint 覆盖说明文案（如「读不到剪贴板，请 Ctrl+V」）；不传恢复默认
 */
function openTextImportModal(options = {}) {
    const textarea = byId('conditionalFormatTextImportInput');
    if (textarea instanceof HTMLTextAreaElement)
        textarea.value = options.prefill ?? '';
    const hint = byId('conditionalFormatTextImportHint');
    if (hint) {
        textImportDefaultHintHtml ??= hint.innerHTML;
        hint.innerHTML =
            options.hint === undefined ? textImportDefaultHintHtml : escapeHtml(options.hint);
    }
    const mask = byId('conditionalFormatTextImportMask');
    const modal = mask?.querySelector('.conditional-format-modal');
    if (mask) {
        if (modal) {
            resetModalPosition(modal);
            applyModalButtonsPosition(modal);
        }
        anchorModalMask(mask);
        mask.style.display = 'flex';
        if (modal)
            bringModalIntoView(mask, modal);
    }
    lockModalScroll();
    if (textarea instanceof HTMLTextAreaElement)
        textarea.focus();
}
/** 关闭「粘贴规则 JSON」弹窗（没开时 no-op，别乱解滚动锁） */
function closeTextImportModal() {
    const mask = byId('conditionalFormatTextImportMask');
    if (mask?.style.display === 'none')
        return;
    if (mask)
        mask.style.display = 'none';
    unlockModalScroll();
}
/** 确认粘贴的 JSON 并导入 */
function confirmTextImport() {
    const textarea = byId('conditionalFormatTextImportInput');
    const text = textarea instanceof HTMLTextAreaElement ? textarea.value : '';
    if (text.trim() === '') {
        showToast(tOr('conditionalFormat.toast.pasteJsonFirst', '先把规则 JSON 粘进来'), 'warn');
        return;
    }
    closeTextImportModal();
    importRulesFromText(text, tOr('conditionalFormat.import.pastedText', '粘贴的文本'));
}
/** 快照是否可导入（与 foreignSnapshotToRule 的判据一致：公式类且有公式） */
function isSnapshotImportable(snapshot) {
    return snapshot.kind === 'expression' && snapshot.formula !== '';
}
/**
 * 导入弹框与表格的勾选联动：一处改动，三处视图同步
 *
 * 弹框列表 / 既有规则表格 / 批量操作条都读同一份 {@link existingSelection}，
 * 改它之后必须把三处都重渲染，否则用户在一处勾了、另一处不亮——那就是
 * momo 报的「没有联动」。
 */
function syncImportSelectionViews() {
    renderImportList();
    renderExistingRules();
    setText('conditionalFormatImportConfirm', tOr('conditionalFormat.import.confirmCount', '导入所选（{count}）', {
        count: String(state.existingSelection.size),
    }));
}
/** 弹框里可导入项的 1 基序号（全选用） */
function selectableImportIndices() {
    return state.importForeignRules
        .map((snapshot, position) => (isSnapshotImportable(snapshot) ? position + 1 : 0))
        .filter((index) => index > 0);
}
/**
 * 打开「选择要导入的规则」弹框
 *
 * 可导入的（公式类）默认全选——一表里通常大多数规则就是要导的；
 * 不可导入的禁用勾选并标注类型，不静默丢。
 */
function openImportModal(snapshots, sheetName) {
    state.importForeignRules = [...snapshots];
    // 联动：弹框勾选 = 表格勾选（同一 Set）。表格已勾了就带着进弹框；
    // 什么都没勾时默认全选可导入项，并回写表格（两边同时亮起，不再「没联动」）。
    if (state.existingSelection.size === 0) {
        state.existingSelection = new Set(selectableImportIndices());
    }
    setText('conditionalFormatImportSheet', sheetName);
    syncImportSelectionViews();
    renderImportList();
    const mask = byId('conditionalFormatImportMask');
    const modal = mask?.querySelector('.conditional-format-modal');
    if (mask) {
        if (modal) {
            resetModalPosition(modal);
            applyModalButtonsPosition(modal);
        }
        anchorModalMask(mask);
        mask.style.display = 'flex';
        if (modal)
            bringModalIntoView(mask, modal);
    }
    lockModalScroll();
}
function closeImportModal() {
    const mask = byId('conditionalFormatImportMask');
    // 没开 = no-op：Esc 块连调五个 close，没开的弹窗不能动共享的滚动锁计数
    // （modalScrollLockCount 是计数式；空关一次就把别的弹窗的锁解掉了）
    if (mask?.style.display === 'none')
        return;
    if (mask) {
        mask.style.display = 'none';
    }
    // 不清 existingSelection：弹框与表格共享它，清了就是「联动只做一半」
    unlockModalScroll();
}
/**
 * 导入弹框列表的分组聚合（momo：要按照分组导入）
 *
 * 与既有规则表格同一套映射（existingGroups，key = snapshotGroupKey），
 * 组序 = 组内首条出现顺序，「未分组」恒排最后——两个视图口径一致，
 * 用户在表格里归好的组在弹框里原样呈现。返回 [组名, [序号, 快照]] 有序对。
 */
function groupImportSnapshots() {
    const buckets = new Map();
    for (const [position, snapshot] of state.importForeignRules.entries()) {
        const group = state.existingGroups[snapshotGroupKey(snapshot)] ?? UNGROUPED_LABEL;
        const bucket = buckets.get(group);
        if (bucket)
            bucket.push([position + 1, snapshot]);
        else
            buckets.set(group, [[position + 1, snapshot]]);
    }
    const ungrouped = buckets.get(UNGROUPED_LABEL);
    if (ungrouped !== undefined) {
        buckets.delete(UNGROUPED_LABEL);
        buckets.set(UNGROUPED_LABEL, ungrouped);
    }
    return [...buckets];
}
/** 弹框分组内可导入项的序号（组内全选用：不可导入的禁用项不混进来） */
function importableIndicesOfGroup(entries) {
    return entries.filter(([, snapshot]) => isSnapshotImportable(snapshot)).map(([index]) => index);
}
function renderImportList() {
    const container = byId('conditionalFormatImportList');
    if (!container)
        return;
    const selection = state.existingSelection;
    // 表头：导入弹框的行是 5 列（勾选 / 序号 / 范围 / 公式 / 类型警示），
    // 原来没有列名，范围与公式两串等宽等长的文本全靠猜。也是行高把手的落点。
    const head = `<div class="conditional-format-import-row conditional-format-import-row--head conditional-format-table-head table-resize-head">
        <span></span>
        <span>#</span>
        <span>${tOr('conditionalFormat.import.colRange', '应用范围')}</span>
        <span>${tOr('conditionalFormat.import.colFormula', '公式')}</span>
        <span></span>
      </div>`;
    container.innerHTML =
        head +
            groupImportSnapshots()
                .map(([group, entries]) => {
                const isCollapsed = state.importGroupCollapsed.has(group);
                const rows = entries
                    .map(([index, snapshot]) => {
                    const canImport = isSnapshotImportable(snapshot);
                    const formulaPreview = snapshot.formula.length > 40 ? `${snapshot.formula.slice(0, 40)}…` : snapshot.formula;
                    return `
      <label class="conditional-format-import-row${canImport ? '' : ' is-disabled'}" data-import-index="${String(index)}">
        <input type="checkbox" data-import-check="${String(index)}" ${selection.has(index) ? 'checked' : ''} ${canImport ? '' : 'disabled'} aria-label="${tOr('conditionalFormat.import.rowAria', '选择第 {index} 条规则', { index: String(index) })}" />
        <span class="conditional-format-import-index">${String(index)}</span>
        <span class="conditional-format-import-range" title="${escapeHtml(snapshot.range)}">${escapeHtml(snapshot.range || tOr('conditionalFormat.import.rangeUnread', '（未读到范围）'))}</span>
        <code class="conditional-format-import-formula" title="${escapeHtml(snapshot.formula)}">${escapeHtml(formulaPreview)}</code>
        ${canImport ? '' : `<em class="conditional-format-tag-warn">${tOr('conditionalFormat.import.typeUnsupported', '类型不支持')}</em>`}
      </label>`;
                })
                    .join('');
                return `
      <div class="conditional-format-group conditional-format-existing-group${isCollapsed ? ' is-collapsed' : ''}" data-import-group="${escapeHtml(group)}">
        <div class="conditional-format-group-title">
          <button type="button" class="conditional-format-group-toggle" data-action="toggle-import-group" data-import-group="${escapeHtml(group)}" aria-expanded="${isCollapsed ? 'false' : 'true'}" title="${isCollapsed ? tOr('conditionalFormat.group.expand', '展开分组') : tOr('conditionalFormat.group.collapse', '收起分组')}">${isCollapsed ? '▸' : '▾'}</button>
          <span class="conditional-format-group-name">${escapeHtml(group)}</span>
          <span class="conditional-format-group-count">${String(entries.length)}</span>
          <button type="button" class="conditional-format-group-pick" data-action="pick-import-group" data-import-group="${escapeHtml(group)}" title="${tOr('conditionalFormat.import.pickGroup', '全选 / 取消本组可导入的规则')}">☑</button>
        </div>
        ${rows}
      </div>`;
            })
                .join('');
    setText('conditionalFormatImportConfirm', tOr('conditionalFormat.import.confirmCount', '导入所选（{count}）', {
        count: String(selection.size),
    }));
    // 表头是新节点，重插列宽/行高把手（decorate 幂等）
    state.tableResize.importDialog?.decorate();
    maybeAutoFitTable('importDialog');
}
/**
 * 导入弹框的组标题按钮（点击委托）：收起 / 展开分组、组内全选 / 取消
 *
 * 组内全选是「切换」语义：组内可导入项已全勾 → 全部取消；否则补全。
 * 只勾可导入项——类型不支持的本来就禁着，混进选中集只会虚增计数。
 */
function handleImportListClick(event) {
    const target = event.target;
    const group = target?.closest('[data-import-group]')?.dataset.importGroup;
    if (group === undefined || group === '')
        return;
    if (target?.closest('[data-action="toggle-import-group"]') !== null) {
        const next = new Set(state.importGroupCollapsed);
        if (next.has(group))
            next.delete(group);
        else
            next.add(group);
        state.importGroupCollapsed = next;
        renderImportList();
        return;
    }
    // （能走到这里说明上面 closest 命中了 data-import-group，target 必非空）
    if (target.closest('[data-action="pick-import-group"]') !== null) {
        const found = groupImportSnapshots().find(([name]) => name === group);
        const entries = found === undefined ? [] : found[1];
        const groupIndices = importableIndicesOfGroup(entries);
        const isGroupFullySelected = groupIndices.length > 0 && groupIndices.every((index) => state.existingSelection.has(index));
        const next = new Set(state.existingSelection);
        for (const index of groupIndices) {
            if (isGroupFullySelected)
                next.delete(index);
            else
                next.add(index);
        }
        state.existingSelection = next;
        syncImportSelectionViews();
    }
}
/**
 * 把指定快照导入规则库（导入弹框与表格勾选批量导入共用）
 *
 * 不可导入的逐条跳过并在结果里报数——不静默丢，否则用户以为 10 条全导进来了，
 * 实际只进了 3 条。
 */
function importSnapshots(snapshots, indices) {
    const imported = [];
    let skipped = 0;
    for (const index of indices) {
        const snapshot = snapshots[index - 1];
        // 用条件包裹而非 continue（项目禁 continue）：snapshot 缺失说明序号越界，
        // 跳过这条继续处理其余选中项
        if (snapshot) {
            // 组名随导入带进规则库：表格里归好的组不丢结构
            const rule = foreignSnapshotToRule(snapshot, nextId, groupOfSnapshot(snapshot));
            if (rule)
                imported.push(rule);
            else
                skipped += 1;
        }
    }
    if (imported.length === 0) {
        showToast(tOr('conditionalFormat.toast.importNoFormulaSelected', '所选规则里没有可导入的公式类规则'), 'warn');
        return;
    }
    // 导入前体检：脏规则不该进库（进了只在「应用」时才炸，且只留一句 toast）
    const blocked = blockingEntriesOf(imported);
    if (blocked.length > 0) {
        openRuleDoctor({
            mode: 'import',
            entries: blocked,
            hint: tOr('conditionalFormat.doctor.blockedHintImport', '这 {count} 条的范围 / 公式不合法，宿主一定会拒绝写入。修好再导入，免得进库后「应用」时才报错。', { count: String(blocked.length) }),
            onConfirm: (fixed) => {
                commitImportedSnapshots(patchRulesByKey(imported, fixed), skipped);
            },
        });
        return;
    }
    commitImportedSnapshots(imported, skipped);
}
/**
 * 把体检弹窗改好的规则按 key（来源数组下标）填回原位
 *
 * @param source 原数组（不改）
 * @param fixed 弹窗回传的条目（只含被挑出来的那几条）
 */
function patchRulesByKey(source, fixed) {
    const patched = [...source];
    for (const entry of fixed) {
        const index = Number(entry.key);
        if (Number.isSafeInteger(index) && index >= 0 && index < patched.length) {
            patched[index] = entry.rule;
        }
    }
    return patched;
}
/** 真正落库 + 提示（导入流的终点，体检通过后才走到这） */
function commitImportedSnapshots(imported, skipped) {
    state.rules = [...state.rules, ...imported];
    persistRules();
    renderRuleList();
    showToast(tOr('conditionalFormat.toast.importedRules', '已导入 {count} 条规则{skippedNote}', {
        count: String(imported.length),
        skippedNote: skipped > 0
            ? tOr('conditionalFormat.toast.importedRulesSkipped', '（{count} 条类型不支持，已跳过）', {
                count: skipped,
            })
            : '',
    }), skipped > 0 ? 'info' : 'success');
}
let doctorEntries = [];
let doctorOnConfirm = null;
/**
 * 打开「规则体检」弹窗
 *
 * 三个时机共用一个弹窗（导入前 / 应用前 / 应用后没落地）—— 用户心智只有一件事：
 * 「这几条有问题，改完继续」，而不是三种不同的报错。
 */
function openRuleDoctor(options) {
    doctorEntries = [...options.entries];
    doctorOnConfirm = options.onConfirm;
    setText('conditionalFormatDoctorHint', options.hint);
    setText('conditionalFormatDoctorConfirm', options.mode === 'import'
        ? tOr('conditionalFormat.doctor.confirmImport', '修复并导入')
        : tOr('conditionalFormat.doctor.confirmApply', '修复并应用'));
    renderDoctorList();
    const mask = byId('conditionalFormatDoctorMask');
    const modal = mask?.querySelector('.conditional-format-modal');
    if (mask) {
        if (modal) {
            resetModalPosition(modal);
            applyModalButtonsPosition(modal);
        }
        anchorModalMask(mask);
        mask.style.display = 'flex';
        if (modal)
            bringModalIntoView(mask, modal);
    }
    lockModalScroll();
}
function closeRuleDoctor() {
    const mask = byId('conditionalFormatDoctorMask');
    if (mask?.style.display === 'none')
        return;
    if (mask)
        mask.style.display = 'none';
    unlockModalScroll();
    doctorOnConfirm = null;
}
/** 渲染卡片列表（一条问题规则一张卡：问题 + 可改的范围 / 公式） */
function renderDoctorList() {
    const list = byId('conditionalFormatDoctorList');
    if (!list)
        return;
    list.innerHTML = doctorEntries
        .map((entry) => {
        const isBlocking = hasBlockingIssue(entry.issues);
        const flag = isBlocking
            ? `<span class="conditional-format-doctor-flag">${tOr('conditionalFormat.doctor.flagMustFix', '必须修')}</span>`
            : `<span class="conditional-format-doctor-flag conditional-format-doctor-flag--warn">${tOr('conditionalFormat.doctor.flagMayFail', '可能不生效')}</span>`;
        const issueLines = entry.issues
            .map((issue) => {
            const fix = issue.fixed === undefined
                ? ''
                : ` <em>${tOr('conditionalFormat.doctor.autoFixable', ' → 可自动改成 <code>{fixed}</code>', {
                    fixed: escapeHtml(issue.fixed),
                })}</em>`;
            return `<li class="conditional-format-doctor-issue">${escapeHtml(issue.message)}${fix}</li>`;
        })
            .join('');
        const reasonLine = entry.reason === undefined
            ? ''
            : `<li class="conditional-format-doctor-issue"><em>${tOr('conditionalFormat.doctor.hostReason', '宿主原因：')}</em><code>${escapeHtml(entry.reason)}</code></li>`;
        return `
      <div class="conditional-format-doctor-card">
        <div class="conditional-format-doctor-name">
          <span>${escapeHtml(entry.rule.name)}</span>${flag}
        </div>
        <ul class="conditional-format-doctor-issues">${issueLines}${reasonLine}</ul>
        <div class="conditional-format-doctor-fields">
          <label>${tOr('conditionalFormat.doctor.rangeLabel', '应用于')}<input type="text" class="conditional-format-doctor-range" value="${escapeHtml(entry.rule.appliesTo)}" aria-label="${tOr('conditionalFormat.doctor.rangeAria', '{name} 的应用范围', { name: escapeHtml(entry.rule.name) })}" /></label>
          <label>${tOr('conditionalFormat.doctor.formulaLabel', '公式')}<input type="text" class="conditional-format-doctor-formula" value="${escapeHtml(entry.rule.formula)}" aria-label="${tOr('conditionalFormat.doctor.formulaAria', '{name} 的公式', { name: escapeHtml(entry.rule.name) })}" /></label>
        </div>
      </div>`;
    })
        .join('');
}
/**
 * 把用户在输入框里的改动读回条目（DOM 是真值来源：卡片可能被手改过）
 *
 * 按**卡片顺序**取（不用 data-key 查 DOM：`CSS.escape` 在部分宿主里不存在，
 * 而卡片的渲染顺序恒等于 `doctorEntries` 的顺序）。
 */
function collectDoctorEntries() {
    const list = byId('conditionalFormatDoctorList');
    if (!list)
        return doctorEntries;
    return doctorEntries.map((entry, position) => {
        const card = list.children[position];
        if (!(card instanceof HTMLElement))
            return entry;
        const rangeInput = card.querySelector('.conditional-format-doctor-range');
        const formulaInput = card.querySelector('.conditional-format-doctor-formula');
        return {
            ...entry,
            rule: {
                ...entry.rule,
                appliesTo: rangeInput?.value.trim() ?? entry.rule.appliesTo,
                formula: formulaInput?.value.trim() ?? entry.rule.formula,
            },
        };
    });
}
/** 「🩺 全部自动修复」：把能安全修的一次性修掉，修不了的仍在卡片上标红 */
function fixAllDoctor() {
    const collected = collectDoctorEntries();
    doctorEntries = collected.map((entry) => {
        const { rule } = fixRule(entry.rule);
        return { ...entry, rule, issues: inspectRule(rule) };
    });
    renderDoctorList();
    const remaining = doctorEntries.filter((entry) => hasBlockingIssue(entry.issues)).length;
    showToast(remaining === 0
        ? tOr('conditionalFormat.doctor.fixedAll', '已自动修复（仍标黄的条目只是「可能不生效」，不影响写入）')
        : tOr('conditionalFormat.doctor.fixedPartial', '已自动修复一部分，还剩 {count} 条必须手工改（看红色标记）', {
            count: String(remaining),
        }), remaining === 0 ? 'success' : 'warn');
}
/** 「修复并继续」：再体检一次，还有阻断项就留在这，不把脏规则带进下一步 */
function confirmDoctor() {
    const collected = collectDoctorEntries();
    const refreshed = collected.map((entry) => ({ ...entry, issues: inspectRule(entry.rule) }));
    const stillBlocked = refreshed.filter((entry) => hasBlockingIssue(entry.issues));
    if (stillBlocked.length > 0) {
        doctorEntries = refreshed;
        renderDoctorList();
        showToast(tOr('conditionalFormat.toast.stillInvalid', '还有 {count} 条改完仍不合法（卡片上带红色「必须修」），修好再继续', {
            count: String(stillBlocked.length),
        }), 'error');
        return;
    }
    const callback = doctorOnConfirm;
    closeRuleDoctor();
    callback?.(refreshed);
}
/**
 * 体检一批规则：把「宿主一定会拒」的挑出来，交给体检弹窗
 *
 * 只筛阻断项：非阻断项（如「范围在 B 列、公式判 I 列」）在导入 39 条时会
 * 一次性糊满屏幕，反而淹没真正写不进去的那条 —— 它们仍会在**应用后**的
 * 弹窗里出现（那时只剩一两条，看得清）。
 */
function blockingEntriesOf(rules) {
    return inspectRules(rules, (rule) => rule.name)
        .filter((entry) => hasBlockingIssue(entry.issues))
        .map((entry) => ({ key: String(entry.index), rule: entry.rule, issues: entry.issues }));
}
// ===== 导出规则 =====
/**
 * 规则导出的统一出口：选位置 → 写文件 →（FSO 不可用）回退下载
 *
 * momo：所有导出都要能选择保存的位置。通道见 tools/save-file：
 * WPS 原生另存为对话框（预填默认导出位置）+ FSO 直写，失败才回退 Blob 下载。
 *
 * 「最近一次即默认」：用户这次选的目录若与记忆的不同，顺手写回
 * 默认导出位置（设置页「默认导出位置」读同一配置键，即时同步）——
 * 不用为了改默认再跑一趟设置页。
 *
 * @returns 是否成功保存（用户取消也是 false，调用方静默返回即可）
 */
function saveRulesJson(rules, label, labelForMessage = label) {
    const today = new Date().toISOString().slice(0, 10);
    const payload = {
        format: 'bgm-conditional-format-rules',
        version: 1,
        exportedAt: new Date().toISOString(),
        rules,
    };
    const result = saveTextFileWithDialog({
        title: tOr('conditionalFormat.export.dialogTitle', '导出{label}（选择保存位置）', {
            label: labelForMessage,
        }),
        defaultDir: getExportPath(true),
        fileName: `bgm-${label}-${today}.json`,
        content: JSON.stringify(payload, null, 2),
        filterDescription: tOr('conditionalFormat.export.filterDescription', '规则文件 (*.json)'),
        filterExtensions: '*.json',
    });
    // 用户取消（null）：不提示、不动默认位置、返回 false
    const isCancelled = result === null;
    if (isCancelled)
        return false;
    // 降级通道（FSO 不可用）：落浏览器下载目录，toast 明示落点
    const isDownloadFallback = result.path === '';
    if (isDownloadFallback) {
        showToast(tOr('conditionalFormat.toast.exportedToDownloads', '已导出 {count} 条{label}到浏览器下载目录', {
            count: String(rules.length),
            label: labelForMessage,
        }), 'success');
        return true;
    }
    const chosenDirectory = directoryNameOf(result.path);
    // 「最近一次即默认」：这次选的目录与记忆不同 → 写回默认导出位置
    // （设置页「默认导出位置」读同一配置键，即时同步）
    const hasChosenDirectory = chosenDirectory !== '';
    const isNewDefaultDirectory = hasChosenDirectory && chosenDirectory !== getExportPath(true);
    if (isNewDefaultDirectory) {
        setExportPath(chosenDirectory);
        showToast(tOr('conditionalFormat.toast.defaultExportDirSaved', '已记住为默认导出位置: {dir}', {
            dir: chosenDirectory,
        }), 'info');
    }
    showToast(tOr('conditionalFormat.toast.exportedToPath', '已导出 {count} 条{label}到 {path}', {
        count: String(rules.length),
        label: labelForMessage,
        path: result.path,
    }), 'success');
    return true;
}
/**
 * 复制规则 JSON 到剪贴板
 *
 * 与导出文件同一 payload 结构（可直接粘回「粘贴规则」/ 导入），
 * 适合「快速备份到笔记 / 发给别人」而不用先选保存位置。
 */
async function copyRulesJson(rules, label, labelForMessage = label) {
    if (rules.length === 0) {
        showToast(tOr('conditionalFormat.toast.noRulesToCopy', '没有可复制的规则'), 'warn');
        return;
    }
    const payload = {
        format: 'bgm-conditional-format-rules',
        version: 1,
        exportedAt: new Date().toISOString(),
        rules,
    };
    const isOk = await copyTextToSystemClipboard(JSON.stringify(payload, null, 2));
    if (isOk)
        showToast(tOr('conditionalFormat.toast.copiedToClipboard', '已复制 {count} 条{label}到剪贴板', {
            count: String(rules.length),
            label: labelForMessage,
        }), 'success');
    else
        showToast(tOr('conditionalFormat.toast.clipboardCopyFailed', '复制到剪贴板失败，请改用「导出到文件」'), 'error');
}
/** 导出整个规则库（备份 / 迁移 / 分享） */
function exportRules() {
    if (state.rules.length === 0) {
        showToast(tOr('conditionalFormat.toast.libraryEmpty', '规则库是空的，先新建或导入几条'), 'warn');
        return;
    }
    saveRulesJson(state.rules, '规则库', tOr('conditionalFormat.export.labelLibrary', '规则库'));
}
/** 导出所选规则（我的规则勾选 / 分组内勾选 / 工作表规则批量条共用） */
function exportSelectedRules(rules, label, labelForMessage = label) {
    if (rules.length === 0) {
        showToast(tOr('conditionalFormat.toast.noSelectedRules', '没有选中的规则'), 'warn');
        return;
    }
    saveRulesJson(rules, label, labelForMessage);
}
/** 遍历顺序 = 写入顺序（存储里 key 的次序稳定，diff 好读） */
const TABLE_RESIZE_IDS = ['existing', 'library', 'importDialog', 'paste'];
/**
 * 表格尺寸的存储键
 *
 * 四张表共用一个键：都在同一页、读一次就够，也不会出现「四个键写了一半」的
 * 半新半旧状态。结构：`{ existing: {cols, rowHeight}, … }`，缺项 = 全自动。
 */
const TABLE_RESIZE_STORE_KEY = 'conditionalFormat.tableSizes.v1';
/**
 * 把存储里的一个条目收敛成 {@link TableSizeState}
 *
 * 存储是用户可改的（PluginStorage 本质是个字符串表），所以逐字段验型：
 * 非数字 / 非正数 / NaN 一律当 `null`（= 自动），不让一个坏值把整表钉成 0px。
 *
 * @param value 存储里读出的原始值
 * @returns 收敛后的状态；不是对象则 `null`
 */
function toTableSizeState(value) {
    if (typeof value !== 'object' || value === null)
        return null;
    const record = value;
    const rawWidths = Array.isArray(record.cols) ? record.cols : [];
    const widths = rawWidths.map((width) => typeof width === 'number' && Number.isFinite(width) && width > 0 ? Math.round(width) : null);
    const rawRowHeight = record.rowHeight;
    const rowHeight = typeof rawRowHeight === 'number' && Number.isFinite(rawRowHeight) && rawRowHeight > 0
        ? Math.round(rawRowHeight)
        : null;
    return { cols: widths, rowHeight };
}
/** 读四张表的尺寸（坏 JSON / 坏条目都退化为「全自动」，不让页面初始化失败） */
function readTableSizes() {
    const raw = getConfig(TABLE_RESIZE_STORE_KEY, '', true);
    if (raw === '')
        return {};
    try {
        const parsed = JSON.parse(raw);
        if (typeof parsed !== 'object' || parsed === null)
            return {};
        const record = parsed;
        const entries = TABLE_RESIZE_IDS.map((id) => [id, toTableSizeState(record[id])]).filter((entry) => entry[1] !== null);
        return Object.fromEntries(entries);
    }
    catch {
        return {};
    }
}
/** 把四张表的当前尺寸写回存储（任一表拖动结束都会触发） */
function saveTableSizes() {
    const payload = {};
    for (const id of TABLE_RESIZE_IDS) {
        const controller = state.tableResize[id];
        if (controller !== null)
            payload[id] = controller.getState();
    }
    setConfig(TABLE_RESIZE_STORE_KEY, JSON.stringify(payload));
}
/**
 * 点「📐 自适行列」：按内容重新分配该表列宽，行高回到按内容
 *
 * 手动拖动过的表也允许再点 —— 用户点的就是「重新分配」，此时覆盖旧值是预期行为，
 * 不是冲掉记忆。
 */
function smartFitTable(id) {
    const controller = state.tableResize[id];
    if (!controller)
        return;
    if (controller.autoFit() === 0) {
        showToast(tOr('conditionalFormat.toast.tableNotReady', '表格还没内容或正藏着，先读取规则再点「📐 自适行列」'), 'warn');
        return;
    }
    state.tableAutoFitDone.add(id);
    saveTableSizes();
    showToast(tOr('conditionalFormat.toast.fitted', '已按内容分配列宽，行高改为按内容（拖列线可手调，双击列线回到自动）'), 'success');
}
/**
 * 首次渲染出内容时按内容自动分配一次
 *
 * 尊重手动值：存储里已有固定列宽 / 行高（用户拖过或上次智能分配过）就跳过 ——
 * 否则每次重渲染都重新量，用户刚拖好的列宽会被冲掉。
 */
function maybeAutoFitTable(id) {
    if (state.tableAutoFitDone.has(id))
        return;
    const controller = state.tableResize[id];
    if (!controller)
        return;
    const stored = controller.getState();
    if (stored.cols.some((width) => width !== null) || stored.rowHeight !== null) {
        state.tableAutoFitDone.add(id);
        return;
    }
    if (controller.autoFit() === 0)
        return;
    state.tableAutoFitDone.add(id);
    saveTableSizes();
}
/**
 * 给四张表接上列宽/行高拖拽（只建一次）
 *
 * 句柄挂在**容器**上，容器节点在渲染时只换子节点不换自己，所以只建一次即可；
 * 每次重渲染后由各自的 render 函数调 `decorate()` 补把手。
 */
function setupTableResize() {
    const stored = readTableSizes();
    const bindings = [
        { id: 'existing', elementId: 'conditionalFormatExistingList' },
        { id: 'library', elementId: 'conditionalFormatRuleList' },
        { id: 'importDialog', elementId: 'conditionalFormatImportList' },
        { id: 'paste', elementId: 'conditionalFormatPasteTable' },
    ];
    for (const { id, elementId } of bindings) {
        const container = byId(elementId);
        if (container) {
            state.tableResize[id] = bindTableResize({
                container,
                initial: stored[id] ?? {},
                onChange: () => {
                    saveTableSizes();
                },
            });
        }
    }
}
export function initializeConditionalFormatPage() {
    markConditionalFormatPaneLoaded();
    initializeShellNav();
    initializeTheme();
    initializeI18n();
    startThemeSync();
    // ⚠️ 宿主读取（loadRules / reloadSheets 等 COM）**不在这里做**，挪到本函数
    // 末尾的 populateFromHost()——2026-10-24 真机缺陷：桥未就绪时 collectSheets
    // 抛错会连坐整个初始化，后面全部事件绑定都装不上，下拉成了「不能点击不能
    // 选中」的死件。先装绑定（纯 DOM 不可能抛），再读宿主，读失败页面仍可用。
    // 搜索
    inputById('conditionalFormatSearch')?.addEventListener('input', (event) => {
        state.searchQuery = event.target.value;
        renderRuleList();
    });
    // 目标工作簿 / 工作表：选择器（option-picker）内部通过 onChange 调
    // onWorkbookChange / onSheetChange，不再需要在这里绑 <select> 的 change
    byId('conditionalFormatReloadSheetsBtn')?.addEventListener('click', () => {
        reloadSheets();
    });
    byId('conditionalFormatRefreshExistingBtn')?.addEventListener('click', () => {
        loadExistingRules();
    });
    // 目标表锁定：默认不锁（选中键失效时兜底跳活动表，保持既有行为）。
    // 勾选后失效不跳 —— 条件格式是写操作，静默应用到错表的代价太高。
    const lockBox = inputById('conditionalFormatSheetLock');
    if (lockBox) {
        lockBox.checked = isSheetLocked();
        lockBox.addEventListener('change', () => {
            setSheetLock(lockBox.checked);
        });
    }
    // 「一键套用」：把别处选中的簿/表落到本页的 KEY_SHEET 上
    registerTargetSheetApplier('conditional-format', (snap) => {
        if (!snap.workbook || !snap.sheet)
            return false;
        const key = `${snap.workbook}::${snap.sheet}`;
        const isHit = state.sheets.some((entry) => entry.key === key);
        if (!isHit)
            return false;
        state.selectedKey = key;
        state.selectionMissing = '';
        setConfig(KEY_SHEET, key);
        renderWorkbookPicker();
        renderSheetPicker();
        loadExistingRules();
        return true;
    });
    // 既有规则表格：搜索 + 事件委托（不给每行绑监听器，347 条规则下才不卡）
    inputById('conditionalFormatExistingSearch')?.addEventListener('input', (event) => {
        state.existingQuery = event.target.value;
        state.existingPage = 1;
        renderExistingRules();
    });
    // 委托绑在 **panel** 上而不是表格上：批量操作条在表格容器外，
    // 且表格节点会在「正文」与「浮动窗口」之间搬家（appendChild 不丢监听器，
    // 但绑在表格上就意味着批量条要另绑一份——绑父节点一次覆盖两者）。
    byId('conditionalFormatExistingPanel')?.addEventListener('click', handleExistingTableClick);
    byId('conditionalFormatExistingPanel')?.addEventListener('change', handleExistingTableChange);
    // 浮动「工作表规则」窗口：拖动 / 缩放 / 收起 + 开关与 DOM 搬家
    bindExistingToolbar();
    // 两个列表的拖拽排序 + 行右键菜单（通用组件接入，只建一次）
    setupSortablesAndMenus();
    // 四张表的列宽/行高拖拽（通用组件接入，只建一次；每次重渲染后 decorate）
    setupTableResize();
    // 规则操作
    byId('conditionalFormatNewRuleBtn')?.addEventListener('click', () => {
        openEditor(null, true);
    });
    byId('conditionalFormatPasteBtn')?.addEventListener('click', () => {
        pasteRules();
    });
    // ▾：系统剪贴板 / 手写文本（「从文本导入」已并入这个下拉）
    byId('conditionalFormatPasteMenuBtn')?.addEventListener('click', (event) => {
        const button = event.currentTarget;
        if (button instanceof HTMLElement)
            openPasteMenu(button);
    });
    byId('conditionalFormatImportBtn')?.addEventListener('click', () => {
        importForeign();
    });
    // ▾：从文件 / 从文本（项目导出的 .json 走文件这条）
    byId('conditionalFormatImportMenuBtn')?.addEventListener('click', (event) => {
        const button = event.currentTarget;
        if (button instanceof HTMLElement)
            openImportMenu(button);
    });
    byId('conditionalFormatImportFile')?.addEventListener('change', handleImportFileChange);
    byId('conditionalFormatTextImportOk')?.addEventListener('click', () => {
        confirmTextImport();
    });
    byId('conditionalFormatTextImportCancel')?.addEventListener('click', () => {
        closeTextImportModal();
    });
    byId('conditionalFormatTextImportMask')?.addEventListener('click', (event) => {
        if (event.target === byId('conditionalFormatTextImportMask'))
            closeTextImportModal();
    });
    byId('conditionalFormatExportBtn')?.addEventListener('click', (event) => {
        // 「导出规则」= 下拉：导出到文件 / 复制到剪贴板（后者不用先选保存位置）
        const button = event.currentTarget;
        const rect = button.getBoundingClientRect();
        showContextMenu({
            items: [
                {
                    id: 'export-file',
                    label: tOr('conditionalFormat.export.toFile', '📄 导出到文件'),
                    onSelect: () => {
                        exportRules();
                    },
                },
                {
                    id: 'export-clipboard',
                    label: tOr('conditionalFormat.export.toClipboard', '📋 复制到剪贴板'),
                    onSelect: () => copyRulesJson(state.rules, '规则库', tOr('conditionalFormat.export.labelLibrary', '规则库')),
                },
            ],
            x: rect.left,
            y: rect.bottom + 4,
            anchor: button,
        });
    });
    // 全选 / 取消全部：作用于当前**搜索后的可见集**（与既有规则表格的
    // 全选同口径——跨搜索全选再一键删，搜不到想撤回来的项最危险）。
    // 已全选时再点 = 取消，不用另找「取消选择」。
    byId('conditionalFormatPickAllBtn')?.addEventListener('click', () => {
        const visible = filterRules(state.rules, state.searchQuery);
        if (visible.length === 0) {
            showToast(tOr('conditionalFormat.toast.noRulesToSelectAll', '没有可全选的规则'), 'warn');
            return;
        }
        const visibleIds = visible.map((rule) => rule.id);
        const isAllPicked = visibleIds.every((id) => state.ruleSelection.has(id));
        const next = new Set(state.ruleSelection);
        for (const id of visibleIds) {
            if (isAllPicked)
                next.delete(id);
            else
                next.add(id);
        }
        state.ruleSelection = next;
        renderRuleList();
    });
    // 批量条（勾选后才出现）：删除所选 / 导出所选 / 取消选择
    byId('conditionalFormatRuleBatchBar')?.addEventListener('click', (event) => {
        const target = event.target;
        const button = target?.closest('[data-rule-batch]');
        if (!button)
            return;
        switch (button.dataset.ruleBatch) {
            case 'copy': {
                copyRules([...state.ruleSelection]);
                break;
            }
            case 'edit': {
                openBatchEdit('library');
                break;
            }
            case 'delete': {
                deleteSelectedRules([...state.ruleSelection]);
                break;
            }
            case 'export': {
                const picked = state.rules.filter((rule) => state.ruleSelection.has(rule.id));
                exportSelectedRules(picked, '所选规则', tOr('conditionalFormat.export.labelSelected', '所选规则'));
                break;
            }
            case 'clear': {
                state.ruleSelection = new Set();
                renderRuleList();
                break;
            }
            default: {
                break;
            }
        }
    });
    byId('conditionalFormatDefaultsBtn')?.addEventListener('click', () => {
        generateDefaults();
    });
    byId('conditionalFormatApplyBtn')?.addEventListener('click', () => {
        applyFlow();
    });
    // 危险操作：清空目标表全部条件格式后重建。与「应用」分开成两个按钮，
    // 是为了让「不清除任何既有规则」成为默认路径（旧实现只有一个按钮且默认清空）。
    byId('conditionalFormatApplyReplaceBtn')?.addEventListener('click', () => {
        replaceFlow();
    });
    // 编辑器
    byId('conditionalFormatEditorSave')?.addEventListener('click', () => {
        saveEditor();
    });
    byId('conditionalFormatEditorCancel')?.addEventListener('click', () => {
        closeEditor();
    });
    // 编辑器浮层：点遮罩空白处关闭（与确认模态框同口径，点内容不关）
    byId('conditionalFormatEditorMask')?.addEventListener('click', (event) => {
        if (event.target === byId('conditionalFormatEditorMask'))
            closeEditor();
    });
    // 六个模态框统一补「窗口三件套」：拖标题栏移动 + ⛶ 最大化/还原 + ▾ 收起 +
    // 右下角缩放把手——能力原语在 window-chrome（与浮动窗共用的窗口能力层）。
    // 窄任务窗格里遮罩居中的模态框又小又挡内容，此前只能看不能调（momo：加上
    // 浮动窗口模块的收起和放大等功能）。
    // [遮罩 id, 标题栏 id, 收起按钮 id, 最大化按钮 id, 缩放把手 id]
    const MODAL_SPECS = [
        [
            'conditionalFormatEditorMask',
            'conditionalFormatEditorTitle',
            'conditionalFormatEditorCollapse',
            'conditionalFormatEditorMax',
            'conditionalFormatEditorResize',
        ],
        [
            'conditionalFormatImportMask',
            'conditionalFormatImportTitle',
            'conditionalFormatImportCollapse',
            'conditionalFormatImportMax',
            'conditionalFormatImportResize',
        ],
        [
            'conditionalFormatGroupMask',
            'conditionalFormatGroupTitle',
            'conditionalFormatGroupCollapse',
            'conditionalFormatGroupMax',
            'conditionalFormatGroupResize',
        ],
        [
            'conditionalFormatConfirmMask',
            'conditionalFormatConfirmTitle',
            'conditionalFormatConfirmCollapse',
            'conditionalFormatConfirmMax',
            'conditionalFormatConfirmResize',
        ],
        [
            'conditionalFormatPasteMask',
            'conditionalFormatPasteTitle',
            'conditionalFormatPasteCollapse',
            'conditionalFormatPasteMax',
            'conditionalFormatPasteResize',
        ],
        [
            'conditionalFormatTextImportMask',
            'conditionalFormatTextImportTitle',
            'conditionalFormatTextImportCollapse',
            'conditionalFormatTextImportMax',
            'conditionalFormatTextImportResize',
        ],
        [
            'conditionalFormatBatchMask',
            'conditionalFormatBatchTitle',
            'conditionalFormatBatchCollapse',
            'conditionalFormatBatchMax',
            'conditionalFormatBatchResize',
        ],
        [
            'conditionalFormatDoctorMask',
            'conditionalFormatDoctorTitle',
            'conditionalFormatDoctorCollapse',
            'conditionalFormatDoctorMax',
            'conditionalFormatDoctorResize',
        ],
    ];
    for (const [maskId, titleId, collapseId, maximizeId, resizeId] of MODAL_SPECS) {
        const mask = byId(maskId);
        const modal = mask?.querySelector('.conditional-format-modal');
        const grip = byId(titleId);
        if (modal && grip)
            bindModalDrag({ modal, grip });
        const collapseButton = byId(collapseId);
        if (modal && collapseButton)
            bindModalCollapse({ modal, button: collapseButton });
        const maximizeButton = byId(maximizeId);
        if (modal && maximizeButton)
            bindModalMaximize({ modal, button: maximizeButton });
        const resizeHandle = byId(resizeId);
        if (modal && resizeHandle)
            bindModalResize({ modal, handle: resizeHandle });
    }
    // 粘贴规则弹窗：确定 / 取消 / 遮罩关闭（三件套已在上面统一绑）
    const pasteMask = byId('conditionalFormatPasteMask');
    byId('conditionalFormatPasteOk')?.addEventListener('click', () => {
        confirmPaste();
    });
    byId('conditionalFormatPasteCancel')?.addEventListener('click', () => {
        closePasteModal();
    });
    pasteMask?.addEventListener('click', (event) => {
        if (event.target === pasteMask)
            closePasteModal();
    });
    // 多条粘贴：表格里逐条改范围 / 统一范围 / 批量修改（范围·公式·颜色）
    byId('conditionalFormatPasteTable')?.addEventListener('input', handlePasteTableInput);
    byId('conditionalFormatPasteApplyRange')?.addEventListener('click', () => {
        applyPasteUniformRange();
    });
    byId('conditionalFormatPasteBatchEdit')?.addEventListener('click', () => {
        openBatchEdit('paste');
    });
    // 批量修改弹窗（三处入口共用）
    byId('conditionalFormatBatchOk')?.addEventListener('click', () => {
        confirmBatchEdit();
    });
    byId('conditionalFormatBatchCancel')?.addEventListener('click', () => {
        closeBatchEdit();
        closeRuleDoctor();
    });
    byId('conditionalFormatBatchMask')?.addEventListener('click', (event) => {
        if (event.target === byId('conditionalFormatBatchMask'))
            closeBatchEdit();
    });
    // 颜色字段：选择器 / 十六进制手输 / 吸管三边联动（吸管按钮不支持时保持隐藏）
    for (const field of COLOR_FIELDS) {
        bindColorField(field);
    }
    // 既有规则分组：自动聚类 / 清除 / 归组弹窗
    byId('conditionalFormatClusterBtn')?.addEventListener('click', () => {
        autoClusterExistingGroups();
    });
    byId('conditionalFormatMergeBtn')?.addEventListener('click', () => {
        mergeExistingDuplicates();
    });
    // 两张主表的「📐 自适行列」：各管各的表（点哪个就量哪个，不做「一键全量」——
    // 导入弹框 / 粘贴表格只在打开时自动量一次，工具栏上再塞两个按钮反而找不到）
    byId('conditionalFormatFitExistingBtn')?.addEventListener('click', () => {
        smartFitTable('existing');
    });
    byId('conditionalFormatFitLibraryBtn')?.addEventListener('click', () => {
        smartFitTable('library');
    });
    byId('conditionalFormatRepairAnchorBtn')?.addEventListener('click', () => {
        repairAnchors(false);
    });
    byId('conditionalFormatFixCellBtn')?.addEventListener('click', () => {
        fixRulesToCell();
    });
    byId('conditionalFormatClearGroupsBtn')?.addEventListener('click', () => {
        clearExistingGroups();
    });
    byId('conditionalFormatGroupConfirm')?.addEventListener('click', () => {
        confirmGroupName();
    });
    byId('conditionalFormatGroupCancel')?.addEventListener('click', () => {
        closeGroupNameModal();
    });
    byId('conditionalFormatGroupMask')?.addEventListener('click', (event) => {
        if (event.target === byId('conditionalFormatGroupMask'))
            closeGroupNameModal();
    });
    // 导入手工规则：选择弹框（全选 / 全不选 / 确认 / 取消 / 遮罩）
    byId('conditionalFormatImportConfirm')?.addEventListener('click', () => {
        const indices = [...state.existingSelection].sort((a, b) => a - b);
        closeImportModal();
        importSnapshots(state.importForeignRules, indices);
    });
    byId('conditionalFormatImportCancel')?.addEventListener('click', () => {
        closeImportModal();
    });
    // 规则体检：全部自动修复 / 修复并继续 / 取消 / 点遮罩关闭
    byId('conditionalFormatDoctorFixAll')?.addEventListener('click', () => {
        fixAllDoctor();
    });
    byId('conditionalFormatDoctorConfirm')?.addEventListener('click', () => {
        confirmDoctor();
    });
    byId('conditionalFormatDoctorCancel')?.addEventListener('click', () => {
        closeRuleDoctor();
    });
    byId('conditionalFormatDoctorMask')?.addEventListener('click', (event) => {
        if (event.target === byId('conditionalFormatDoctorMask'))
            closeRuleDoctor();
    });
    byId('conditionalFormatImportMask')?.addEventListener('click', (event) => {
        if (event.target === byId('conditionalFormatImportMask'))
            closeImportModal();
    });
    byId('conditionalFormatImportAll')?.addEventListener('click', () => {
        state.existingSelection = new Set(selectableImportIndices());
        syncImportSelectionViews();
    });
    byId('conditionalFormatImportNone')?.addEventListener('click', () => {
        state.existingSelection = new Set();
        syncImportSelectionViews();
    });
    // 组标题按钮（收起 / 展开分组、组内全选）走 click 委托
    byId('conditionalFormatImportList')?.addEventListener('click', (event) => {
        handleImportListClick(event);
    });
    // 列表勾选走 change 委托；勾选只更新确认按钮计数，不重建列表（保住焦点，
    // 用户连勾十几条时不用每次重新点）
    byId('conditionalFormatImportList')?.addEventListener('change', (event) => {
        const target = event.target;
        const rawIndex = target?.dataset.importCheck;
        if (rawIndex === undefined)
            return;
        const index = Number(rawIndex);
        if (!Number.isSafeInteger(index) || index < 1)
            return;
        const next = new Set(state.existingSelection);
        if (target?.checked === true)
            next.add(index);
        else
            next.delete(index);
        state.existingSelection = next;
        // 联动：弹框里勾一条，表格与批量条同步亮起（不重建弹框列表——保住焦点，
        // 用户连勾十几条时不用每次重新点）
        renderExistingRules();
        setText('conditionalFormatImportConfirm', tOr('conditionalFormat.import.confirmCount', '导入所选（{count}）', {
            count: String(next.size),
        }));
    });
    // 确认模态框（只服务「清空整表后应用」这一个危险操作）
    byId('conditionalFormatConfirmClear')?.addEventListener('click', () => {
        closeConfirmModal();
        runApply('replace');
    });
    byId('conditionalFormatConfirmCancel')?.addEventListener('click', () => {
        closeConfirmModal();
    });
    byId('conditionalFormatConfirmMask')?.addEventListener('click', (event) => {
        if (event.target === byId('conditionalFormatConfirmMask'))
            closeConfirmModal();
    });
    document.addEventListener('keydown', (event) => {
        if (event.key !== 'Escape')
            return;
        closeConfirmModal();
        // 其余弹窗也关：各 close 幂等（没开时 no-op），一次 Esc 全收
        closeEditor();
        closeImportModal();
        closeGroupNameModal();
        closePasteModal();
        closeTextImportModal();
        closeBatchEdit();
        closeRuleDoctor();
    });
    // ---- 宿主读取放在全部绑定之后：抛错也只损失首屏数据，不损失交互 ----
    populateFromHost();
    renderRuleList();
    // 启用 data-action 按钮：漏了这一步，页面按钮会灰 5 秒直到门禁超时兜底
    notifyModulesReady();
}
/**
 * 首屏宿主读取（COM 集中在这里；抛错时绑定已装完，页面仍可用）
 *
 * 典型失败场景：宿主初始化窗口内同步跨进程 COM 抛错（JSAPI 桥未就绪，或被
 * JsApiDevTool 调速器限速拖慢看门狗）。此时只报告「首屏数据没读到」并给恢复
 * 路径——下拉显示「（无已打开的工作簿）」，「🔄 刷新列表」按钮是绑好的，点一
 * 下重新枚举即可。绝不让异常把初始化连坐掉（那才是真机「组件不能点击」的本因）。
 */
function populateFromHost() {
    try {
        loadRules();
        loadExistingGroups();
        state.selectedKey = getConfig(KEY_SHEET, '', true);
        // 进入时重放：其它页获取的工作簿/表/列/行一次性显示（读一次存储，零轮询）
        mountDataContextNotice('conditional-format');
        reloadSheets();
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        bgmLog(LOG_LEVELS.ERROR, `[conditionalFormat] 首屏宿主读取失败：${message}`);
        showToast(tOr('conditionalFormat.toast.loadWorkbooksFailed', '读取工作簿列表失败，请点「🔄 刷新列表」重试'), 'error');
        // 下拉渲染成明确的空态（有刷新按钮可点），不是静默的空下拉
        renderWorkbookPicker();
        renderSheetPicker();
    }
}
// ===== 「工作表规则」拖出为浮动窗口 =====
/**
 * 绑定「工作表规则」工具条（显示其格式规则 + ↑↓ 调序 + 删除）
 *
 * 工具条常显在「既有规则」区内（任务窗格与专注模式共用同一份 DOM）。
 * 进入专注模式的入口在模块标题的「⛶ 只显示此模块」按钮（module-state
 * 运行时注入）——工具栏原先那个「🔍 规则管理器」按钮与之完全同一件事（该模块现名「工作表规则」）
 * （同调 enterSoloMode('conditional-format', 'sec-existing')），momo：
 * 按钮功能重复，已删。
 */
function bindExistingToolbar() {
    const scopeSelect = selectById('conditionalFormatFloatScope');
    // 「显示其格式规则」：整表 / 当前选择。
    // 当前选择 = 只显示 AppliesTo 与选区相交的规则 —— 用户框了一列想看
    // 「这条列上挂了哪些条件」时不用在 347 条里翻。
    scopeSelect?.addEventListener('change', () => {
        state.existingScope = scopeSelect.value === 'selection' ? 'selection' : 'all';
        state.existingPage = 1;
        renderExistingRules();
    });
    // ↑↓ / 删除：与批量条同一套实现，只是入口不同（WPS 原生的按钮位）
    byId('conditionalFormatFloatUp')?.addEventListener('click', () => {
        batchMoveForeignRules(-1);
    });
    byId('conditionalFormatFloatDown')?.addEventListener('click', () => {
        batchMoveForeignRules(1);
    });
    byId('conditionalFormatFloatDelete')?.addEventListener('click', () => {
        batchDeleteForeignRules();
    });
}
/**
 * 「工作表规则」的专注模式入口：模块标题的「⛶ 只显示此模块」按钮
 * （module-state 运行时注入，本文件不再装配任何入口）。
 *
 * 历史备注：这里曾有 setupRuleManagerEntry 给工具栏按钮
 * （conditionalFormatFloatBtn）绑 enterSoloMode，与 ⛶ 按钮完全同一件事，
 * 2026-10-25 momo 指出功能重复，已删——专注入口只留 ⛶ 一处。
 *
 * 为什么不再是原生独立窗口：原生 WebDialog（Application.CreateWebDialog /
 * ShowDialog）即使 `IsModal=false` 也会置顶、抢焦点，挡住用户在表格上框选区 ——
 * 这是 WPS 宿主级限制，插件侧绕不过（代码已尽力传非模态）。边看表格边管规则
 * 恰恰是它的核心场景，被挡反而本末倒置，故弃用原生。
 *
 * 页面内专注模式：本页只剩「既有规则」（配合专注模式隐藏顶栏占满任务窗格），
 * 底部控制条可 ↑↓ 切换 / 退出。任务窗格在侧边不挡表格主区。
 */
// ===== 拖拽排序 + 行右键菜单（sortable-list / context-menu 两个通用组件接入）=====
/**
 * 装配两个列表的拖拽排序与行右键菜单
 *
 * - 规则库列表：重排 = 本地 moveItemNear + 持久化（零 COM，即时生效）；
 * - 既有规则表格：重排 = 按「相邻交换」逐格调 COM 优先级（|Δ| 次
 *   moveForeignRule），完成后重读整表。WPS 没有「移动一格」原语，逐格交换
 *   是唯一不丢非公式规则（数据条 / 图标集）的办法——见 moveForeignRule 注释。
 *
 * 两个容器都是「子节点反复重渲染、容器本身不动」的形态，故 sortable 与委托
 * 菜单都只建一次；渲染函数末尾调 handle.refresh() 重新扫描项即可。
 */
function setupSortablesAndMenus() {
    // ---- 规则库列表 ----
    const ruleList = byId('conditionalFormatRuleList');
    if (ruleList) {
        state.ruleSortable = createSortable({
            container: ruleList,
            itemSelector: '.conditional-format-rule[data-rule-id]',
            getItemId: (item) => item.dataset.ruleId ?? '',
            // 把手启动：行内有勾选 / 可见性 / ↑↓⧉✎✕ 一堆交互元素，整行可拖
            // 会和它们抢手势（momo：现在都是可拖动的——误触排序）。从 ⋮⋮ 把手
            // 起拖，其余位置该点的点、该选的选。
            handleSelector: '.conditional-format-rule-handle',
            onReorder: (event) => {
                const next = moveItemNear(state.rules, event.fromId, event.overId, event.placeAfter);
                // 顺序没变（放到原位的邻居上）→ 不持久化不重渲染
                const hasChanged = next.some((rule, index) => rule.id !== state.rules[index]?.id);
                if (!hasChanged)
                    return;
                state.rules = next;
                persistRules();
                renderRuleList();
            },
        });
        // 组标题也可拖：整组调整次序（组序 = 组内首条规则的位置，落成规则序即可）
        state.groupSortable = createSortable({
            container: ruleList,
            itemSelector: '.conditional-format-group-title',
            getItemId: (item) => item.closest('[data-group]')?.dataset.group ?? '',
            onReorder: (event) => {
                // 当前组序取**全量**规则（不是搜索后的可见序）：overId 可能只出现在
                // 可见序里，但搬迁必须落在全量序上，否则未可见的组会被挤到队尾
                const currentOrder = groupRules(state.rules).map(([group]) => group);
                const nextOrder = moveGroupNear(currentOrder, event.fromId, event.overId, event.placeAfter);
                const next = reorderGroups(state.rules, nextOrder);
                const hasChanged = next.some((rule, index) => rule.id !== state.rules[index]?.id);
                if (!hasChanged)
                    return;
                state.rules = next;
                persistRules();
                renderRuleList();
            },
        });
        attachDelegatedContextMenu(ruleList, '.conditional-format-rule[data-rule-id]', (item) => {
            const id = item.dataset.ruleId ?? '';
            const rule = state.rules.find((candidate) => candidate.id === id);
            if (!rule)
                return [];
            const index = state.rules.indexOf(rule);
            const isHidden = rule.hidden === true;
            return [
                {
                    id: 'edit',
                    label: tOr('conditionalFormat.menu.edit', '✎ 编辑'),
                    onSelect: () => {
                        openEditor(id, false);
                    },
                },
                {
                    id: 'copy',
                    label: tOr('conditionalFormat.menu.copy', '⧉ 复制'),
                    onSelect: () => {
                        copyRules([id]);
                    },
                },
                { id: 'sep1', separator: true },
                {
                    id: 'up',
                    label: tOr('conditionalFormat.menu.moveUp', '↑ 上移（提高优先级）'),
                    disabled: index <= 0,
                    disabledReason: tOr('conditionalFormat.menu.alreadyTop', '已经是最高优先级'),
                    onSelect: () => {
                        moveRule(id, -1);
                    },
                },
                {
                    id: 'down',
                    label: tOr('conditionalFormat.menu.moveDown', '↓ 下移（降低优先级）'),
                    disabled: index >= state.rules.length - 1,
                    disabledReason: tOr('conditionalFormat.menu.alreadyBottom', '已经是最低优先级'),
                    onSelect: () => {
                        moveRule(id, 1);
                    },
                },
                { id: 'sep2', separator: true },
                {
                    id: 'hide',
                    label: isHidden
                        ? tOr('conditionalFormat.menu.unhide', '👁 取消隐藏')
                        : tOr('conditionalFormat.menu.hide', '👁 隐藏（留在库内不应用）'),
                    onSelect: () => {
                        toggleHidden(id, !isHidden);
                    },
                },
                { id: 'sep3', separator: true },
                {
                    id: 'delete',
                    label: tOr('conditionalFormat.menu.delete', '✕ 删除'),
                    danger: true,
                    onSelect: () => {
                        deleteRule(id);
                    },
                },
            ];
        });
    }
    // ---- 既有规则表格 ----
    const existingPanel = byId('conditionalFormatExistingPanel');
    if (existingPanel) {
        state.existingSortable = createSortable({
            container: existingPanel,
            itemSelector: '.conditional-format-row[data-row-index]',
            getItemId: (item) => item.dataset.rowIndex ?? '',
            // 提交后整表重读、行号整体漂移：按旧行号找不到「移动后的项」，
            // 落位动画会飞错位置——关掉，直接撤浮层（toast 已告知结果）
            animateDrop: false,
            onReorder: (event) => {
                reorderForeignRules(event.fromId, event.overId, event.placeAfter);
            },
        });
        attachDelegatedContextMenu(existingPanel, '.conditional-format-row[data-row-index]', (item) => {
            const index = Number(item.dataset.rowIndex ?? '0');
            const snapshot = state.existing[index - 1];
            if (!snapshot)
                return [];
            const canImport = snapshot.kind === 'expression' && snapshot.formula !== '';
            const isStopKnown = snapshot.stopIfTrue !== undefined;
            return [
                {
                    id: 'import',
                    label: tOr('conditionalFormat.menu.importToLibrary', '⤵ 导入规则库'),
                    disabled: !canImport,
                    disabledReason: tOr('conditionalFormat.menu.importDisabled', '该类型插件无法重建，不能导入'),
                    onSelect: () => {
                        importForeignRule(index);
                    },
                },
                {
                    id: 'edit',
                    label: tOr('conditionalFormat.menu.editFull', '✎ 编辑（范围 / 公式 / 颜色）'),
                    onSelect: () => {
                        openExistingRuleEditor(index);
                    },
                },
                {
                    id: 'duplicate',
                    label: tOr('conditionalFormat.menu.duplicate', '⧉ 复制成新规则'),
                    disabled: !canImport,
                    disabledReason: tOr('conditionalFormat.menu.duplicateDisabled', '该类型读不到公式，无法复制'),
                    onSelect: () => {
                        openDuplicateModal(index);
                    },
                },
                {
                    id: 'group',
                    label: tOr('conditionalFormat.menu.assignGroup', '🏷 归入分组'),
                    onSelect: () => {
                        state.existingSelection = new Set([index]);
                        renderExistingRules();
                        openGroupNameModal();
                    },
                },
                {
                    id: 'stop',
                    label: snapshot.stopIfTrue === true
                        ? tOr('conditionalFormat.menu.clearStopIfTrue', '🚦 取消「如果为真则停」')
                        : tOr('conditionalFormat.menu.stopIfTrue', '🚦 如果为真则停'),
                    disabled: !isStopKnown,
                    disabledReason: tOr('conditionalFormat.menu.stopUnknown', '当前 WPS 未暴露该属性'),
                    onSelect: () => {
                        const entry = selectedSheet();
                        if (!entry)
                            return;
                        const result = setForeignStopIfTrue(entry.worksheet, index, snapshot.stopIfTrue !== true);
                        if (result.ok)
                            loadExistingRules();
                        else
                            showToast(tOr('conditionalFormat.toast.setFailed', '设置失败：{error}', {
                                error: result.error,
                            }), 'error');
                    },
                },
                { id: 'sep1', separator: true },
                {
                    id: 'up',
                    label: tOr('conditionalFormat.menu.moveUp', '↑ 上移（提高优先级）'),
                    disabled: index <= 1,
                    disabledReason: tOr('conditionalFormat.menu.alreadyTop', '已经是最高优先级'),
                    onSelect: () => {
                        moveForeignRuleRow(index, -1);
                    },
                },
                {
                    id: 'down',
                    label: tOr('conditionalFormat.menu.moveDown', '↓ 下移（降低优先级）'),
                    disabled: index >= state.existing.length,
                    disabledReason: tOr('conditionalFormat.menu.alreadyBottom', '已经是最低优先级'),
                    onSelect: () => {
                        moveForeignRuleRow(index, 1);
                    },
                },
                { id: 'sep2', separator: true },
                {
                    id: 'delete',
                    label: tOr('conditionalFormat.menu.deleteFromSheet', '✕ 从工作表删除'),
                    danger: true,
                    onSelect: () => {
                        deleteForeignRuleRow(index);
                    },
                },
            ];
        });
    }
}
/**
 * 既有规则拖拽提交：从 from 逐格交换到目标位（COM 无「移动一格」原语）
 *
 * 目标位由落点推算：placeAfter ? over : over - 1；over 为 null = 移到最后。
 * 逐步调用 moveForeignRule（每次一格、写后回读校验），中途失败即停并 toast
 * 说明已完成步数——不假装成功，也不丢弃已完成的步骤。
 */
function reorderForeignRules(fromId, overId, isPlaceAfter) {
    const entry = selectedSheet();
    if (!entry)
        return;
    const from = Number(fromId);
    if (!Number.isSafeInteger(from) || from < 1 || from > state.existing.length)
        return;
    let target = state.existing.length;
    if (overId !== null) {
        const over = Number(overId);
        if (!Number.isSafeInteger(over) || over < 1 || over > state.existing.length)
            return;
        target = isPlaceAfter ? over : over - 1;
    }
    if (target === from || target < 1 || target > state.existing.length)
        return;
    const direction = target < from ? -1 : 1;
    let position = from;
    let failure = null;
    while (position !== target) {
        const result = moveForeignRule(entry.worksheet, position, direction);
        if (!result.ok) {
            failure = result.error;
            break;
        }
        position += direction;
    }
    const done = Math.abs(position - from);
    if (failure !== null) {
        showToast(tOr('conditionalFormat.toast.moveInterrupted', '调整中断：{failure}（已完成 {done} 步）', {
            failure,
            done: String(done),
        }), 'error');
    }
    else if (done > 0) {
        showToast(tOr('conditionalFormat.toast.movedCells', '已移动 {count} 格', {
            count: String(done),
        }), 'success');
    }
    loadExistingRules();
}
