/**
 * 跨页数据上下文共享
 * @module tools/dataContext
 * @description 页面获取到的工作簿 / 工作表 / 列 / 行信息写入 PluginStorage（键
 *   `bgm_data_context`），其它页面**进入时**读一次并重放成通知条。
 *
 * 为什么是「进入时读一次」而不是实时推送 / 轮询：周期性同步 COM 是 2026-10-21
 * 定位的卡顿根因（宿主初始化窗口内 / 频繁跨进程读取都会卡），这里只在两个
 * 天然便宜的时机各碰一次存储 —— 写入方在用户点击的按需路径上，读取方在页面
 * 初始化已读 PluginStorage 的同一阶段。
 */
import { getApp, bgmLog, getColumnMap, getLastRow } from './util/index.js';
import { LOG_LEVELS } from '../core/constants.js';
// tOr 直连 locale-store：i18n/index 桶会经 locale-install 拉进 ts/index（模块顶层写 window），
// node 单测一 import 就 ReferenceError。别改回桶。
import { tOr } from '../i18n/locale-store.js';
/** 存储键（单一最新快照，后写覆盖先写 —— 用户只关心「最近拿到的是什么」） */
const DATA_CONTEXT_KEY = 'bgm_data_context';
/**
 * 页面标识 → 展示名。
 *
 * 用函数而不是常量表：这里是**短名**（`富化`），要嵌进「{from}页已获取」这句话里；
 * 而 `nav-order.ts` 的 `PAGE_LABELS` 是长名（`富化面板`），给设置页模块排序当标题用 ——
 * 两处语境不同，各用各的 key，不能合并。
 */
function pageLabel(page) {
    switch (page) {
        case 'sync-panel': {
            return tOr('dataContext.from.syncPanel', '同步面板');
        }
        case 'enrich': {
            return tOr('dataContext.from.enrich', '富化');
        }
        case 'highlight': {
            return tOr('dataContext.from.highlight', '高亮');
        }
        case 'clean': {
            return tOr('dataContext.from.clean', '清理');
        }
        case 'settings': {
            return tOr('dataContext.from.settings', '设置');
        }
        default: {
            return page;
        }
    }
}
/** 写入最新数据上下文（用户点击获取数据的按需路径上调用，勿在自动轮询里调） */
export function saveDataContext(snap) {
    try {
        const app = getApp();
        if (!app?.PluginStorage)
            return;
        app.PluginStorage.setItem(DATA_CONTEXT_KEY, JSON.stringify({ ...snap, savedAt: Date.now() }));
    }
    catch (error) {
        // 快照写入是旁路能力：宿主/桩任何异常都不允许打断获取数据的主流程
        bgmLog(LOG_LEVELS.WARN, `[dataContext] 写入失败: ${String(error)}`);
    }
}
/** 读取最新数据上下文；没有或解析失败返回 null */
export function readDataContext() {
    try {
        const app = getApp();
        const raw = app?.PluginStorage ? app.PluginStorage.getItem(DATA_CONTEXT_KEY) : undefined;
        if (!raw)
            return null;
        const snap = JSON.parse(raw);
        if (!snap.workbook && !snap.sheet)
            return null;
        return {
            workbook: snap.workbook ?? '',
            sheet: snap.sheet ?? '',
            columns: Array.isArray(snap.columns) ? snap.columns : [],
            rowCount: snap.rowCount ?? 0,
            fromPage: snap.fromPage ?? '',
            savedAt: snap.savedAt ?? 0,
        };
    }
    catch {
        return null;
    }
}
/** 页面标识 → 套用实现（`mountDataContextNotice` 要读它决定显不显示按钮） */
const targetSheetAppliers = new Map();
/** 注册本页的「套用」实现（init 时调用；同一页重复注册以最后一次为准） */
// eslint-disable-next-line unicorn/consistent-boolean-name -- applier 是回调函数（返回 boolean），不是布尔变量；规则误报了返回类型
export function registerTargetSheetApplier(page, applier) {
    targetSheetAppliers.set(page, applier);
}
/** 本页是否支持「一键套用」（通知条据此决定显不显示按钮） */
export function hasTargetSheetApplier(page) {
    return targetSheetAppliers.has(page);
}
/**
 * 执行「套用到本页」。没有 applier 或执行抛错都返回 false（调用方只改按钮文案，
 * 不往上抛 —— 套用是便利功能，不该把页面搞崩）。
 */
// eslint-disable-next-line unicorn/consistent-boolean-name -- 与 registerTargetSheetApplier 同一理由：这是返回 boolean 的动作函数，不是布尔变量
export function applyDataContextToPage(page) {
    const registered = targetSheetAppliers.get(page);
    if (!registered)
        return false;
    const snapshot = readDataContext();
    if (!snapshot)
        return false;
    try {
        return registered(snapshot);
    }
    catch (error) {
        bgmLog(LOG_LEVELS.WARN, `[dataContext] 套用到 ${page} 失败: ${String(error)}`);
        return false;
    }
}
/** 仅供测试：清空注册表（避免跨文件残留影响其它用例） */
export function resetTargetSheetAppliers() {
    targetSheetAppliers.clear();
}
/**
 * 页面进入时重放：把其它页面获取的数据上下文显示为通知条（本页自己写的不重复展示）。
 *
 * 挂到 `<main class="main">` 顶部，一次性读存储，不做任何轮询；
 * 用户点 ✕ 即消失（本次进入期间不再出现）。
 *
 * 通知条带「套用到本页」按钮（仅当该页注册过 applier 时显示）：
 * 用户在高亮页选了表 → 跑到主面板 → 看到「高亮页已获取 X/Y」→ 点一下就
 * 把主面板也切到 X/Y，不用再把两级下拉重新点一遍。
 */
export function mountDataContextNotice(page) {
    const snap = readDataContext();
    if (!snap || snap.fromPage === page)
        return;
    const main = document.querySelector('main.main');
    if (!main || document.getElementById('bgmDataContextNotice'))
        return;
    const from = pageLabel(snap.fromPage);
    const time = new Date(snap.savedAt);
    const at = Number.isNaN(time.getTime())
        ? ''
        : ` · ${String(time.getHours()).padStart(2, '0')}:${String(time.getMinutes()).padStart(2, '0')}`;
    const columnPart = snap.columns.length > 0
        ? tOr('dataContext.colSuffix', ' · {count} 列', { count: String(snap.columns.length) })
        : '';
    const rowPart = snap.rowCount > 0
        ? tOr('dataContext.rowSuffix', ' · {count} 行', { count: String(snap.rowCount) })
        : '';
    const bar = document.createElement('div');
    bar.id = 'bgmDataContextNotice';
    // grid-column 兼容 panel 的 main-grid 布局（块布局下该属性无效果）
    bar.style.cssText =
        'display:flex;align-items:center;gap:8px;grid-column:1/-1;margin:0 0 8px;padding:6px 10px;' +
            'font-size:12px;color:var(--text-2,#bac2de);background:var(--bg-surface-2,#313244);' +
            'border-radius:6px;';
    const text = document.createElement('span');
    text.textContent = tOr('dataContext.loaded', '📋 {from}页已获取：{workbook} / {sheet}{columns}{rows}{at}', {
        from,
        workbook: snap.workbook || '—',
        sheet: snap.sheet || '—',
        columns: columnPart,
        rows: rowPart,
        at,
    });
    const actions = document.createElement('span');
    actions.style.cssText = 'margin-left:auto;display:flex;align-items:center;gap:6px;';
    // 「套用到本页」：只有本页注册了 applier 才给按钮（清理页是多选语义、
    // 设置页没有目标表，给了也做不到，不如不给）。
    if (targetSheetAppliers.has(page)) {
        const applyButton = document.createElement('button');
        applyButton.type = 'button';
        applyButton.className = 'bgm-btn small';
        applyButton.textContent = tOr('dataContext.apply', '↧ 套用到本页');
        applyButton.setAttribute('aria-label', tOr('dataContext.applyAria', '把{from}页选中的工作簿与工作表套用到本页', { from }));
        applyButton.addEventListener('click', () => {
            const isApplied = applyDataContextToPage(page);
            applyButton.textContent = isApplied
                ? tOr('dataContext.applied', '✓ 已套用')
                : tOr('dataContext.applyFailed', '✗ 套用失败');
            applyButton.disabled = true;
            applyButton.style.opacity = isApplied ? '0.75' : '1';
            if (!isApplied) {
                text.textContent = tOr('dataContext.failedText', '📋 套用失败：{workbook} / {sheet} 当前不可用（工作簿或工作表可能已关闭）', {
                    workbook: snap.workbook || '—',
                    sheet: snap.sheet || '—',
                });
            }
        });
        actions.append(applyButton);
    }
    const close = document.createElement('button');
    close.type = 'button';
    close.textContent = '✕';
    close.setAttribute('aria-label', tOr('dataContext.closeAria', '关闭数据同步提示'));
    close.style.cssText =
        'border:none;background:transparent;color:inherit;cursor:pointer;font-size:12px;';
    close.addEventListener('click', () => {
        bar.remove();
    });
    actions.append(close);
    bar.append(text, actions);
    main.prepend(bar);
}
/**
 * 从工作表提取快照（列名走 getColumnMap 的表头读，行数走 getLastRow）。
 * 供各页在「用户点击获取数据」的路径上统一取数，避免每页自己拼。
 *
 * 工作簿名走 `worksheet.Parent.Name`（取不到时退 `ActiveWorkbook.Name`）——
 * 曾经两处都填 `worksheet.Name`，通知条于是显示成「动画 / 动画」，
 * 「一键套用」也无从知道该切到哪个工作簿。
 */
export function snapshotFromWorksheet(worksheet, headerRow, fromPage) {
    const name = readSheetName(worksheet);
    const workbook = readWorkbookName(worksheet);
    let columns = [];
    let rowCount = 0;
    try {
        columns = [...getColumnMap(worksheet, headerRow).keys()];
        const lastRow = getLastRow(worksheet);
        rowCount = lastRow > headerRow ? lastRow - headerRow : 0;
    }
    catch {
        // 列/行读失败不阻断主流程：快照缺列行信息好过获取动作本身失败
    }
    return { workbook, sheet: name, columns, rowCount, fromPage };
}
/** 读工作表名（COM 属性访问整体包 try：拿不到不影响主流程） */
function readSheetName(worksheet) {
    try {
        return worksheet.Name;
    }
    catch {
        return '';
    }
}
/** 读工作表所属工作簿名（Parent 优先，退化到活动工作簿） */
function readWorkbookName(worksheet) {
    try {
        const parent = worksheet.Parent;
        const byParent = parent?.Name;
        if (byParent)
            return byParent;
    }
    catch {
        // Parent 不可达时走下面的活动工作簿兜底
    }
    try {
        return getApp()?.ActiveWorkbook?.Name ?? '';
    }
    catch {
        return '';
    }
}
