/**
 * UI 事件处理模块 - 入口与聚合
 * @module ui/handlers/index
 * @description 资源追踪、按钮监听、ACTION_HANDLERS 分发、消息监听、事件总线监听、
 *              配置 UI 回填等。同时 re-export 子模块的公开 API，保持原 handlers.ts 的外部接口。
 */
import { LOG_LEVELS, bgmLog, BGM, loadBgToken, showConfirm, refreshData, previewSyncContent, isSyncRecordEnabled, getTheme, getListType, getTimeFilter, getRefreshInterval, getLogLevel, getModalButtonsPosition, getThemeSchedule, getClusterMode, getMergeMode, } from '../../index.js';
import { onLocaleChange } from '../../i18n/locale-store.js';
import { getLocale } from '../../i18n/runtime.js';
import { loadGithubConfigIntoForm } from './github-settings.js';
import { initializeAccountManager } from './accounts.js';
import { initializeModuleOrderEditor } from './module-order.js';
import { initializeShortcutSettings } from './shortcuts-settings.js';
import { initializeConfigPathControls } from './path-controls.js';
import { clearTrackedListeners, trackedAddEventListener } from './resource-tracking.js';
// 子模块
import { _T } from './_constants.js';
import { handleActionClick, syncUsageGuideButton } from './action-handlers.js';
import { loadEnrichPreviewSettingsIntoForm } from './enrich-preview-settings.js';
import { loadHighlightSettingsIntoForm } from './highlight-settings.js';
import { initializeIncrementalSyncFromRibbon } from './incremental-bindings.js';
import { setupEventListeners, setupMessageListener } from './sync-panel-events.js';
import { loadTemplateFileInfo } from './template-file.js';
import { handleClusterModeClick, handleMergeModeClick, handleEnableSyncRecordChange, handleLanguageClick, handleListTypeChange, handleLocalePackInstall, handleLocalePackOpenDirectory, handleLogLevelChange, handleLogLevelFilterChange, handleRefreshIntervalChange, handleThemeChange, handleModalButtonsPositionClick, handleThemeModeClick, handleThemeScheduleChange, handleThemeToggleClick, handleTimeFilterChange, refreshLocalePackStatus, setupTimeFilterControls, updateLanguageButtons, updateModalButtonsPositionButtons, updateClusterModeButtons, updateMergeModeButtons, updateThemeModeButtons, updateThemeToggle, } from './settings-bindings.js';
import { setupUpdateChecker } from './update-checker.js';
import { syncFromPanel } from './sync.js';
import { showTokenDialog, showUserIdDialog, updateTokenStatus, updateUserIdStatus, } from './token.js';
// 子模块 re-export（保持原 handlers.ts 的对外 API）
export { showTokenDialog, showUserIdDialog, updateTokenStatus, updateUserIdStatus, openUserCollection, testTokenValidity, testDebugConnection, showUserProfile, hideUserProfile, } from './token.js';
export { syncFromPanel, syncCollectionFromBgm, syncFromBgmByAPI } from './sync.js';
export { cleanLockedDataSheet } from './sheet.js';
export { clearAllPendingTimeouts } from './resource-tracking.js';
export { removeMessageListener } from './sync-panel-events.js';
// 连接测试弹窗
// ========== 面板操作分发 ==========
export function onAction(action) {
    switch (action) {
        case 'sync': {
            void syncFromPanel();
            break;
        }
        case 'clear': {
            showConfirm(_T.confirmClearMarks, (confirmed) => {
                if (confirmed && typeof refreshData === 'function')
                    refreshData();
            });
            break;
        }
        case 'setToken': {
            showTokenDialog(loadBgToken() ?? '');
            break;
        }
        case 'preview': {
            if (typeof previewSyncContent === 'function')
                void previewSyncContent();
            break;
        }
        case 'showUserIdDialog': {
            showUserIdDialog();
            break;
        }
        case 'showClearConfirm': {
            showConfirm(_T.confirmClearMarks, (confirmed) => {
                if (confirmed && typeof refreshData === 'function')
                    refreshData();
            });
            break;
        }
        case 'tokenUpdated': {
            updateTokenStatus();
            break;
        }
        case 'userIdUpdated': {
            updateUserIdStatus();
            break;
        }
        case 'requestStopSync': {
            bgmLog(LOG_LEVELS.INFO, '[handleActionClick] 用户请求停止同步');
            BGM.sync.requestStop();
            break;
        }
        case 'pauseSync': {
            bgmLog(LOG_LEVELS.INFO, '用户请求暂停同步');
            BGM.sync.pause();
            break;
        }
        case 'resumeSync': {
            bgmLog(LOG_LEVELS.INFO, '用户请求恢复同步');
            BGM.sync.resume();
            break;
        }
        default: {
            // 未知 action 不处理（与旧逻辑一致：无默认分支即什么都不做）
            break;
        }
    }
}
// ========== 事件监听 ==========
export function setupButtonListeners() {
    document.querySelectorAll('[data-action]').forEach((button) => {
        trackedAddEventListener(button, 'click', handleActionClick);
    });
    // 启用同步记录 开关：从 config 读取初始状态 + 注册 change 监听器
    const checkboxEnableSyncRecord = document.getElementById('checkboxEnableSyncRecord');
    if (checkboxEnableSyncRecord) {
        // 从 config 读取初始状态（与 checkboxIncremental/checkboxSkipConflicts 一致的双向同步机制）
        try {
            const isEnabled = isSyncRecordEnabled();
            checkboxEnableSyncRecord.checked = isEnabled;
            bgmLog(LOG_LEVELS.INFO, `[handlers] 从配置读取同步记录状态: ${isEnabled ? '开启' : '关闭'}`);
        }
        catch (error) {
            bgmLog(LOG_LEVELS.WARN, `[handlers] 读取同步记录状态失败: ${error.message}`);
        }
        trackedAddEventListener(checkboxEnableSyncRecord, 'change', handleEnableSyncRecordChange);
        bgmLog(LOG_LEVELS.INFO, '[handlers] 启用同步记录 checkbox 监听器已注册');
    }
    // GitHub 配置：面板加载时自动填充已保存的值（含策略与同步源类型）
    try {
        loadGithubConfigIntoForm();
    }
    catch (error) {
        bgmLog(LOG_LEVELS.WARN, `[handlers] 加载 GitHub 配置失败: ${error.message}`);
    }
    // 系统日志：级别筛选下拉框变化时重新渲染日志列表
    const logLevelFilter = document.getElementById('logLevelFilter');
    if (logLevelFilter) {
        trackedAddEventListener(logLevelFilter, 'change', handleLogLevelFilterChange);
        bgmLog(LOG_LEVELS.INFO, '[handlers] 日志级别筛选 change 监听器已注册');
    }
    // 设置页：外观主题（按钮组：深色 / 浅色 / 跟随系统 / 定时 + 定时时刻输入）
    // 旧 themeSelect 下拉已改为按钮组（momo：用按钮形式），此处仅兼容残留的旧 DOM
    const themeSelect = document.getElementById('themeSelect');
    if (themeSelect) {
        themeSelect.value = getTheme(true);
        trackedAddEventListener(themeSelect, 'change', handleThemeChange);
        bgmLog(LOG_LEVELS.INFO, '[handlers] 主题选择 change 监听器已注册');
    }
    for (const button of document.querySelectorAll('[data-theme-mode]')) {
        trackedAddEventListener(button, 'click', handleThemeModeClick);
    }
    // 日夜开关（替代原「深色 / 浅色」两块色卡预览）
    const themeToggleButton = document.getElementById('themeToggleBtn');
    if (themeToggleButton) {
        trackedAddEventListener(themeToggleButton, 'click', handleThemeToggleClick);
    }
    const themeDarkStart = document.getElementById('themeDarkStart');
    const themeLightStart = document.getElementById('themeLightStart');
    const savedSchedule = getThemeSchedule(true);
    if (themeDarkStart) {
        themeDarkStart.value = savedSchedule.darkStart;
        trackedAddEventListener(themeDarkStart, 'change', handleThemeScheduleChange);
    }
    if (themeLightStart) {
        themeLightStart.value = savedSchedule.lightStart;
        trackedAddEventListener(themeLightStart, 'change', handleThemeScheduleChange);
    }
    updateThemeModeButtons(getTheme(true));
    updateThemeToggle(getTheme(true));
    // 设置页：界面语言（分段按钮：简体 / 繁體 / English）
    for (const button of document.querySelectorAll('[data-locale]')) {
        trackedAddEventListener(button, 'click', handleLanguageClick);
    }
    updateLanguageButtons(getLocale());
    // 语言变更（本页切换 / 其它窗格切换轮询回来）→ 同步按钮态与覆盖率文案。
    // 覆盖率那行不是 data-i18n 节点（内容是动态拼的），applyI18n 刷不到它。
    onLocaleChange((code) => {
        updateLanguageButtons(code);
        // 语言包这时才异步加载完，状态行里「已装版本」要等这一拍才准
        refreshLocalePackStatus();
    });
    // 语言包在线安装（修复 / 追新）：两个按钮都在设置页，不存在时静默跳过
    const localePackInstallButton = document.getElementById('localePackInstallBtn');
    if (localePackInstallButton) {
        trackedAddEventListener(localePackInstallButton, 'click', () => {
            void handleLocalePackInstall();
        });
    }
    const localePackOpenButton = document.getElementById('localePackOpenDirBtn');
    if (localePackOpenButton) {
        trackedAddEventListener(localePackOpenButton, 'click', handleLocalePackOpenDirectory);
    }
    // 模态框按钮位置分段按钮（回填 + 点击切换）
    for (const button of document.querySelectorAll('[data-modal-buttons-position]')) {
        trackedAddEventListener(button, 'click', handleModalButtonsPositionClick);
    }
    updateModalButtonsPositionButtons(getModalButtonsPosition(true));
    // 设置页「🎨 条件格式」：自动聚类口径分段按钮（回填 + 点击切换）
    for (const button of document.querySelectorAll('[data-cluster-mode]')) {
        trackedAddEventListener(button, 'click', handleClusterModeClick);
    }
    updateClusterModeButtons(getClusterMode(true));
    // 设置页「🎨 条件格式」：合并重复项口径（回填 + 点击切换）
    for (const button of document.querySelectorAll('[data-merge-mode]')) {
        trackedAddEventListener(button, 'click', handleMergeModeClick);
    }
    updateMergeModeButtons(getMergeMode(true));
    // 面板「帮助与格式 → 模板文件」：回填 Latest Release 的版本 / 文件名 / 大小
    void loadTemplateFileInfo();
    // 设置页「🎨 富化预览」：表单回填（元素不存在时模块内部自动跳过，面板页无副作用）
    loadEnrichPreviewSettingsIntoForm();
    // 设置页「⚙️ 功能开关」：表单回填
    loadHighlightSettingsIntoForm();
    // 设置页「关于」：检查更新（元素不存在时内部静默跳过）
    setupUpdateChecker();
    // 设置页：默认导出位置 / 默认导入文件夹（回填已记忆的路径）
    initializeConfigPathControls();
    // 设置页：全局日志级别（记录级别偏好）
    const logLevelSelect = document.getElementById('logLevelSelect');
    if (logLevelSelect) {
        logLevelSelect.value = String(getLogLevel(true));
        trackedAddEventListener(logLevelSelect, 'change', handleLogLevelChange);
        bgmLog(LOG_LEVELS.INFO, '[handlers] 日志级别 change 监听器已注册');
    }
    // 设置页：模块排序编辑器（↑↓ 按钮 + 拖拽）
    try {
        initializeModuleOrderEditor();
    }
    catch (error) {
        bgmLog(LOG_LEVELS.WARN, `[handlers] 初始化模块排序编辑器失败: ${error.message}`);
    }
    // 账号：设置页列表 + 长按头像切换（面板与设置页都会调用，缺元素时各自跳过）
    try {
        initializeAccountManager();
    }
    catch (error) {
        bgmLog(LOG_LEVELS.WARN, `[handlers] 初始化账号管理失败: ${error.message}`);
    }
    // 设置页：快捷键编辑器（绑定录制 / 冲突提示 / 鼠标手势）
    try {
        initializeShortcutSettings();
    }
    catch (error) {
        bgmLog(LOG_LEVELS.WARN, `[handlers] 初始化快捷键编辑器失败: ${error.message}`);
    }
    // 设置页：默认收藏列表类型
    const listTypeSelect = document.getElementById('listTypeSelect');
    if (listTypeSelect) {
        listTypeSelect.value = getListType(true);
        trackedAddEventListener(listTypeSelect, 'change', handleListTypeChange);
        bgmLog(LOG_LEVELS.INFO, '[handlers] 收藏列表类型 change 监听器已注册');
    }
    // 设置页：默认时间筛选范围
    const timeFilterSelect = document.getElementById('timeFilterSelect');
    if (timeFilterSelect) {
        timeFilterSelect.value = getTimeFilter(true);
        trackedAddEventListener(timeFilterSelect, 'change', handleTimeFilterChange);
        bgmLog(LOG_LEVELS.INFO, '[handlers] 时间筛选范围 change 监听器已注册');
    }
    // 设置页：自动刷新间隔（含校验）
    const refreshIntervalInput = document.getElementById('refreshIntervalInput');
    if (refreshIntervalInput) {
        refreshIntervalInput.value = String(getRefreshInterval(true));
        trackedAddEventListener(refreshIntervalInput, 'change', handleRefreshIntervalChange);
        bgmLog(LOG_LEVELS.INFO, '[handlers] 刷新间隔 change 监听器已注册');
    }
}
function startHandlers() {
    // 先清理旧监听器，防止面板重新初始化时重复注册
    clearTrackedListeners();
    setupButtonListeners();
    setupTimeFilterControls();
    // 首屏状态文案：这些节点没有 data-i18n（内容是状态），不主动写一次就会一直
    // 停在 HTML 里的中文初始值上。`initializeI18n()` 已由入口在此之前调用。
    syncUsageGuideButton();
    setupMessageListener();
    setupEventListeners();
    initializeIncrementalSyncFromRibbon();
    bgmLog(LOG_LEVELS.INFO, '[handlers] initializeHandlers 完成');
}
/**
 * 初始化 UI 事件处理模块。
 *
 * 显式入口函数，由 `ts/entry/sync-panel-entry.ts` 调用。
 * 不在模块加载时自动执行，避免：
 *  - 模块加载期间触发 trackedSetTimeout(setupButtonListeners, 0)
 *  - 在测试环境（无 DOM/BGM 全局对象）下意外触发副作用
 *
 * 行为：
 *  - 根据 document.readyState 决定同步执行还是延迟到 DOMContentLoaded
 *  - 调用 setupButtonListeners() 注册按钮点击监听
 *  - 注册消息监听器（接收 token/userId 等更新通知）
 *  - 注册事件总线监听器（接收配置变更与同步进度通知）
 *  - 从配置恢复增量同步、跳过冲突 UI 状态
 */
export function initializeHandlers() {
    if (typeof document === 'undefined') {
        // 无 DOM 环境（如 Node 测试环境）下同步执行
        startHandlers();
    }
    else if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            startHandlers();
        });
    }
    else {
        startHandlers();
    }
}
export { showConnectionTestDialog, hideConnectionTestDialog } from '../github-config-dialog.js';
